prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'PRODUCTOS'
,p_alias=>'PRODUCTOS'
,p_step_title=>'PRODUCTOS'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20220921122701'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27891706277595254)
,p_plug_name=>'PRODUCTOS'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleA'
,p_plug_template=>wwv_flow_imp.id(26020060573473803)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'PRODUCTOS'
,p_query_where=>'tipo = NVL(:P5_TIPO,1) and estado = ''A'''
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_plug_header=>'<h2><p style="font-family:verdana; color:red; size:60px">PRODUCTOS/SERVICIOS<p></h2>'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(27892096599595264)
,p_region_id=>wwv_flow_imp.id(27891706277595254)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'DESCRIPCION'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'REFERENCIA'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'DESCRIPCION'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80587746570556662)
,p_name=>'P5_TIPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(27891706277595254)
,p_prompt=>'<font size="3" color="red">Mostrar</font>'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:PRODUCTOS;1,SERVICIOS;3'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_cattributes_element=>'style="font-weight:bold;color:blue"'
,p_tag_attributes2=>'style="font-weight:bold;color:red"'
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
