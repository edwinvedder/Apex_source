prompt --application/pages/page_00042
begin
--   Manifest
--     PAGE: 00042
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>42
,p_name=>'ENTREGAS'
,p_alias=>'ENTREGAS'
,p_step_title=>'ORDENES'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'08'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20220917120327'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(139987290734424388)
,p_plug_name=>'REPARACIONES'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(26045265164473840)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select O.COMPANIA,',
'       O.ID,',
'       FECHA,',
'       PRODUCTO_ID,',
'       CANTIDAD_PRODUCTO,',
'       CLIENTE_ID,C.NOMBRE||'' ''||C.APELLIDOS||''(''||P.DESCRIPCION||'')'' NOMBRE,',
'       TIPO_FACTURACION,',
'       FECHA_VGARANTIA,',
'       O.ESTADO,',
'       NOTAS,',
'       REFERENCIA1,',
'       REFERENCIA2,',
'       NUMPOLIZA,',
'       NUMRECLAM,',
'       ASEGURADORA_ID,',
'       VDESDE,',
'       VHASTA,',
'       FECHA_ENTREGA,',
'       CASE ',
'  WHEN FECHA_ENTREGA > SYSDATE AND (FECHA_ENTREGA - SYSDATE) > 3 THEN ''apex-cal-green''',
'  WHEN (FECHA_ENTREGA - SYSDATE) > 0 AND (FECHA_ENTREGA - SYSDATE) <= 3 THEN ''apex-cal-yellow''',
'  ELSE ''apex-cal-orange''',
'END AS css_class',
'  from ORDENES_REPARACION O',
'  inner join PRODUCTOS P on O.PRODUCTO_ID = p.id',
'  inner join CLIENTES C on O.CLIENTE_ID = C.id',
' where O.COMPANIA=:P0_CIA AND O.ESTADO <> ''D'''))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_attribute_01=>'FECHA'
,p_attribute_02=>'FECHA_ENTREGA'
,p_attribute_03=>'NOMBRE'
,p_attribute_04=>'ID'
,p_attribute_05=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::P0_RCOTIZA:&ID.'
,p_attribute_06=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:16::'
,p_attribute_07=>'Y'
,p_attribute_08=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  UPDATE ORDENES_REPARACION',
'    SET FECHA = TO_DATE(:APEX$NEW_START_DATE,''YYYYMMDDHH24MISS''),',
'        FECHA_ENTREGA = TO_DATE(:APEX$NEW_END_DATE,''YYYYMMDDHH24MISS'')',
'    WHERE ID = :APEX$PK_VALUE;',
'END;'))
,p_attribute_09=>'list:navigation'
,p_attribute_13=>'N'
,p_attribute_14=>'CSS_CLASS'
,p_attribute_17=>'Y'
,p_attribute_19=>'Y'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135991662736802463)
,p_name=>'P42_ORDEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(139987290734424388)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
