prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'ASEGURADORAS'
,p_alias=>'ASEGURADORAS'
,p_step_title=>'ASEGURADORAS'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>'<style>h1,ol,ul,li,button{margin:0;padding:0}button{border:none;background:none}body{background:#fff}body,input,button{font-size:14px;font-family:arial,sans-serif;color:#222}a{color:#1a0dab;text-decoration:none}a:hover,a:active{text-decoration:underl'
||'ine}a:visited{color:#609}html,body{min-width:400px}body,html{height:100%;margin:0;padding:0}.gb_Wa:not(.gb_Fd){font:13px/27px Roboto,RobotoDraft,Arial,sans-serif;z-index:986}@-webkit-keyframes gb__a{0%{opacity:0}50%{opacity:1}}@keyframes gb__a{0%{opa'
||'city:0}50%{opacity:1}}a.gb_0{border:none;color:#4285f4;cursor:default;font-weight:bold;outline:none;position:relative;text-align:center;text-decoration:none;text-transform:uppercase;white-space:nowrap;-webkit-user-select:none}a.gb_0:hover:after,a.gb_'
||'0:focus:after{background-color:rgba(0,0,0,.12);content:'''';height:100%;left:0;position:absolute;top:0;width:100%}a.gb_0:hover,a.gb_0:focus{text-decoration:none}a.gb_0:active{background-color:rgba(153,153,153,.4);text-decoration:none}a.gb_1{background-'
||'color:#4285f4;color:#fff}a.gb_1:active{background-color:#0043b2}.gb_2{-webkit-box-shadow:0 1px 1px rgba(0,0,0,.16);box-shadow:0 1px 1px rgba(0,0,0,.16)}.gb_0,.gb_1,.gb_3,.gb_4{display:inline-block;line-height:28px;padding:0 12px;-webkit-border-radius'
||':2px;border-radius:2px}.gb_3{background:#f8f8f8;border:1px solid #c6c6c6}.gb_4{background:#f8f8f8}.gb_3,#gb a.gb_3.gb_3,.gb_4{color:#666;cursor:default;text-decoration:none}#gb a.gb_4.gb_4{cursor:default;text-decoration:none}.gb_4{border:1px solid #4'
||'285f4;font-weight:bold;outline:none;background:#4285f4;background:-webkit-linear-gradient(top,#4387fd,#4683ea);background:linear-gradient(top,#4387fd,#4683ea);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#4387fd,endColorstr=#4683ea'
||',GradientType=0)}#gb a.gb_4.gb_4{color:#fff}.gb_4:hover{-webkit-box-shadow:0 1px 0 rgba(0,0,0,.15);box-shadow:0 1px 0 rgba(0,0,0,.15)}.gb_4:active{-webkit-box-shadow:inset 0 2px 0 rgba(0,0,0,.15);box-shadow:inset 0 2px 0 rgba(0,0,0,.15);background:#3'
||'c78dc;background:-webkit-linear-gradient(top,#3c7ae4,#3f76d3);background:linear-gradient(top,#3c7ae4,#3f76d3);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#3c7ae4,endColorstr=#3f76d3,GradientType=0)}.gb_Ba{display:none!important}.g'
||'b_Ca{visibility:hidden}.gb_cd{display:inline-block;vertical-align:middle}.gb_Bf{position:relative}.gb_D{display:inline-block;outline:none;vertical-align:middle;-webkit-border-radius:2px;border-radius:2px;-webkit-box-sizing:border-box;box-sizing:borde'
||'r-box;height:40px;width:40px;color:#000;cursor:pointer;text-decoration:none}#gb#gb a.gb_D{color:#000;cursor:pointer;text-decoration:none}.gb_Za{border-color:transparent;border-bottom-color:#fff;border-style:dashed dashed solid;border-width:0 8.5px 8.'
||'5px;display:none;position:absolute;left:11.5px;top:43px;z-index:1;height:0;width:0;-webkit-animation:gb__a .2s;animation:gb__a .2s}.gb_0a{border-color:transparent;border-style:dashed dashed solid;border-width:0 8.5px 8.5px;display:none;position:absol'
||'ute;left:11.5px;z-index:1;height:0;width:0;-webkit-animation:gb__a .2s;animation:gb__a .2s;border-bottom-color:#ccc;border-bottom-color:rgba(0,0,0,.2);top:42px}x:-o-prefocus,div.gb_0a{border-bottom-color:#ccc}.gb_F{background:#fff;border:1px solid #c'
||'cc;border-color:rgba(0,0,0,.2);color:#000;-webkit-box-shadow:0 2px 10px rgba(0,0,0,.2);box-shadow:0 2px 10px rgba(0,0,0,.2);display:none;outline:none;overflow:hidden;position:absolute;right:8px;top:62px;-webkit-animation:gb__a .2s;animation:gb__a .2s'
||';-webkit-border-radius:2px;border-radius:2px;-webkit-user-select:text}.gb_cd.gb_ma .gb_Za,.gb_cd.gb_ma .gb_0a,.gb_cd.gb_ma .gb_F,.gb_ma.gb_F{display:block}.gb_cd.gb_ma.gb_Cf .gb_Za,.gb_cd.gb_ma.gb_Cf .gb_0a{display:none}.gb_Df{position:absolute;right'
||':8px;top:62px;z-index:-1}.gb_Ka .gb_Za,.gb_Ka .gb_0a,.gb_Ka .gb_F{margin-top:-10px}.gb_cd:first-child,#gbsfw:first-child+.gb_cd{padding-left:4px}.gb_qa.gb_Te .gb_cd:first-child{padding-left:0}.gb_Ue{position:relative}.gb_Nc .gb_Ue,.gb_0d .gb_Ue{float'
||':right}.gb_D{padding:8px;cursor:pointer}.gb_qa .gb_4c:not(.gb_0):focus img{background-color:rgba(0,0,0,0.20);outline:none;-webkit-border-radius:50%;border-radius:50%}.gb_Ve button:focus svg,.gb_Ve button:hover svg,.gb_Ve button:active svg,.gb_D:focus'
||',.gb_D:hover,.gb_D:active,.gb_D[aria-expanded=true]{outline:none;-webkit-border-radius:50%;border-radius:50%}.gb_wc .gb_Ve.gb_We button:focus svg,.gb_wc .gb_Ve.gb_We button:focus:hover svg,.gb_Ve button:focus svg,.gb_Ve button:focus:hover svg,.gb_D:f'
||'ocus,.gb_D:focus:hover{background-color:rgba(60,64,67,0.1)}.gb_wc .gb_Ve.gb_We button:active svg,.gb_Ve button:active svg,.gb_D:active{background-color:rgba(60,64,67,0.12)}.gb_wc .gb_Ve.gb_We button:hover svg,.gb_Ve button:hover svg,.gb_D:hover{backg'
||'round-color:rgba(60,64,67,0.08)}.gb_ja .gb_D.gb_Na:hover{background-color:transparent}.gb_D[aria-expanded=true],.gb_D:hover[aria-expanded=true]{background-color:rgba(95,99,104,0.24)}.gb_D[aria-expanded=true] .gb_Xe,.gb_D[aria-expanded=true] .gb_Ze{fi'
||'ll:#5f6368;opacity:1}.gb_wc .gb_Ve button:hover svg,.gb_wc .gb_D:hover{background-color:rgba(232,234,237,0.08)}.gb_wc .gb_Ve button:focus svg,.gb_wc .gb_Ve button:focus:hover svg,.gb_wc .gb_D:focus,.gb_wc .gb_D:focus:hover{background-color:rgba(232,2'
||'34,237,0.10)}.gb_wc .gb_Ve button:active svg,.gb_wc .gb_D:active{background-color:rgba(232,234,237,0.12)}.gb_wc .gb_D[aria-expanded=true],.gb_wc .gb_D:hover[aria-expanded=true]{background-color:rgba(255,255,255,0.12)}.gb_wc .gb_D[aria-expanded=true] '
||'.gb_Xe,.gb_wc .gb_D[aria-expanded=true] .gb_Ze{fill:#ffffff;opacity:1}.gb_cd{padding:4px}.gb_qa.gb_Te .gb_cd{padding:4px 2px}.gb_qa.gb_Te .gb_Oa.gb_cd{padding-left:6px}.gb_F{z-index:991;line-height:normal}.gb_F.gb_0e{left:8px;right:auto}@media (max-w'
||'idth:350px){.gb_F.gb_0e{left:0}}.gb_1e .gb_F{top:56px}.gb_C .gb_D,.gb_E .gb_C .gb_D{background-position:-64px -29px}.gb_j .gb_C .gb_D{background-position:-29px -29px;opacity:1}.gb_C .gb_D,.gb_C .gb_D:hover,.gb_C .gb_D:focus{opacity:1}.gb_Hd{display:n'
||'one}.gb_Vc{font-family:Google Sans,Roboto,RobotoDraft,Helvetica,Arial,sans-serif;font-size:20px;font-weight:400;letter-spacing:.25px;line-height:48px;margin-bottom:2px;opacity:1;overflow:hidden;padding-left:16px;position:relative;text-overflow:ellips'
||'is;vertical-align:middle;top:2px;white-space:nowrap;-webkit-flex:1 1 auto;flex:1 1 auto}.gb_Vc.gb_Wc{color:#3c4043}.gb_qa.gb_ra .gb_Vc{margin-bottom:0}.gb_Xc.gb_Zc .gb_Vc{padding-left:4px}.gb_qa.gb_ra .gb_0c{position:relative;top:-2px}.gb_qa{color:bl'
||'ack;min-width:320px;position:relative;-webkit-transition:box-shadow 250ms;transition:box-shadow 250ms}.gb_qa.gb_Ec{min-width:240px}.gb_qa.gb_Id .gb_Jd{display:none}.gb_qa.gb_Id .gb_Kd{height:56px}header.gb_qa{display:block}.gb_qa svg{fill:currentColo'
||'r}.gb_Ld{position:fixed;top:0;width:100%}.gb_Md{-webkit-box-shadow:0 4px 5px 0 rgba(0,0,0,0.14),0 1px 10px 0 rgba(0,0,0,0.12),0 2px 4px -1px rgba(0,0,0,0.2);box-shadow:0 4px 5px 0 rgba(0,0,0,0.14),0 1px 10px 0 rgba(0,0,0,0.12),0 2px 4px -1px rgba(0,0'
||',0,0.2)}.gb_Nd{height:64px}.gb_qa:not(.gb_Ic) .gb_2c.gb_3c:not(.gb_Od):not(.gb_Pd),.gb_qa:not(.gb_Ic) .gb_Cd:not(.gb_Od):not(.gb_Pd),.gb_qa.gb_Qd .gb_2c.gb_3c.gb_Od,.gb_qa.gb_Qd .gb_Cd.gb_Od,.gb_qa.gb_Qd .gb_2c.gb_3c.gb_Pd,.gb_qa.gb_Qd .gb_Cd.gb_Pd{d'
||'isplay:none!important}.gb_Kd{-webkit-box-sizing:border-box;box-sizing:border-box;position:relative;width:100%;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-pack:space-between;-webkit-justify-content:space-between;justify-content:s'
||'pace-between;min-width:-webkit-min-content;min-width:min-content}.gb_qa:not(.gb_ra) .gb_Kd{padding:8px}.gb_qa.gb_Rd .gb_Kd{-webkit-flex:1 0 auto;flex:1 0 auto}.gb_qa .gb_Kd.gb_Sd.gb_Td{min-width:0}.gb_qa.gb_ra .gb_Kd{padding:4px;padding-left:8px;min-'
||'width:0}.gb_Jd{height:48px;vertical-align:middle;white-space:nowrap;-webkit-box-align:center;-webkit-align-items:center;align-items:center;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-user-select:none}.gb_Vd>.gb_Jd{display:table-cell'
||';width:100%}.gb_Xc{padding-right:30px;-webkit-box-sizing:border-box;box-sizing:border-box;-webkit-flex:1 0 auto;flex:1 0 auto}.gb_qa.gb_ra .gb_Xc{padding-right:14px}.gb_Wd{-webkit-flex:1 1 100%;flex:1 1 100%}.gb_Wd>:only-child{display:inline-block}.g'
||'b_Xd.gb_Oc{padding-left:4px}.gb_Xd.gb_Zd,.gb_qa.gb_Rd .gb_Xd,.gb_qa.gb_ra:not(.gb_0d) .gb_Xd{padding-left:0}.gb_qa.gb_ra .gb_Xd.gb_Zd{padding-right:0}.gb_qa.gb_ra .gb_Xd.gb_Zd .gb_ja{margin-left:10px}.gb_Oc{display:inline}.gb_qa.gb_Ic .gb_Xd.gb_1d,.g'
||'b_qa.gb_0d .gb_Xd.gb_1d{padding-left:2px}.gb_Vc{display:inline-block}.gb_Xd{-webkit-box-sizing:border-box;box-sizing:border-box;height:48px;line-height:normal;padding:0 4px;padding-left:30px;-webkit-flex:0 0 auto;flex:0 0 auto;-webkit-box-pack:flex-e'
||'nd;-webkit-justify-content:flex-end;justify-content:flex-end}.gb_0d{height:48px}.gb_qa.gb_0d{min-width:initial;min-width:auto}.gb_0d .gb_Xd{float:right;padding-left:32px}.gb_0d .gb_Xd.gb_2d{padding-left:0}.gb_3d{font-size:14px;max-width:200px;overflo'
||'w:hidden;padding:0 12px;text-overflow:ellipsis;white-space:nowrap;-webkit-user-select:text}.gb_4d{-webkit-transition:background-color .4s;transition:background-color .4s}.gb_5d{color:black}.gb_wc{color:white}.gb_qa a,.gb_Bc a{color:inherit}.gb_t{colo'
||'r:rgba(0,0,0,0.87)}.gb_qa svg,.gb_Bc svg,.gb_Xc .gb_6d,.gb_Nc .gb_6d{color:#5f6368;opacity:1}.gb_wc svg,.gb_Bc.gb_Fc svg,.gb_wc .gb_Xc .gb_6d,.gb_wc .gb_Xc .gb_vc,.gb_wc .gb_Xc .gb_0c,.gb_Bc.gb_Fc .gb_6d{color:rgba(255,255,255, .87 )}.gb_wc .gb_Xc .g'
||'b_uc:not(.gb_7d){opacity:.87}.gb_Wc{color:inherit;opacity:1;text-rendering:optimizeLegibility;-webkit-font-smoothing:antialiased}.gb_wc .gb_Wc,.gb_5d .gb_Wc{opacity:1}.gb_8d{position:relative}.gb_9d{font-family:arial,sans-serif;line-height:normal;pad'
||'ding-right:15px}a.gb_g,span.gb_g{color:rgba(0,0,0,0.87);text-decoration:none}.gb_wc a.gb_g,.gb_wc span.gb_g{color:white}a.gb_g:focus{outline-offset:2px}a.gb_g:hover{text-decoration:underline}.gb_h{display:inline-block;padding-left:15px}.gb_h .gb_g{di'
||'splay:inline-block;line-height:24px;vertical-align:middle}.gb_ae{font-family:Google Sans,Roboto,RobotoDraft,Helvetica,Arial,sans-serif;font-weight:500;font-size:14px;letter-spacing:.25px;line-height:16px;margin-left:10px;margin-right:8px;min-width:96'
||'px;padding:9px 23px;text-align:center;vertical-align:middle;-webkit-border-radius:4px;border-radius:4px;-webkit-box-sizing:border-box;box-sizing:border-box}.gb_qa.gb_0d .gb_ae{margin-left:8px}#gb a.gb_4.gb_4.gb_ae,#gb a.gb_3.gb_3.gb_ae{cursor:pointer'
||'}.gb_4.gb_ae:hover{background:#2b7de9;-webkit-box-shadow:0 1px 2px 0 rgba(66,133,244,0.3),0 1px 3px 1px rgba(66,133,244,0.15);box-shadow:0 1px 2px 0 rgba(66,133,244,0.3),0 1px 3px 1px rgba(66,133,244,0.15)}.gb_4.gb_ae:focus,.gb_4.gb_ae:hover:focus{ba'
||'ckground:#5094ed;-webkit-box-shadow:0 1px 2px 0 rgba(66,133,244,0.3),0 1px 3px 1px rgba(66,133,244,0.15);box-shadow:0 1px 2px 0 rgba(66,133,244,0.3),0 1px 3px 1px rgba(66,133,244,0.15)}.gb_4.gb_ae:active{background:#63a0ef;-webkit-box-shadow:0 1px 2p'
||'x 0 rgba(66,133,244,0.3),0 1px 3px 1px rgba(66,133,244,0.15);box-shadow:0 1px 2px 0 rgba(66,133,244,0.3),0 1px 3px 1px rgba(66,133,244,0.15)}.gb_ae:not(.gb_3){background:#1a73e8;border:1px solid transparent}.gb_qa.gb_ra .gb_ae{padding:9px 15px;min-wi'
||'dth:80px}.gb_be{text-align:left}#gb a.gb_ae.gb_3,#gb .gb_wc a.gb_ae,#gb.gb_wc a.gb_ae{background:#ffffff;border-color:#dadce0;-webkit-box-shadow:none;box-shadow:none;color:#1a73e8}#gb a.gb_4.gb_ka.gb_ce.gb_ae{background:#8ab4f8;border:1px solid trans'
||'parent;-webkit-box-shadow:none;box-shadow:none;color:#202124}#gb a.gb_ae.gb_3:hover,#gb .gb_wc a.gb_ae:hover,#gb.gb_wc a.gb_ae:hover{background:#f8fbff;border-color:#cce0fc}#gb a.gb_4.gb_ka.gb_ce.gb_ae:hover{background:#93baf9;-webkit-box-shadow:0 1p'
||'x 3px 1px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.3);box-shadow:0 1px 3px 1px rgba(0,0,0,0.15),0 1px 2px rgba(0,0,0,0.3)}#gb a.gb_ae.gb_3:focus,#gb a.gb_ae.gb_3:focus:hover,#gb .gb_wc a.gb_ae:focus,#gb .gb_wc a.gb_ae:focus:hover,#gb.gb_wc a.gb_ae:foc'
||'us,#gb.gb_wc a.gb_ae:focus:hover{background:#f4f8ff;border-color:#c9ddfc}#gb a.gb_4.gb_ka.gb_ce.gb_ae:focus,#gb a.gb_4.gb_ka.gb_ce.gb_ae:focus:hover{background:#a6c6fa;-webkit-box-shadow:none;box-shadow:none}#gb a.gb_ae.gb_3:active,#gb .gb_wc a.gb_ae'
||':active,#gb.gb_wc a.gb_ae:active{background:#ecf3fe}#gb a.gb_4.gb_ka.gb_ce.gb_ae:active{background:#a1c3f9;-webkit-box-shadow:0 1px 2px rgba(60,64,67,0.3),0 2px 6px 2px rgba(60,64,67,0.15);box-shadow:0 1px 2px rgba(60,64,67,0.3),0 2px 6px 2px rgba(60'
||',64,67,0.15)}#gb a.gb_ae.gb_3:not(.gb_ka):active{-webkit-box-shadow:0 1px 2px 0 rgba(60,64,67,0.3),0 2px 6px 2px rgba(60,64,67,0.15);box-shadow:0 1px 2px 0 rgba(60,64,67,0.3),0 2px 6px 2px rgba(60,64,67,0.15)}.gb_ja{background-color:rgba(255,255,255,'
||'0.88);border:1px solid #dadce0;-webkit-box-sizing:border-box;box-sizing:border-box;cursor:pointer;display:inline-block;max-height:48px;overflow:hidden;outline:none;padding:0;vertical-align:middle;width:134px;-webkit-border-radius:8px;border-radius:8p'
||'x}.gb_ja.gb_ka{background-color:transparent;border:1px solid #5f6368}.gb_la{display:inherit}.gb_ja.gb_ka .gb_la{background:#ffffff;-webkit-border-radius:4px;border-radius:4px;display:inline-block;left:8px;margin-right:5px;position:relative;padding:3p'
||'x;top:-1px}.gb_ja:hover{border:1px solid #d2e3fc;background-color:rgba(248,250,255,0.88)}.gb_ja.gb_ka:hover{border:1px solid #5f6368;background-color:rgba(232,234,237,0.08)}.gb_ja:focus{border:1px solid #fff;background-color:rgba(255,255,255);-webkit'
||'-box-shadow:0 1px 2px 0 rgba(60,64,67,0.3),0 1px 3px 1px rgba(60,64,67,0.15);box-shadow:0 1px 2px 0 rgba(60,64,67,0.3),0 1px 3px 1px rgba(60,64,67,0.15)}.gb_ja.gb_ka:focus{border:1px solid #e8eaed;background-color:#38383b}.gb_ja.gb_ka:active,.gb_ja.g'
||'b_ma.gb_ka:focus{border:1px solid #5f6368;background-color:#333438}.gb_na{display:inline-block;padding-left:7px;padding-bottom:2px;text-align:center;vertical-align:middle;line-height:32px;width:78px}.gb_ja.gb_ka .gb_na{line-height:26px;width:72px;pad'
||'ding-left:0;padding-bottom:0}.gb_na.gb_oa{background-color:#f1f3f4;-webkit-border-radius:4px;border-radius:4px;margin-left:8px;padding-left:0}.gb_na.gb_oa .gb_pa{vertical-align:middle}.gb_qa:not(.gb_ra) .gb_ja{margin-left:10px;margin-right:4px}.gb_sa'
||'{max-height:32px;width:78px}.gb_ja.gb_ka .gb_sa{max-height:26px;width:72px}.gb_Da{-webkit-background-size:32px 32px;background-size:32px 32px;border:0;-webkit-border-radius:50%;border-radius:50%;display:block;margin:0;position:relative;height:32px;wi'
||'dth:32px;z-index:0}.gb_Ea{background-color:#e8f0fe;border:1px solid rgba(32,33,36,.08);position:relative}.gb_Ea.gb_Da{height:30px;width:30px}.gb_Ea.gb_Da:hover,.gb_Ea.gb_Da:active{-webkit-box-shadow:none;box-shadow:none}.gb_Fa{background:#fff;border:'
||'none;-webkit-border-radius:50%;border-radius:50%;bottom:2px;-webkit-box-shadow:0 1px 2px 0 rgba(60,64,67,.30),0 1px 3px 1px rgba(60,64,67,.15);box-shadow:0 1px 2px 0 rgba(60,64,67,.30),0 1px 3px 1px rgba(60,64,67,.15);height:14px;margin:2px;position:'
||'absolute;right:0;width:14px}.gb_Ha{color:#1f71e7;font:400 22px/32px Google Sans,Roboto,RobotoDraft,Helvetica,Arial,sans-serif;text-align:center;text-transform:uppercase}@media (min-resolution:1.25dppx),(-o-min-device-pixel-ratio:5/4),(-webkit-min-dev'
||'ice-pixel-ratio:1.25),(min-device-pixel-ratio:1.25){.gb_Da::before{display:inline-block;-webkit-transform:scale(.5);transform:scale(.5);-webkit-transform-origin:left 0;transform-origin:left 0}.gb_Ia::before{display:inline-block;-webkit-transform:scal'
||'e(.5);transform:scale(.5);-webkit-transform-origin:left 0;transform-origin:left 0}.gb_l .gb_Ia::before{-webkit-transform:scale(0.416666667);transform:scale(0.416666667)}}.gb_Da:hover,.gb_Da:focus{-webkit-box-shadow:0 1px 0 rgba(0,0,0,.15);box-shadow:'
||'0 1px 0 rgba(0,0,0,.15)}.gb_Da:active{-webkit-box-shadow:inset 0 2px 0 rgba(0,0,0,.15);box-shadow:inset 0 2px 0 rgba(0,0,0,.15)}.gb_Da:active::after{background:rgba(0,0,0,.1);-webkit-border-radius:50%;border-radius:50%;content:'''';display:block;height'
||':100%}.gb_Ja{cursor:pointer;line-height:40px;min-width:30px;opacity:.75;overflow:hidden;vertical-align:middle;text-overflow:ellipsis}.gb_D.gb_Ja{width:auto}.gb_Ja:hover,.gb_Ja:focus{opacity:.85}.gb_Ka .gb_Ja,.gb_Ka .gb_La{line-height:26px}#gb#gb.gb_K'
||'a a.gb_Ja,.gb_Ka .gb_La{font-size:11px;height:auto}.gb_Ma{border-top:4px solid #000;border-left:4px dashed transparent;border-right:4px dashed transparent;display:inline-block;margin-left:6px;opacity:.75;vertical-align:middle}.gb_Na:hover .gb_Ma{opac'
||'ity:.85}.gb_ja>.gb_Oa{padding:3px 3px 3px 4px}.gb_Pa.gb_Ca{color:#fff}.gb_j .gb_Ja,.gb_j .gb_Ma{opacity:1}#gb#gb.gb_j.gb_j a.gb_Ja,#gb#gb .gb_j.gb_j a.gb_Ja{color:#fff}.gb_j.gb_j .gb_Ma{border-top-color:#fff;opacity:1}.gb_E .gb_Da:hover,.gb_j .gb_Da:'
||'hover,.gb_E .gb_Da:focus,.gb_j .gb_Da:focus{-webkit-box-shadow: 0 1px 0 rgba(0,0,0,.15) , 0 1px 2px rgba(0,0,0,.2) ;box-shadow: 0 1px 0 rgba(0,0,0,.15) , 0 1px 2px rgba(0,0,0,.2) }.gb_Qa .gb_Oa,.gb_Ra .gb_Oa{position:absolute;right:1px}.gb_Oa.gb_i,.g'
||'b_Sa.gb_i,.gb_Na.gb_i{-webkit-flex:0 1 auto;flex:0 1 auto;-webkit-flex:0 1 main-size;flex:0 1 main-size}.gb_Ta.gb_Ua .gb_Ja{width:30px!important}.gb_Va{height:40px;position:absolute;right:-5px;top:-5px;width:40px}.gb_Wa .gb_Va,.gb_Xa .gb_Va{right:0;t'
||'op:0}.gb_Oa .gb_D{padding:4px}.gb_ee{display:none}.gb_1c{display:none}.gb_1c.gb_ma{display:block}.gb_2c{background-color:#fff;-webkit-box-shadow:0 1px 0 rgba(0,0,0,0.08);box-shadow:0 1px 0 rgba(0,0,0,0.08);color:#000;position:relative;z-index:986}.gb'
||'_3c{height:40px;padding:16px 24px;white-space:nowrap}.gb_2c .gb_4c{border:0;font-weight:500;font-size:14px;line-height:36px;min-width:32px;padding:0 16px;vertical-align:middle}.gb_2c .gb_4c:before{content:'''';height:6px;left:0;position:absolute;top:-6'
||'px;width:100%}.gb_2c .gb_4c:after{bottom:-6px;content:'''';height:6px;left:0;position:absolute;width:100%}.gb_2c .gb_4c+.gb_4c{margin-left:8px}.gb_5c{height:48px;padding:4px;margin:-8px 0 0 -8px}.gb_6c{font-family:Roboto,RobotoDraft,Helvetica,Arial,san'
||'s-serif;overflow:hidden;vertical-align:top}.gb_3c .gb_6c{display:inline-block;padding-left:8px;width:640px}.gb_7c{background-color:inherit}.gb_3c .gb_7c{display:inline-block;position:absolute;top:18px;right:24px}.gb_7c .gb_8c{height:1.5em;margin:-.25'
||'em 10px -.25em 0;vertical-align:text-top;width:1.5em}.gb_9c{line-height:20px;font-size:16px;font-weight:700;color:rgba(0,0,0,.87)}.gb_3c .gb_9c,.gb_3c .gb_ad{width:640px}.gb_ad .gb_bd,.gb_ad{line-height:20px;font-size:13px;font-weight:400;color:rgba('
||'0,0,0,.54)}.gb_cd.gb_dd{padding:0}.gb_dd .gb_F{background:#ffffff;border:solid 1px transparent;-webkit-border-radius:8px;border-radius:8px;-webkit-box-sizing:border-box;box-sizing:border-box;padding:16px;right:16px;top:72px;-webkit-box-shadow:0 1px 2'
||'px 0 rgba(65,69,73,0.3),0 3px 6px 2px rgba(65,69,73,0.15);box-shadow:0 1px 2px 0 rgba(65,69,73,0.3),0 3px 6px 2px rgba(65,69,73,0.15)}.gb_dd .gb_F.gb_ed{right:60px;top:48px}.gb_dd .gb_F.gb_fd{top:62px}a.gb_gd{color:#5f6368!important;font-size:22px;he'
||'ight:24px;opacity:1;padding:8px;position:absolute;right:8px;top:8px;text-decoration:none!important;width:24px}a.gb_gd:focus,a.gb_gd:active,a.gb_gd:focus:hover{background-color:#e8eaed;-webkit-border-radius:50%;border-radius:50%;outline:none}a.gb_gd:h'
||'over{background-color:#f1f3f4;-webkit-border-radius:50%;border-radius:50%;outline:none}svg.gb_hd{fill:#5f6368;opacity:1}.gb_id{padding:0;white-space:normal;display:table}.gb_dd .gb_4:active{outline:none;-webkit-box-shadow:0 4px 5px rgba(0,0,0,.16);bo'
||'x-shadow:0 4px 5px rgba(0,0,0,.16)}.gb_0.gb_jd.gb_kd{-webkit-border-radius:4px;border-radius:4px;-webkit-box-sizing:border-box;box-sizing:border-box;cursor:pointer;height:36px;font-family:Google Sans,Roboto,RobotoDraft,Helvetica,Arial,sans-serif;font'
||'-size:14px;font-weight:500;letter-spacing:.25px;line-height:16px;min-width:70px;outline:none;text-transform:none;-webkit-font-smoothing:antialiased}.gb_0.gb_ld.gb_kd{-webkit-border-radius:4px;border-radius:4px;-webkit-box-sizing:border-box;box-sizing'
||':border-box;cursor:pointer;height:36px;color:#5f6368;font-family:Google Sans,Roboto,RobotoDraft,Helvetica,Arial,sans-serif;font-size:14px;font-weight:500;letter-spacing:.25px;line-height:16px;min-width:70px;outline:none;padding:8px 6px;text-transform'
||':none;-webkit-font-smoothing:antialiased}.gb_0.gb_jd.gb_kd{background:white;border:1px solid #dadce0;color:#1a73e8;margin-top:21px;padding:9px 7px}.gb_0.gb_jd.gb_kd:hover{background-color:rgba(26,115,232,0.04)}.gb_0.gb_jd.gb_kd:focus,.gb_0.gb_jd.gb_k'
||'d:focus:hover{background-color:rgba(26,115,232,0.12);border:solid 1px #1a73e8}.gb_0.gb_jd.gb_kd:active{background-color:rgba(26,115,232,0.1);border-color:transparent}.gb_0.gb_ld:hover{background-color:#f8f9fa}.gb_0.gb_ld:focus,.gb_0.gb_ld:hover:focus'
||'{background-color:#f1f3f4;border-color:transparent}.gb_0.gb_ld:active{background-color:#f1f3f4;-webkit-box-shadow:0 1px 2px 0 rgba(60,64,67,0.3),0 1px 3px 1px rgba(60,64,67,0.15);box-shadow:0 1px 2px 0 rgba(60,64,67,0.3),0 1px 3px 1px rgba(60,64,67,0'
||'.15)}.gb_bd{color:#5f6368;font-family:Roboto,RobotoDraft,Helvetica,Arial,sans-serif;font-size:14px;letter-spacing:.25px;line-height:20px;margin:0;margin-bottom:5px}.gb_md{text-align:right;font-size:14px;padding-bottom:0;white-space:nowrap}.gb_md .gb_'
||'nd,.gb_md .gb_od{margin-left:12px;text-transform:none}a.gb_4.gb_nd:hover{background-color:#2b7de9;border-color:transparent;-webkit-box-shadow:0 1px 2px 0 rgba(66,133,244,0.3),0 1px 3px 1px rgba(66,133,244,0.15);box-shadow:0 1px 2px 0 rgba(66,133,244,'
||'0.3),0 1px 3px 1px rgba(66,133,244,0.15)}a.gb_4.gb_nd:focus,a.gb_4.gb_nd:hover:focus{background-color:#5094ed;border-color:transparent;-webkit-box-shadow:0 1px 2px 0 rgba(66,133,244,0.3),0 1px 3px 1px rgba(66,133,244,0.15);box-shadow:0 1px 2px 0 rgba'
||'(66,133,244,0.3),0 1px 3px 1px rgba(66,133,244,0.15)}a.gb_4.gb_nd:active{background-color:#63a0ef;-webkit-box-shadow:0 1px 2px 0 rgba(66,133,244,0.3),0 1px 3px 1px rgba(66,133,244,0.15);box-shadow:0 1px 2px 0 rgba(66,133,244,0.3),0 1px 3px 1px rgba(6'
||'6,133,244,0.15)}.gb_md .gb_kd.gb_nd img{background-color:inherit;-webkit-border-radius:initial;border-radius:initial;height:18px;margin:0 8px 0 4px;vertical-align:text-top;width:18px}.gb_pd .gb_id .gb_qd .gb_kd{border:2px solid transparent}.gb_id .gb'
||'_qd .gb_kd:focus:after,.gb_id .gb_qd .gb_kd:hover:after{background-color:transparent}.gb_rd{color:#3c4043;font-family:Google Sans,Roboto,RobotoDraft,Helvetica,Arial,sans-serif;font-size:16px;font-weight:500;letter-spacing:.1px;line-height:20px;margin'
||':0;margin-bottom:12px}.gb_bd a.gb_td{text-decoration:none;color:#5e97f6}.gb_bd a.gb_td:visited{color:#5e97f6}.gb_bd a.gb_td:hover,.gb_bd a.gb_td:active{text-decoration:underline}.gb_ud{position:absolute;background:transparent;top:-999px;z-index:-1;vi'
||'sibility:hidden;margin-top:1px;margin-left:1px}#gb .gb_dd{margin:0}.gb_dd .gb_4c{background:#4d90fe;border:2px solid transparent;-webkit-box-sizing:border-box;box-sizing:border-box;font-weight:500;margin-top:21px;min-width:70px;text-align:center;-web'
||'kit-font-smoothing:antialiased}.gb_dd a.gb_4{background:#1a73e8;-webkit-border-radius:4px;border-radius:4px;color:#ffffff;font-family:Google Sans,Roboto,RobotoDraft,Helvetica,Arial,sans-serif;font-size:14px;font-weight:500;letter-spacing:.25px;line-h'
||'eight:16px;padding:8px 22px;-webkit-font-smoothing:antialiased}.gb_dd.gb_vd .gb_F{background-color:#fce8e6}.gb_dd.gb_wd a.gb_nd,.gb_dd.gb_vd a.gb_nd{background-color:#d93025}.gb_dd.gb_wd a.gb_nd:hover,.gb_dd.gb_vd a.gb_nd:hover{background-color:#cc31'
||'27;-webkit-box-shadow:0 -1px 5px rgba(128,134,139,0.09),0 3px 5px rgba(128,134,139,0.06),0 1px 2px rgba(60,64,67,0.3),0 1px 3px rgba(60,64,67,0.15);box-shadow:0 -1px 5px rgba(128,134,139,0.09),0 3px 5px rgba(128,134,139,0.06),0 1px 2px rgba(60,64,67,'
||'0.3),0 1px 3px rgba(60,64,67,0.15)}.gb_dd.gb_wd a.gb_nd:focus,.gb_dd.gb_vd a.gb_nd:focus{background-color:#b3332c;-webkit-box-shadow:none;box-shadow:none}.gb_dd.gb_wd a.gb_nd:active,.gb_dd.gb_vd a.gb_nd:active{background-color:#a6342e;-webkit-box-sha'
||'dow:0 -2px 8px rgba(128,134,139,0.09),0 4px 8px rgba(128,134,139,0.06),0 1px 2px rgba(60,64,67,0.3),0 2px 6px rgba(60,64,67,0.15);box-shadow:0 -2px 8px rgba(128,134,139,0.09),0 4px 8px rgba(128,134,139,0.06),0 1px 2px rgba(60,64,67,0.3),0 2px 6px rgb'
||'a(60,64,67,0.15)}.gb_dd.gb_xd a.gb_4{float:right}#gb .gb_dd a.gb_4c.gb_4c{color:#ffffff;cursor:pointer}.gb_dd .gb_4c:hover{background:#357ae8;border-color:#2f5bb7}.gb_yd,.gb_qd{display:table-cell}.gb_yd{vertical-align:middle}.gb_yd img{height:48px;pa'
||'dding-left:4px;padding-right:20px;width:48px}.gb_qd{padding-left:13px;width:100%}.gb_dd .gb_qd{padding-top:4px;min-width:326px;padding-left:0;width:326px}.gb_dd.gb_zd .gb_qd{min-width:254px;width:254px}.gb_dd.gb_xd .gb_qd{padding-top:32px}.gb_Cd{colo'
||'r:#ffffff;font-size:13px;font-weight:bold;height:25px;line-height:19px;padding-top:5px;padding-left:12px;position:relative;background-color:#4d90fe}.gb_Cd .gb_Dd{color:#ffffff;cursor:default;font-size:22px;font-weight:normal;position:absolute;right:1'
||'2px;top:5px}.gb_Cd .gb_nd,.gb_Cd .gb_ld{color:#ffffff;display:inline-block;font-size:11px;margin-left:16px;padding:0 8px;white-space:nowrap}.gb_Ed{background:none;background-image:-webkit-gradient(linear,left top,left bottom,from(rgba(0,0,0,0.16)),to'
||'(rgba(0,0,0,0.2)));background-image:-webkit-linear-gradient(top,rgba(0,0,0,0.16),rgba(0,0,0,0.2));background-image:linear-gradient(top,rgba(0,0,0,0.16),rgba(0,0,0,0.2));background-image:-webkit-linear-gradient(top,rgba(0,0,0,0.16),rgba(0,0,0,0.2));bo'
||'rder-radius:2px;border:1px solid #dcdcdc;border:1px solid rgba(0,0,0,0.1);cursor:default!important;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#160000ff,endColorstr=#220000ff);text-decoration:none!important;-webkit-border-radius:2'
||'px}.gb_Ed:hover{background:none;background-image:-webkit-gradient(linear,left top,left bottom,from(rgba(0,0,0,0.14)),to(rgba(0,0,0,0.2)));background-image:-webkit-linear-gradient(top,rgba(0,0,0,0.14),rgba(0,0,0,0.2));background-image:linear-gradient('
||'top,rgba(0,0,0,0.14),rgba(0,0,0,0.2));background-image:-webkit-linear-gradient(top,rgba(0,0,0,0.14),rgba(0,0,0,0.2));border:1px solid rgba(0,0,0,0.2);box-shadow:0 1px 1px rgba(0,0,0,0.1);-webkit-box-shadow:0 1px 1px rgba(0,0,0,0.1);filter:progid:DXIm'
||'ageTransform.Microsoft.gradient(startColorstr=#14000000,endColorstr=#22000000)}.gb_Ed:active{box-shadow:inset 0 1px 2px rgba(0,0,0,0.3);-webkit-box-shadow:inset 0 1px 2px rgba(0,0,0,0.3)}.gb_qa .gb_0{color:#4285f4}.gb_qa .gb_1{color:#fff}.gb_qa .gb_4'
||'c:not(.gb_Re):focus{outline:none}sentinel{}.z1asCe{display:inline-block;fill:currentColor;height:24px;line-height:24px;position:relative;width:24px}.z1asCe svg{display:block;height:100%;width:100%}</style>'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20220921120311'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26597157282737963)
,p_plug_name=>'ASEGURADORAS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26043357085473838)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'ASEGURADORAS'
,p_include_rowid_column=>true
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'ASEGURADORAS'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_header=>unistr('<h2><p style="font-family:verdana; color:red; size:70px"> COMPA\00D1\00CDAS DE SEGUROS <p></h2>')
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(26597629379737964)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:RP:P7_ID:\#ID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ADMIN'
,p_internal_uid=>17810685374776510
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26597723242737970)
,p_db_column_name=>'COMPANIA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Compania'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26597953387737984)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26598357145737984)
,p_db_column_name=>'NOMBRE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'NOMBRE'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26598820226737985)
,p_db_column_name=>'ABREV'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'SIGLAS'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26599238720737985)
,p_db_column_name=>'DIRECCION'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'DIRECCION'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26599633359737986)
,p_db_column_name=>'TELEFONO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'TELEFONO'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26599953393737986)
,p_db_column_name=>'ESTADO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'ESTADO'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(27688163000493833)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(23389825808582667)
,p_db_column_name=>'ROWID'
,p_display_order=>17
,p_column_identifier=>'H'
,p_column_label=>'Rowid'
,p_column_type=>'OTHER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(26602706734743047)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'178158'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COMPANIA:ID:NOMBRE:ABREV:DIRECCION:TELEFONO:ESTADO:ROWID'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(26602073406737997)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(26597157282737963)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(26107812107473922)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'CREAR'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:7'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26601129992737995)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(26597157282737963)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26601624787737996)
,p_event_id=>wwv_flow_imp.id(26601129992737995)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(26597157282737963)
);
wwv_flow_imp.component_end;
end;
/
