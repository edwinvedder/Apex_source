prompt --application/pages/page_00068
begin
--   Manifest
--     PAGE: 00068
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>68
,p_name=>'ESTACIONES'
,p_alias=>'ESTACIONES'
,p_step_title=>'ESTACIONES/CABINAS'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.sq {',
'  border: 10px solid #642850;',
'  height: 100px;',
'  width: 100px;',
'  position: relative;',
'  margin-top: 100px;',
'}',
'.tl {',
'  position: absolute;',
'  top: -33px;',
'  left: -36px;',
'  border-left: 10px solid #642850;',
'  border-top: 10px solid #642850;',
'  height: 76px;',
'  width: 76px;',
'  transform: rotate(45deg);',
'  -webkit-transform: rotate(45deg);',
'  -moz-transform: rotate(45deg);',
'  -o-transform: rotate(45deg);',
'  transform-origin: 100% 100%;',
'}',
'.tarje {',
'  background-color: #f8d3c0;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'KADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230921145019'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11073988979161106)
,p_plug_name=>'ESTACIONES'
,p_region_template_options=>'#DEFAULT#'
,p_region_attributes=>'background-color=&color.'
,p_plug_template=>wwv_flow_imp.id(26020060573473803)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "ID",',
'       "DESCRIPCION",',
'       "DETALLE",',
'       "TIPO",',
'       "DURACION_DEFAULT",',
'       "COLOR",',
'       "POSICION_VISUAL",',
'       "ESTADO",',
'       "DOCUMENTO",',
'       ( select l1."NOMBRE" from "DOCUMENTOS" l1 where l1."ID" = m."DOCUMENTO") "DOCUMENTO_L$1"',
'from "ESTADO_ORDEN" m',
'where "TIPO" IN (''1'',''2'')'))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P68_ORDER_BY", "orderBys": [{"key":"DESCRIPCION","expr":"\"DESCRIPCION\" asc"},{"key":"DETALLE","expr":"\"DETALLE\" asc"}]}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(11074484637161112)
,p_region_id=>wwv_flow_imp.id(11073988979161106)
,p_layout_type=>'FLOAT'
,p_card_css_classes=>'tarje'
,p_title_adv_formatting=>false
,p_title_column_name=>'DESCRIPCION'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'DETALLE'
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'<E>Duraci&oacute;n:&nbsp;</E>&DURACION_DEFAULT.<I>h</I>'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-home'
,p_icon_position=>'START'
,p_icon_description=>'&DESCRIPCION.'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(10174979841960130)
,p_card_id=>wwv_flow_imp.id(11074484637161112)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Editar'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:69:&SESSION.::&DEBUG.::P69_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_action_css_classes=>'tarje'
,p_is_hot=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11074920990161118)
,p_name=>'P68_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11073988979161106)
,p_item_default=>'DESCRIPCION'
,p_prompt=>'Ordenar Por'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC2:Nombre;DESCRIPCION,Posici\00F3n;POSICION_VISUAL')
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp.component_end;
end;
/
