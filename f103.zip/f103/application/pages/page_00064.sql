prompt --application/pages/page_00064
begin
--   Manifest
--     PAGE: 00064
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>64
,p_name=>'ESTACIONES DE LA ORDEN'
,p_alias=>'ESTACIONES-DE-LA-ORDEN'
,p_step_title=>'ESTACIONES DE LA ORDEN'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(26133504368474187)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<meta http-equiv="refresh" content="&P0_REFRESH.">',
''))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function drop_over_handle(evt) {',
'   evt.preventDefault();',
'}',
'',
'function drag_handle(evt) {',
'   evt.dataTransfer.setData("Text",evt.target.id);',
'}',
'',
'function drop_handle(obj,evt) {',
'   evt.preventDefault(evt);',
'   var data=evt.dataTransfer.getData("Text");',
'   evt.target.appendChild(document.getElementById(data));',
'   $x("P47_ID").value = data;    ',
'   $x("P47_ORDEN").value = obj.id;    ',
'    ',
'   apex.server.process ( "GUARDA_BIEN", { pageItems: "#P47_ID, #P47_ORDEN" });',
'   apex.region(''P1_ESTADOS'').refresh();',
'   location.reload();',
'}',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.dropdiv {',
'   border: 2px solid #838383;',
'   box-shadow: 3px 3px 3px #BDBEBD;',
'   border-radius: 5px 5px 5px 5px;',
'   display: block;',
'   min-height: 300px;',
'   padding: 16px;',
'   text-decoration: none;',
'   margin-right: 10px;',
'   width: 100%;',
'}',
'',
'.dropdiv:hover {',
'   -webkit-transform: translateY(-6px);',
'   -ms-transform: translateY(-6px);',
'   transform: translateY(-6px);',
'}',
'',
'.dropdiv h1 {',
'    font: bold 16px/16px Helvetica, Arial, Sans-serif;',
'    text-shadow: 0px -1px 2px rgba(0, 0, 0, 0.5);',
'    margin: 0px;',
'    text-align: center;',
'    line-height: 35px;',
'    border-radius: 20px;',
'    background-color: #f1f1f1;',
'    overflow: visible;',
'    text-overflow: ellipsis;',
'    white-space: nowrap;',
'}',
'',
'.dropdiv-new-item-region {',
'    clear: both;',
'}',
'',
'.dropdiv-new-card {',
'    float: left;',
'    text-align: center;',
'    margin: 3px 10px 10px 10px;',
'    transition: all 0.3s cubic-bezier(.25, .8, .25, 1);',
'    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);',
'    background: #55c555;',
'}',
'',
'.dropdiv-new-card:hover {',
'    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23);',
'}',
'',
'.dropdiv-new-card i {',
'    font-size: 14px;',
'    line-height: 28px;',
'    width: 28px;',
'    height: 28px;',
'    color: white;',
'}',
'',
'/* CSS code for the div to be dragged */',
'.dnddiv {',
'    display: inline-block;',
'    width: 100%;',
'    box-shadow: 0 1px 4px 0 rgba(0, 0, 0, 0.44);',
'    border-radius: 1px;',
'    color: rgba(0, 0, 0, 0.87);',
'    transition: all 0.4s ease;',
'    background: #f7e18b;',
'    position: relative;',
'    overflow: hidden;',
'/*    cursor: pointer;*/',
'    cursor: grab;',
'    margin-bottom: 8px;',
'}',
'',
'.dnddiv:hover {',
'    background: rgb(240, 165, 61);',
'    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23);',
'    /*cursor: grabbing;*/',
'}',
'',
'.dnddiv .card-content .img_lnk {',
'    height: 40px;',
'    line-height: 40px;',
'    border-radius: 20px;',
'    background-color: #f1f1f1;',
'    overflow: hidden;',
'    text-overflow: ellipsis;',
'    white-space: nowrap; ',
'    padding-right: 4px;',
'}',
'',
'.dnddiv .card-content .img_lnk:hover {',
'    overflow: visible;',
'}',
'',
'.dnddiv .card-content .img_lnk img{',
'    float: left;',
'    height: 40px;',
'    width: 40px;',
'    padding: 0px 4px;',
'    border-radius: 50%;',
'    margin-right: 10px;',
'    background: #f1f1f1;',
'}',
'',
'.dnddiv .card-header {',
'    float: left;',
'    text-align: center;',
'    margin: 6px 0px 6px 6px;',
'    box-shadow: 0 12px 20px -10px rgba(230, 230, 230, 0.28), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgba(230, 230, 230, 0.2);',
'    transition: all 1.0s ease;',
'}',
'',
'.dnddiv .card-header i {',
'    font-size: 18px;',
'    line-height: 28px;',
'    width: 28px;',
'    height: 28px;',
'    /*color: white;*/',
'    transition: all 1.0s ease;',
'}',
'',
'.dnddiv .card-title {',
'    text-align: left;',
'    padding: 0 6px;',
'    overflow: hidden;',
'    min-height: 40px;',
'    display: table;',
'    margin-top: 10px;',
'}',
'',
'.dnddiv .card-content {',
'    font-size: 10px;',
'    margin: 0 20px 6px;',
'    padding-top: 3px;',
'    border-top: 1px solid #eeeeee;',
'    color: #999999;',
'}',
'.tooltip {',
'  position: relative;',
'  display: inline-block;',
'  border-bottom: 1px dotted black; /* If you want dots under the hoverable text */',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(26132915190474180)
,p_page_component_map=>'10'
,p_last_updated_by=>'KADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230920145036'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161272201713145569)
,p_plug_name=>'ESTADO DE LA ORDEN'
,p_region_name=>'P1_ESTADOS'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26045265164473840)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Declare',
'   Vloop number := 1;',
'   cursor c_proc is',
'   select ''<div class="dropdiv" id="''||id||''" ondrop="drop_handle(this,event)" ',
'                  ondragover="drop_over_handle(event)">',
'                      <h1><a href="''||apex_util.prepare_url(''f?p=&APP_ID.:51:'' || :app_session || ''::::P51_ORDEN:'' || id) ||''">'' ||a.descripcion|| ''</a></h1><br> ',
'                     <div class="dropdiv-new-item-region" style="cursor: default;">',
'                        <a href="''||apex_util.prepare_url(''f?p=&APP_ID.:16:'' || :app_session)||''">',
'                           <div class="dropdiv-new-card" style="cursor: pointer;">',
'                              <i class="fa fa-plus"></i>',
'                           </div> ',
'                        </a>',
'              </div>'' dropproc, a.id, a.color',
'   from estado_orden a, estados_orden_repa b',
'     where a.id = b.eorden_id',
'       and b.eorid > 0',
'       and b.orden_id = :P64_ID',
'   order by secuencia;',
'',
'   cursor c_task (b_noord in varchar, colore in varchar) is',
'   select ''<div id="''||t.id||''" class="dnddiv" draggable="true"',
'                  ondragstart="drag_handle(event)"> ',
'                  <div class="card-header">',
'                     <i class="fa fa-car" style="color:black;background:''||colore||''"></i>',
'                  </div>',
'                  <div class="card-title">',
'                     <p>''||t.referencia1||''</p>',
'                  </div> ',
'                  <div class="card-content">',
'                     <div>',
'                        <div class="img_lnk">',
'                            <a href="'' || apex_util.prepare_url(''f?p=&APP_ID.:32:'' || :app_session || ''::::P0_RCOTIZA:'' || to_number(t.id)) || ''">',
'                                 <div style="cursor: pointer;">',
'                                    <img src="#APP_FILES#useradmin.png"/>'' ||p.nombre ||'' - ''||t.referencia1|| ''',
'                                 </div> ',
'                            </a>                       ',
'                       </div>',
'                    <div>',
'                       <p>''||c.nombre||''-''||pro.descripcion||''</p>',
'                    </div>',
'                 </div>',
'             </div>',
'          </div>'' dragline',
'   from ordenes_reparacion t, clientes c, productos pro, personal p, oficios_personal po',
'   where t.id = :P64_ID',
'     --and t.estado = b_noord ',
'     and TRAE_ESTADO_ORDEN(t.id) = b_noord ',
'     and t.cliente_id=c.id',
'     and t.producto_id=pro.id',
'     and pro.id > 0',
'     and t.personal_resp=p.id',
'     and p.id=po.personal_id',
'     and po.oficio_id in (select para_valor from parametros where para_nombre=''OFICIOS_SUPERVISORES'');',
' actual boolean;',
' inforastro varchar2(100);',
'',
'begin',
'   --Use a HTML table to format the output',
'   sys.htp.print(''<table>'');',
'   sys.htp.print(''<tr>'');',
'   for r_sdlc in c_proc',
'      loop',
'      actual:=FALSE;',
'      sys.htp.print(''<td>'');',
'      sys.htp.print(r_sdlc.dropproc);',
'      for r_task in c_task(r_sdlc.id,r_sdlc.color)',
'      loop',
'         sys.htp.print(r_task.dragline);',
'         actual:=TRUE;',
'      end loop;',
'      if not actual then',
'        select trae_info_rastro(:P64_ID,r_sdlc.id) into inforastro from dual;',
'        sys.htp.print(''<i>''||inforastro||''</i>'');',
'      end if;',
'      sys.htp.print(''</td>'');',
'      if Vloop = 4 then   -- Print Nth columns per row',
'         Vloop := 1;',
'         sys.htp.print(''</tr>'');',
'      else',
'         Vloop := Vloop + 1;',
'      end if;   ',
'   end loop;',
'   sys.htp.print(''</tr>'');',
'   sys.htp.print(''</table>'');',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161272950940145600)
,p_name=>'P64_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(161272201713145569)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161273022893145601)
,p_name=>'P64_ORDEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(161272201713145569)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161274518419145616)
,p_name=>'P64_HORA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(161272201713145569)
,p_pre_element_text=>'<h1>'
,p_post_element_text=>'</h1>'
,p_source=>'TO_CHAR(SYSDATE,''Dy DD Mon HH24:MI:SS'') || '' Orden#''||:P64_ID'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style=''border:0;color:red;'''
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10379446645018545)
,p_name=>'SetValores'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.dnddiv'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mouseup'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10379920592018547)
,p_event_id=>wwv_flow_imp.id(10379446645018545)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'drop_handle()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10380462230018548)
,p_event_id=>wwv_flow_imp.id(10379446645018545)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10379058102018543)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GUARDA_BIEN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'',
'BEGIN',
'begin',
'    CAMBIAR_ESTADO_PROC(:P64_ID,:P64_ORDEN); ',
'    exception when others then',
'    htp.prn(''{"Mierror": "'' || SQLERRM || ''"}'');',
'end;',
'  /* update ordenes_reparacion set estado = :P64_ORDEN',
'   where id = :P64_ID; */',
'-- Eliminate "Error: SyntaxError: Unexpected end of JSON input"',
'   apex_json.open_object;  ',
'   apex_json.write(''success'', true);  ',
'   apex_json.close_object; ',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No puede avanzar!'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Avanzando!'
,p_internal_uid=>10379058102018543
);
wwv_flow_imp.component_end;
end;
/
