prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>21
,p_name=>'IMPRIME COTIZACION'
,p_alias=>'IMPRIME-ORDENES'
,p_step_title=>'IMPRIME COTIZACION'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20210427173303'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31297667505629446)
,p_plug_name=>'Imprime Ordenes'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26043357085473838)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select COMPANIA,',
'       ID,',
'       FECHA,',
'       PRODUCTO_ID,',
'       ( select l.DESCRIPCION from PRODUCTOS l where l.ID = m.PRODUCTO_ID) PRODUCTO_ID_L$1,',
'       CANTIDAD_PRODUCTO,',
'       CLIENTE_ID,',
'       ( select l.APELLIDOS from CLIENTES l where l.ID = m.CLIENTE_ID) CLIENTE_ID_L$2,',
'       TIPO_FACTURACION,',
'       FECHA_VGARANTIA,',
'       ESTADO,',
'       NOTAS,',
'       REFERENCIA1,',
'       REFERENCIA2,',
'       NUMPOLIZA,',
'       NUMRECLAM,',
'       ASEGURADORA_ID,',
'       ( select l.NOMBRE from ASEGURADORAS l where l.ID = m.ASEGURADORA_ID) ASEGURADORA_ID_L$3,',
'       VDESDE,',
'       VHASTA',
'from ORDENES_REPARACION m',
'where ESTADO = ''A'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Imprime Ordenes'
,p_plug_header=>unistr('<H1><p style="font-family:verdana; color:red; size:80px">COTIZACI\00D3N<p></H1>')
,p_plug_footer=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p style="font-family:verdana; color:red; size:10px"> Click en el estado para Imprimir <p>',
''))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(31297804605629446)
,p_name=>'Imprime Ordenes'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>22510860600667992
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31298180095629471)
,p_db_column_name=>'COMPANIA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Compania'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31298587862629486)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31298924161629486)
,p_db_column_name=>'FECHA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'FECHA'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31299263866629487)
,p_db_column_name=>'PRODUCTO_ID'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Producto Id'
,p_display_in_default_rpt=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31299702766629487)
,p_db_column_name=>'PRODUCTO_ID_L$1'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'REPARAR'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31300118130629488)
,p_db_column_name=>'CANTIDAD_PRODUCTO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'CANTIDAD'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31300506961629488)
,p_db_column_name=>'CLIENTE_ID'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'CLIENTE'
,p_display_in_default_rpt=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(29396386790725854)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31300938007629489)
,p_db_column_name=>'CLIENTE_ID_L$2'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Cliente Id'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31301260517629489)
,p_db_column_name=>'TIPO_FACTURACION'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Tipo Facturacion'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31301664501629490)
,p_db_column_name=>'FECHA_VGARANTIA'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fecha Vgarantia'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31302060909629490)
,p_db_column_name=>'ESTADO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'ESTADO'
,p_column_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::P0_RCOTIZA:#ID#'
,p_column_linktext=>'#ESTADO#'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(29396572569739555)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31302460607629491)
,p_db_column_name=>'NOTAS'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Notas'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31302915233629491)
,p_db_column_name=>'REFERENCIA1'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Referencia1'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31303334395629492)
,p_db_column_name=>'REFERENCIA2'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Referencia2'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31303692538629492)
,p_db_column_name=>'NUMPOLIZA'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Numpoliza'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31304056958629493)
,p_db_column_name=>'NUMRECLAM'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Numreclam'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31304509527629493)
,p_db_column_name=>'ASEGURADORA_ID'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Aseguradora Id'
,p_display_in_default_rpt=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31304910677629494)
,p_db_column_name=>'ASEGURADORA_ID_L$3'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Aseguradora Id'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31305281064629494)
,p_db_column_name=>'VDESDE'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Vdesde'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31305725440629495)
,p_db_column_name=>'VHASTA'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Vhasta'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(31309895979643722)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'225230'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FECHA:PRODUCTO_ID_L$1:CANTIDAD_PRODUCTO:CLIENTE_ID:ESTADO:'
);
wwv_flow_imp.component_end;
end;
/
