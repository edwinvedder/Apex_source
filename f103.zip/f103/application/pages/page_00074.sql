prompt --application/pages/page_00074
begin
--   Manifest
--     PAGE: 00074
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>74
,p_name=>'ENVIAR COTIZACION'
,p_alias=>'ENVIAR-COTIZACION'
,p_page_mode=>'MODAL'
,p_step_title=>'ENVIAR COTIZACION'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_comment=>'FROM https://www.javainhand.com/2020/04/upload-image-into-local-directory-in-oracle-apex.html'
,p_page_component_map=>'16'
,p_last_updated_by=>'KADMIN'
,p_last_upd_yyyymmddhh24miss=>'20231113214644'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47489039588347463)
,p_plug_name=>unistr('Adjuntar y Enviar Cotizaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Region--accent1:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(26045265164473840)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_plug_display_column=>3
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p class="mensaje" >Primero debe seleccionar la Cotizaci&oacute;n, luego adjuntar el archivo de la factura en formato PDF.  Luego presionar -Enviar- para colocar en la bandeja de salida hacia el cliente.</p>',
'<p class="mensaje" >',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17807265280861234)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(47489039588347463)
,p_button_name=>'SUBELOA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(26107898604473922)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Adjuntar'
,p_icon_css_classes=>'fa-paperclip'
,p_button_cattributes=>'style="background-color:#ffb366;"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17807667570861235)
,p_button_sequence=>35
,p_button_plug_id=>wwv_flow_imp.id(47489039588347463)
,p_button_name=>'SUBELOB'
,p_button_static_id=>'sendb'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(26107898604473922)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar'
,p_confirm_message=>'Desea enviar esta Factura?'
,p_confirm_style=>'warning'
,p_icon_css_classes=>'fa-send'
,p_button_cattributes=>'style="background-color:green;"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17808048151861235)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(47489039588347463)
,p_button_name=>'Cierralo'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(26107898604473922)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancelar'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-window-close'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40102305968842648)
,p_name=>'P74_COTID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(47489039588347463)
,p_prompt=>unistr('Cotizaci\00F3n')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'COTIZACIONES_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT O.ID CODIGO,  C.NOMBRE||'' ''||C.APELLIDOS || ''(#'' || TO_CHAR(O.ID) ||''-''|| TO_CHAR(O.FECHA,''DD/MON/YYYY'')||'')'' MICOT FROM COTIZACION O, CLIENTES C',
'WHERE O.COMPANIA=:P0_CIA AND O.ESTADO IN (''A'',''B'')',
'  AND C.ID=O.CLIENTE_ID'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40102706421842649)
,p_name=>'P74_MIA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(47489039588347463)
,p_prompt=>unistr('Seleccione Cotizaci\00F3n PDF')
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_11=>'application/pdf'
,p_attribute_12=>'INLINE'
,p_attribute_13=>unistr('Cotizaci\00F3n')
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40103119749842650)
,p_name=>'P74_NOMBRE'
,p_item_sequence=>25
,p_item_plug_id=>wwv_flow_imp.id(47489039588347463)
,p_prompt=>'Archivo adjunto:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'P74_NOMBRE'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17810344657861244)
,p_name=>'Cancela'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(17808048151861235)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17810856126861244)
,p_event_id=>wwv_flow_imp.id(17810344657861244)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P74_COTID,P74_MIA,P74_NOMBRE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17811319064861244)
,p_event_id=>wwv_flow_imp.id(17810344657861244)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17809584737861237)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'EnviaMail'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' DECLARE',
'  L_BFILE  BFILE;',
'  L_BLOB   BLOB;',
'  MIDIR VARCHAR2(20) := ''SUBELO_DIR'';',
'  NOMBREA VARCHAR2(255);',
'  L_DEST_OFFSET INTEGER := 1;',
'  L_SRC_OFFSET  INTEGER := 1;',
'  MIDOCID NUMBER:=SEQ_DOCS.NEXTVAL;',
'  l_placeholders CLOB;  ',
'  elcorreo  NUMBER;',
'BEGIN',
'/*  SELECT BLOB_CONTENT INTO L_BLOB FROM APEX_APPLICATION_TEMP_FILES',
'    WHERE NAME = :ARCHIVO; */',
'    NOMBREA:=:P74_NOMBRE;',
'     IF LENGTH(NOMBREA) = 0 THEN',
'      RAISE_APPLICATION_ERROR(-21001,''FAVOR SELECCIONAR EL ARCHIVO'');',
'    END IF;',
'INSERT INTO TEMP_TFILES (ID, DOCID, ARCHIVOE,ESTADO)',
'  VALUES (SEQ_GRAL.NEXTVAL, MIDOCID, EMPTY_BLOB(),''A'')',
'  RETURN ARCHIVOE INTO L_BLOB;',
'  L_BFILE := BFILENAME(MIDIR, NOMBREA);',
'',
'  DBMS_LOB.FILEOPEN(L_BFILE, DBMS_LOB.FILE_READONLY);',
'  -- loadfromfile deprecated.',
'  -- DBMS_LOB.loadfromfile(l_blob, l_bfile, DBMS_LOB.getlength(l_bfile));',
'  DBMS_LOB.LOADBLOBFROMFILE (',
'    DEST_LOB    => L_BLOB,',
'    SRC_BFILE   => L_BFILE,',
'    AMOUNT      => DBMS_LOB.LOBMAXSIZE,',
'    DEST_OFFSET => L_DEST_OFFSET,',
'    SRC_OFFSET  => L_SRC_OFFSET);',
'  DBMS_LOB.FILECLOSE(L_BFILE);',
'  --COMMIT;',
'   if :P74_COTID > 0 then',
'    for X in (select f.id mid,pr.descripcion producto, f.cliente_id, nombre||'' ''||apellidos nombref,',
'                substr(rnc_cedula,1,3)||''-''||substr(rnc_cedula,4,10)||''-''||substr(rnc_cedula,11,1) rnc,                ',
'                nvl(c.email,''noemail@koinos.com.do'') suemail, to_char(f.fecha,''DD/MM/YYYY'') mfecha, f.moneda, ',
'                info_moneda(f.moneda,''SIMBOLO'')||''$'' || to_char(trae_totalcot(f.id),''999,999,990.90'') fmonto,  ',
'                p.descripcion condicionp',
'            from cotizacion f, clientes c, productos pr, condiciones_pago p',
'            where f.compania=:P0_CIA and f.id=:P74_COTID              ',
'              and c.compania=f.compania and c.id=f.cliente_id and c.estado=''A''',
'              and pr.id = f.producto_id',
'              and p.idcondicion = f.idcondicion)',
'    loop',
'        apex_json.initialize_clob_output;',
'        apex_json.open_object;',
'        apex_json.write(''COT_NUMBER'',x.mid);',
'        apex_json.write(''EL_SERVICIO'',x.producto);',
'        apex_json.write(''FECHA_COTIZACION'',x.mfecha);',
'        apex_json.write(''CONDICION'',x.condicionp);',
'        apex_json.write(''MY_APPLICATION_LINK'',''www.koinos.com.do'');',
'        apex_json.write(''ASK_URL'',''www.koinos.com.do/#contact'');',
'        apex_json.write(''CUSTOMER_NAME'',x.nombref); ',
'        apex_json.write(''MONEDA'',x.moneda);',
'        apex_json.write(''MONTO_BRUTO'',x.fmonto); ',
'',
'',
'        apex_json.close_object;',
'        l_placeholders := apex_json.get_clob_output;',
'        elcorreo:= apex_mail.send ( ',
'            p_from              => ''soporte@koinos.com.do'',',
'            p_to                 => x.suemail,',
'            p_template_static_id => ''COTIZA_EMAIL'',',
'            p_placeholders       => l_placeholders );',
'    end loop;',
'  else ',
unistr('    raise_application_error(-20111,''Debe seleccionar una cotizaci\00F3n!'');   '),
'  end if;    ',
'APEX_MAIL.ADD_ATTACHMENT(',
'p_mail_id => elcorreo,',
'p_attachment => L_BLOB,',
'p_filename => NOMBREA,',
'p_mime_type => ''application/pdf'');',
'COMMIT;',
'  :P74_NOMBRE:=NULL;  ',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Archivo no adjunto o error en correo!'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(17807667570861235)
,p_process_success_message=>'Correo Enviado!!'
,p_internal_uid=>17809584737861237
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17809910552861243)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SubeaDir'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'V_IMAGE APEX_APPLICATION_TEMP_FILES.BLOB_CONTENT%TYPE;',
'V_FILENAME APEX_APPLICATION_TEMP_FILES.FILENAME%TYPE;',
'NO_HAY_COTI EXCEPTION;',
'BEGIN',
'IF NVL(:P74_COTID,0) > 0 THEN',
'BEGIN',
'  SELECT BLOB_CONTENT,FILENAME INTO V_IMAGE,V_FILENAME',
'    FROM APEX_APPLICATION_TEMP_FILES',
'        WHERE UPPER(NAME)=UPPER(:P74_MIA);',
'  EXCEPTION WHEN NO_DATA_FOUND THEN',
'    V_IMAGE:=NULL;',
'    V_FILENAME:=NULL;',
'  WHEN OTHERS THEN',
'    V_IMAGE:=NULL;',
'    V_FILENAME:=NULL;',
'END;',
'ELSE ',
'RAISE NO_HAY_COTI;',
'APEX_ERROR.ADD_ERROR (',
' p_message  => ''Seleccione una cotizacion!'',',
'    p_display_location => apex_error.c_inline_in_notification );',
'END IF;',
'IF V_IMAGE IS NOT NULL AND V_FILENAME IS NOT NULL THEN',
'SAVEFILE(V_IMAGE,''SUBELO_DIR'',V_FILENAME);',
':P74_NOMBRE:=substr(:P74_MIA,instr(:P74_MIA,''/'',1,1)+1);',
'ELSE',
'APEX_ERROR.ADD_ERROR (',
' p_message  => ''Archivo No Cargado'',',
'p_display_location => apex_error.c_inline_in_notification );',
'END IF;',
'EXCEPTION WHEN NO_HAY_COTI THEN',
'  RAISE_APPLICATION_ERROR(-20002,''Debe seleccinar una cotizacion!'');',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(17807265280861234)
,p_internal_uid=>17809910552861243
);
wwv_flow_imp.component_end;
end;
/
