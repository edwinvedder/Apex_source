prompt --application/pages/page_00044
begin
--   Manifest
--     PAGE: 00044
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>44
,p_name=>'MOV_PRODUCTO'
,p_alias=>'MOV-PRODUCTO'
,p_step_title=>'MOVIMIENTO PRODUCTO'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_last_updated_by=>'KADMIN'
,p_last_upd_yyyymmddhh24miss=>'20231023154857'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(141687506530702740)
,p_name=>'MOVIMIENTOS PRODUCTO'
,p_template=>wwv_flow_imp.id(26045265164473840)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--accent2:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select ID,',
'       ID_MOVTO,',
'       ( select l.DESCRIPCION from MOVIMIENTOS_PRODUCTOS l where l.ID = m.ID_MOVTO) ID_MOVTO_L$1,',
'       ( select l.FECHA from MOVIMIENTOS_PRODUCTOS l where l.ID = m.ID_MOVTO) ID_MOVTO_L$2,',
'       ID_PRODUCTO,',
'       SERIE,',
'       UBICACION,',
'     CANTIDAD||(select nvl(siglas,''UND'') uni from PRODUCTOS p, UNIDADES u where p.id=m.id_producto and u.id=p.UNIDAD) CANTIDADES,',
'       COSTO',
'from MOVTOSP_DETALLE m',
'where ID > 0 and ID_PRODUCTO = :P44_PRODUCTO',
'  and ESTADO in (''A'',''E'',''G'')'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(26071555485473867)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'NO HAY MOVIMIENTOS'
,p_query_more_data=>'MAS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Descargar'
,p_prn_output=>'Y'
,p_prn_format=>'PDF'
,p_prn_output_link_text=>'Imprimir'
,p_prn_output_file_name=>'movimtos.pdf'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width_units=>'PERCENTAGE'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'MOVIMIENTOS PRODUCTO'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer=>'Movimientos de un producto'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141687920895702769)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141688343347702775)
,p_query_column_id=>2
,p_column_alias=>'ID_MOVTO'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141688647061702776)
,p_query_column_id=>3
,p_column_alias=>'ID_MOVTO_L$1'
,p_column_display_sequence=>30
,p_column_heading=>'Movimiento'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141689117709702776)
,p_query_column_id=>4
,p_column_alias=>'ID_MOVTO_L$2'
,p_column_display_sequence=>40
,p_column_heading=>'Fecha Movto.'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON-YYYY'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141689459159702776)
,p_query_column_id=>5
,p_column_alias=>'ID_PRODUCTO'
,p_column_display_sequence=>50
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141689932877702777)
,p_query_column_id=>6
,p_column_alias=>'SERIE'
,p_column_display_sequence=>60
,p_column_heading=>'Serie'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141690296654702777)
,p_query_column_id=>7
,p_column_alias=>'UBICACION'
,p_column_display_sequence=>70
,p_column_heading=>'Ubicaci&oacute;n'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(86293660607525290)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12384930357218550)
,p_query_column_id=>8
,p_column_alias=>'CANTIDADES'
,p_column_display_sequence=>52
,p_column_heading=>'Cantidades'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141691100196702778)
,p_query_column_id=>9
,p_column_alias=>'COSTO'
,p_column_display_sequence=>90
,p_column_heading=>'Costo'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135992337567802469)
,p_name=>'P44_PRODUCTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(141687506530702740)
,p_prompt=>'Producto'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'PRODUCTDOA_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT P.ID, P.DESCRIPCION||''(''||NVL(TRAE_CANTIDADP(P.ID),''0'')||'')''DESCRIPCION ',
'FROM PRODUCTOS P',
'WHERE P.COMPANIA=:P0_CIA AND P.TIPO in (1,3) AND P.ESTADO =''A''',
'',
'',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_icon_css_classes=>'fa-tools'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
