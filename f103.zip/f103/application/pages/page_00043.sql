prompt --application/pages/page_00043
begin
--   Manifest
--     PAGE: 00043
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>43
,p_name=>'EXISTENCIAS'
,p_alias=>'EXISTENCIAS'
,p_step_title=>'EXISTENCIAS'
,p_autocomplete_on_off=>'OFF'
,p_page_css_classes=>'#CSS_CANT_CLASSES#'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_last_updated_by=>'KADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230831165029'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(141487527501322040)
,p_name=>'EXISTENCIA DE PRODUCTOS'
,p_template=>wwv_flow_imp.id(26045265164473840)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--accent3:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select P.ID,',
'       REFERENCIA,',
'       DESCRIPCION,',
'       BARCODEN,',
'       CATEGORIA,',
'       TIPO,',
'       UNIDAD,',
'       COMPRAVENTA,',
'       COMBO,',
'       CANTIDAD_ACTUAL,(SELECT NVL(SUM(E.CANTIDAD),0) FROM EXISTENCIAS_PRODUCTOS E WHERE E.ID_PRODUCTO = P.ID) CUANTOS,',
'       CANTIDAD_MINIMA,',
'       CANTIDAD_MAXIMA,',
'       case',
'           when (SELECT NVL(SUM(E.CANTIDAD),0) FROM EXISTENCIAS_PRODUCTOS E WHERE E.ID_PRODUCTO = P.ID) <= (CANTIDAD_MINIMA) then ''u-danger-text''',
'           when (SELECT NVL(SUM(E.CANTIDAD),0) FROM EXISTENCIAS_PRODUCTOS E WHERE E.ID_PRODUCTO = P.ID) > (CANTIDAD_MAXIMA) then ''u-info-text''',
'           else ''u-normal-text''',
'       end as CSS_CANT_CLASSES,',
'       PESO,',
'       VOLUMEN,',
'       IMPUESTO_DEFAULTC,',
'       IMPUESTO_DEFAULTP,',
'       CUENTA_INGRESOS,',
'       CUENTA_GASTOS,',
'       PRECIO_COMPRA,',
'       PRECIO_VENTA,',
'       ESTADO,',
'       COMPANIA,',
'       COLOR,',
'       MONEDA,',
'       MARCAMOD_ID,',
'       ANOFAB_PROD,',
'       MODELO',
'  from PRODUCTOS P',
' where p.TIPO=:P43_TIPO AND P.ID >0',
'',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P43_TIPO'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(26071555485473867)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'NO EXISTEN REGISTROS'
,p_query_more_data=>'MAS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Descargar'
,p_prn_output=>'Y'
,p_prn_format=>'PDF'
,p_prn_output_link_text=>'Imprimir'
,p_prn_output_file_name=>'EXISTENCIA_ARCH.pdf'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width_units=>'PERCENTAGE'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'EXISTENCIA DE PRODUCTOS'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_sort_null=>'L'
,p_plug_query_exp_filename=>'EXISTENCIA_ARCH'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141487860103322052)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141488297360322057)
,p_query_column_id=>2
,p_column_alias=>'REFERENCIA'
,p_column_display_sequence=>20
,p_column_heading=>'Referencia'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141488648604322057)
,p_query_column_id=>3
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>30
,p_column_heading=>'Descripcion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141489121699322057)
,p_query_column_id=>4
,p_column_alias=>'BARCODEN'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141489482770322058)
,p_query_column_id=>5
,p_column_alias=>'CATEGORIA'
,p_column_display_sequence=>50
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141489895703322058)
,p_query_column_id=>6
,p_column_alias=>'TIPO'
,p_column_display_sequence=>60
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141490324607322058)
,p_query_column_id=>7
,p_column_alias=>'UNIDAD'
,p_column_display_sequence=>70
,p_column_heading=>'Unidad'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(28089634462897751)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141490655081322059)
,p_query_column_id=>8
,p_column_alias=>'COMPRAVENTA'
,p_column_display_sequence=>80
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141491138318322059)
,p_query_column_id=>9
,p_column_alias=>'COMBO'
,p_column_display_sequence=>90
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141491542836322059)
,p_query_column_id=>10
,p_column_alias=>'CANTIDAD_ACTUAL'
,p_column_display_sequence=>100
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(135992198139802468)
,p_query_column_id=>11
,p_column_alias=>'CUANTOS'
,p_column_display_sequence=>101
,p_column_heading=>'Cantidad Real'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span class="#CSS_CANT_CLASSES#">#CUANTOS#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141491860262322059)
,p_query_column_id=>12
,p_column_alias=>'CANTIDAD_MINIMA'
,p_column_display_sequence=>110
,p_column_heading=>'Cantidad Minima'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141492293553322060)
,p_query_column_id=>13
,p_column_alias=>'CANTIDAD_MAXIMA'
,p_column_display_sequence=>120
,p_column_heading=>'Cantidad Maxima'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(163287780097305162)
,p_query_column_id=>14
,p_column_alias=>'CSS_CANT_CLASSES'
,p_column_display_sequence=>280
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141492702970322060)
,p_query_column_id=>15
,p_column_alias=>'PESO'
,p_column_display_sequence=>130
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141493085842322060)
,p_query_column_id=>16
,p_column_alias=>'VOLUMEN'
,p_column_display_sequence=>140
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141493452410322063)
,p_query_column_id=>17
,p_column_alias=>'IMPUESTO_DEFAULTC'
,p_column_display_sequence=>150
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141493920512322063)
,p_query_column_id=>18
,p_column_alias=>'IMPUESTO_DEFAULTP'
,p_column_display_sequence=>160
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141494291188322063)
,p_query_column_id=>19
,p_column_alias=>'CUENTA_INGRESOS'
,p_column_display_sequence=>170
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141494670018322064)
,p_query_column_id=>20
,p_column_alias=>'CUENTA_GASTOS'
,p_column_display_sequence=>180
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141495140529322064)
,p_query_column_id=>21
,p_column_alias=>'PRECIO_COMPRA'
,p_column_display_sequence=>190
,p_column_heading=>'Precio Compra'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141495491028322064)
,p_query_column_id=>22
,p_column_alias=>'PRECIO_VENTA'
,p_column_display_sequence=>200
,p_column_heading=>'Precio Venta'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141495918951322065)
,p_query_column_id=>23
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>210
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(27688163000493833)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141496299460322065)
,p_query_column_id=>24
,p_column_alias=>'COMPANIA'
,p_column_display_sequence=>220
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141496658307322065)
,p_query_column_id=>25
,p_column_alias=>'COLOR'
,p_column_display_sequence=>230
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141497087753322065)
,p_query_column_id=>26
,p_column_alias=>'MONEDA'
,p_column_display_sequence=>240
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141497520776322066)
,p_query_column_id=>27
,p_column_alias=>'MARCAMOD_ID'
,p_column_display_sequence=>250
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141497899515322066)
,p_query_column_id=>28
,p_column_alias=>'ANOFAB_PROD'
,p_column_display_sequence=>260
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(141498280471322066)
,p_query_column_id=>29
,p_column_alias=>'MODELO'
,p_column_display_sequence=>270
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135992010261802466)
,p_name=>'P43_TIPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(141487527501322040)
,p_prompt=>'TIPO'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:ALMACENABLES;1,CONSUMIBLES;2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_icon_css_classes=>'fa-tools'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
