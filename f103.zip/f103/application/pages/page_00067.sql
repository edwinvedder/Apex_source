prompt --application/pages/page_00067
begin
--   Manifest
--     PAGE: 00067
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>67
,p_name=>'ORDEN INFO'
,p_alias=>'ORDEN-INFO'
,p_step_title=>'ORDEN INFO'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.usuar {',
'    font-family:verdana;',
'    font-size:8px;',
'    font-weight:bold;',
'}',
'',
'.negras {',
'    font-family:verdana;',
'    font-size:12px;',
'    font-weight:bold;',
'}',
'.tarje {',
'  background-color: #f8d3c0;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'KADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230922161804'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10175380539960134)
,p_plug_name=>'ORDENES'
,p_region_template_options=>'#DEFAULT#:t-Region--accent2:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(26045265164473840)
,p_plug_display_sequence=>15
,p_plug_grid_column_span=>6
,p_plug_display_column=>4
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(10175510614960136)
,p_name=>'GESTION'
,p_template=>wwv_flow_imp.id(26045265164473840)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--accent2:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_grid_column_span=>6
,p_display_column=>4
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'OBSERVACIONES'
,p_query_where=>'ID_ORDEN=:P67_ORDEN'
,p_include_rowid_column=>false
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P67_ORDEN'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(26071555485473867)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10175826325960139)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10175988535960140)
,p_query_column_id=>2
,p_column_alias=>'ID_ORDEN'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10176017598960141)
,p_query_column_id=>3
,p_column_alias=>'FECHA_HORA'
,p_column_display_sequence=>30
,p_column_heading=>'Fecha Hora'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON-YYYY HH24:MI:SS'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10176112003960142)
,p_query_column_id=>4
,p_column_alias=>'NOTA'
,p_column_display_sequence=>40
,p_column_heading=>'Nota'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<p  style="font-family:Sans-serif;font-size:10;font-weight:normal;">#NOTA#</P>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10176234139960143)
,p_query_column_id=>5
,p_column_alias=>'USUARIO'
,p_column_display_sequence=>50
,p_column_heading=>'Usuario'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(156287090169842267)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10175674188960137)
,p_plug_name=>'ESTACIONES'
,p_region_template_options=>'#DEFAULT#:t-Region--accent2:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(26045265164473840)
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>8
,p_plug_display_column=>3
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select EORID,',
'       ORDEN_ID,',
'       EORDEN_ID,',
'       (SELECT DESCRIPCION FROM ESTADO_ORDEN WHERE ID=EORDEN_ID) DESCRIPCION,',
'       SECUENCIA,',
'       INICIADA,',
'       FINALIZADA,',
'       CALIFICACION,',
'       ESTADO,',
'       CASE ',
'         WHEN TRAE_ESTADO_ORDEN(ORDEN_ID)=EORDEN_ID THEN ''negras''',
'         ELSE ''nada''',
'       END FORMATO',
'  from ESTADOS_ORDEN_REPA',
' where ORDEN_ID=:P67_ORDEN',
' order by SECUENCIA ASC'))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P67_ORDEN'
,p_plug_query_num_rows=>15
,p_attribute_01=>'ADVANCED_FORMATTING'
,p_attribute_05=>'<span class="&FORMATO.">&DESCRIPCION.<span>'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10175777032960138)
,p_plug_name=>'RASTRO'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26020060573473803)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       ID_ORDEN,',
'       ID_ESTORDEN,',
'       (SELECT DESCRIPCION FROM ESTADO_ORDEN WHERE ID=ID_ESTORDEN) ESTORDEN,       ',
'       FECHA,',
'       DURACION,',
'       EVALUACION,',
'       ESTADO,',
'       TRAE_INFO_RASTRO(ID_ORDEN,ID_ESTORDEN) DESCRIPCION',
'  from RASTRO_ORDEN',
' where ID_ORDEN=:P67_ORDEN',
' order by ID_ESTORDEN'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P67_ORDEN'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(10176398585960144)
,p_region_id=>wwv_flow_imp.id(10175777032960138)
,p_layout_type=>'GRID'
,p_card_css_classes=>'tarje'
,p_title_adv_formatting=>false
,p_title_column_name=>'ESTORDEN'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'DESCRIPCION'
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10175468715960135)
,p_name=>'P67_ORDEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10175380539960134)
,p_prompt=>'Orden'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ORDENES_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT O.ID OID, O.ID||''/''||P.DESCRIPCION||''-''||C.NOMBRE||'' ''||APELLIDOS ORDEN FROM PRODUCTOS P, CLIENTES C, ORDENES_REPARACION O',
'WHERE P.ID = O.PRODUCTO_ID',
'  AND C.ID = O.CLIENTE_ID',
'  AND O.COMPANIA = :P0_CIA',
'  AND O.ID > 0'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10176487628960145)
,p_name=>'REFRESCA'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P67_ORDEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10176557202960146)
,p_event_id=>wwv_flow_imp.id(10176487628960145)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10175510614960136)
);
wwv_flow_imp.component_end;
end;
/
