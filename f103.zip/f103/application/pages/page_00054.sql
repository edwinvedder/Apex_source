prompt --application/pages/page_00054
begin
--   Manifest
--     PAGE: 00054
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>54
,p_name=>'IMPRIMIR'
,p_alias=>'IMPRIMIR'
,p_step_title=>'IMPRIMIR'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'a {',
'  outline: none;',
'  text-decoration: none;',
'  padding: 2px 1px 0;',
'}',
'',
'a:link {',
'  color: blue;',
'}',
'',
'a:visited {',
'  color: purple;',
'}',
'',
'a:focus,',
'a:hover {',
'  border-bottom: 1px solid;',
'}',
'',
'a:active {',
'  color: red;',
'}',
'',
'a[href^="javascript"] {',
'  background: url("#APP_IMAGES#docpng.png") no-repeat 100% 0;',
'  background-size: 16px 16px;',
'  padding-right: 19px;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'10'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20221007121922'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(165387304473599051)
,p_plug_name=>'IMPRIMIR ORDENES'
,p_region_template_options=>'#DEFAULT#:t-Region--accent3:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(26045265164473840)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'CURSOR ORD1 IS select ''<tr ><td class=" u-tL" headers="C22511980156668032">''|| TO_CHAR(M.FECHA,''DD-MON-YYYY'')||''</td>',
'<td class=" u-tL" headers="C22512758761668033">'' ||( select l.DESCRIPCION from PRODUCTOS l where l.ID = M.PRODUCTO_ID)||''</td>',
'<td class=" u-tR" headers="C22513174125668034">''||M.CANTIDAD_PRODUCTO||''</td>',
'<td class=" u-tL" headers="C22513562956668034">''||( select l.NOMBRE||'' ''||l.APELLIDOS from CLIENTES l where l.ID = M.CLIENTE_ID)||''</td>',
'<td class=" u-tL" headers="C22515116904668036"><a title="''|| D.TITULO || ''" href="'' || apex_util.prepare_url(''f?p=&APP_ID.: ''||D.UPAGINA|| '':'' || :app_session || ''::::P0_RCOTIZA:'' || to_number(M.ID)) || ''" >''||(select l.DESCRIPCION from ESTADO_ORDEN '
||'l where l.ID= M.ESTADO)||''</a></td></tr>'' MDETALLE,',
'       M.COMPANIA,',
'       M.ID',
'from ORDENES_REPARACION M, ESTADO_ORDEN E, DOCUMENTOS D',
'where M.ID > 0 ',
'  and E.ID = M.ESTADO',
'  and E.ESTADO = ''A''',
'  and D.ID = E.DOCUMENTO',
'  and D.ESTADO =''A''',
'order by M.ID,M.FECHA ASC;',
'CUANTOS number;',
'BEGIN',
'  CUANTOS:=0;',
'  sys.htp.print(''<div id="R22510723500667992_chart" class="a-IRR-chartView"></div><div id="R22510723500667992_group_by" class="a-IRR-groupByView">',
'</div> <div id="R22510723500667992_pivot" class="a-IRR-pivotView"></div>',
'<div id="R22510723500667992_data_panel" class="a-IRR-reportView">',
'  <div class="a-IRR-tableContainer">'');',
'  sys.htp.print(''<table aria-label="Region = Ordenes, Report = Primary Default, View = Report, Displayed Rows Start = 1, Displayed Rows End = 1" class="a-IRR-table" id="22510860600667992">',
'<tr><th class="a-IRR-header u-tL" id="C22511980156668032"><a class="a-IRR-headerLink" data-column="22511980156668032" >FECHA</a></th><th class="a-IRR-header" id="C22512758761668033">',
'<a class="a-IRR-headerLink" data-column="22512758761668033" >REPARAR</a></th>',
'<th class="a-IRR-header u-tR" id="C22513174125668034"><a class="a-IRR-headerLink" data-column="22513174125668034" >CANTIDAD</a></th>',
'<th class="a-IRR-header" id="C22513562956668034"><a class="a-IRR-headerLink" data-column="22513562956668034" >CLIENTE</a></th>',
'<th class="a-IRR-header u-tL" id="C22515116904668036"><a class="a-IRR-headerLink" data-column="22515116904668036" >ESTADO</a></th></tr>'');',
'  FOR I IN ORD1 ',
'  LOOP',
'    sys.htp.print(I.MDETALLE);',
'    CUANTOS:=CUANTOS + 1;',
'  END LOOP;',
'  sys.htp.print(''</table></div>'');',
'  sys.htp.print(''<div class="a-IRR-paginationWrap a-IRR-paginationWrap--bottom"><ul class="a-IRR-pagination"><li aria-hidden="true" class="a-IRR-pagination-item is-disabled"></li>',
'<li class="a-IRR-pagination-item"><span class="a-IRR-pagination-label">Mostrando ''||CUANTOS||'' Ordenes </span></li><li aria-hidden="true" class="a-IRR-pagination-item is-disabled"></li></ul></div></div></div></div></div>',
'<div class="a-IRR-sortWidget" id="R22510723500667992_sort_widget" style="display:none;">',
'<ul class="a-IRR-sortWidget-actions" id="R22510723500667992_sort_widget_actions">',
'<li class="a-IRR-sortWidget-actions-item" id="R22510723500667992_sort_widget_action_up">',
'<button class="a-Button a-IRR-button a-IRR-sortWidget-button" type="button" title="Sort Ascending" data-option="up">',
'<span class="a-Icon icon-irr-sort-asc"></span></button></li>'');',
'',
'  sys.htp.print(''<li class="a-IRR-sortWidget-actions-item" id="R22510723500667992_sort_widget_action_down">',
'<button class="a-Button a-IRR-button a-IRR-sortWidget-button" type="button" title="Sort Descending" data-option="down">',
'<span class="a-Icon icon-irr-sort-desc"></span></button></li><li class="a-IRR-sortWidget-actions-item" id="R22510723500667992_sort_widget_action_hide">',
'<button class="a-Button a-IRR-button a-IRR-sortWidget-button" type="button" title="Hide Column" data-option="hide"><span class="a-Icon icon-irr-remove-col"></span></button></li>',
'<li class="a-IRR-sortWidget-actions-item" id="R22510723500667992_sort_widget_action_break"><button class="a-Button a-IRR-button a-IRR-sortWidget-button" type="button" title="Control Break" data-option="break">',
'<span class="a-Icon icon-irr-control-break"></span></button></li>',
'<li class="a-IRR-sortWidget-actions-item" id="R22510723500667992_sort_widget_action_help">',
'<button class="a-Button a-IRR-button a-IRR-sortWidget-button" type="button" title="Column Information" data-option="help">',
'<span class="a-Icon icon-irr-help"></span></button></li>',
'<li class="a-IRR-sortWidget-actions-item" id="R22510723500667992_sort_widget_action_computation">',
'<button class="a-Button a-IRR-button a-IRR-sortWidget-button" type="button" title="Compute" data-option="computation">',
'<span class="a-Icon icon-irr-calculator"></span></button></li></ul><div class="a-IRR-sortWidget-help" id="R22510723500667992_sort_widget_help"></div>',
'<div class="a-IRR-sortWidget-search" id="R22510723500667992_sort_widget_search">',
'<label for="R22510723500667992_sort_widget_search_field" class="a-IRR-sortWidget-searchLabel">',
'<span class="u-VisuallyHidden">Search</span></label><input id="R22510723500667992_sort_widget_search_field" class="a-IRR-sortWidget-searchField" type="text" placeholder="Filter..." />',
'<div class="a-IRR-sortWidget-rows" id="R22510723500667992_sort_widget_rows"></div></div></div></div>',
'<p style="font-family:verdana; color:red; size:8px">  *Click en el estado para Imprimir el documento correspondiente <p>'');',
'END;',
'',
''))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp.component_end;
end;
/
