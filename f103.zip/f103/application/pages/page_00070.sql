prompt --application/pages/page_00070
begin
--   Manifest
--     PAGE: 00070
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>70
,p_name=>'ADD_IMPUESTOS'
,p_alias=>'ADD-IMPUESTOS'
,p_page_mode=>'MODAL'
,p_step_title=>'ADD_IMPUESTOS'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'500'
,p_dialog_width=>'700'
,p_dialog_attributes=>'close: function(event, ui) {apex.navigation.dialog.close(true,{dialogPageId:27});}'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'KADMIN'
,p_last_upd_yyyymmddhh24miss=>'20231113150443'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34972080693971664)
,p_plug_name=>'DISPONIBLES'
,p_region_name=>'mylistview'
,p_region_template_options=>'#DEFAULT#:t-Region--accent4:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(26045265164473840)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>4
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID MID,',
'       DESCRIPCION,',
'       SIGLAS,',
'       PORCIENTO,',
'       VALOR,',
'       ESTADO',
'  from IMPUESTOS',
' where COMPANIA=:P0_CIA',
' order by ID'))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P70_DCOT,P70_ADD'
,p_plug_query_num_rows=>15
,p_plug_footer=>'Click para agregar impuesto.'
,p_attribute_01=>'ADVANCED_FORMATTING:INSET'
,p_attribute_03=>'span class="select-room"'
,p_attribute_04=>'data-id="&MID." '
,p_attribute_05=>'&SIGLAS.'
,p_attribute_16=>'javascript:$s(''P70_ADD'',''&MID.'')'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34972162504971665)
,p_plug_name=>'APLICAR'
,p_region_name=>'MILISTA2'
,p_region_template_options=>'#DEFAULT#:t-Region--accent7:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(26045265164473840)
,p_plug_display_sequence=>45
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>6
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D.DCOT_ID,',
'       D.ID NID,',
'       D.IMPUESTO_ID IID,',
'       I.SIGLAS DESCRIPCION',
'  from IMPUESTOS I',
'    inner join SOPORTE.DCOT_IMPUESTOS D',
'    on I.ID = D.IMPUESTO_ID and D.DCOT_ID=:P70_DCOT',
'',
'  '))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P70_DCOT'
,p_plug_query_num_rows=>15
,p_attribute_01=>'ADVANCED_FORMATTING:INSET'
,p_attribute_03=>'span class="select-imp"'
,p_attribute_04=>'data-id="&IID." '
,p_attribute_05=>'&DESCRIPCION.'
,p_attribute_16=>'javascript:$s(''P70_DEL'',''&IID.'')'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17791679402839874)
,p_button_sequence=>75
,p_button_name=>'Close'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(26107812107473922)
,p_button_image_alt=>'Close'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34973720673971718)
,p_name=>'P70_DCOT'
,p_item_sequence=>55
,p_item_default=>'37'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34973816987971719)
,p_name=>'P70_ADD'
,p_item_sequence=>65
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35301621988758322)
,p_name=>'P70_DEL'
,p_item_sequence=>85
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17793842576839882)
,p_name=>'CLICK_SELECTOR'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.select-room'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17794309617839885)
,p_event_id=>wwv_flow_imp.id(17793842576839882)
,p_event_result=>'TRUE'
,p_action_sequence=>5
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Desea incluir este impuesto?'
,p_attribute_02=>'Confirmar'
,p_attribute_06=>'Si'
,p_attribute_07=>'No'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17794844358839886)
,p_event_id=>wwv_flow_imp.id(17793842576839882)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin',
'  insert into dcot_impuestos',
'    values(:P70_DCOT,SEQ_UBICACION.NEXTVAL,:P70_ADD);',
'End;'))
,p_attribute_02=>'P70_ADD'
,p_attribute_03=>'P70_DCOT,P70_ADD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17795327494839886)
,p_event_id=>wwv_flow_imp.id(17793842576839882)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Listo!'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17795811916839887)
,p_event_id=>wwv_flow_imp.id(17793842576839882)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(34972162504971665)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17796281346839888)
,p_name=>'CLICK_SELECTOR_A'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.select-imp'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17796797203839888)
,p_event_id=>wwv_flow_imp.id(17796281346839888)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Desea eliminar este impuesto?'
,p_attribute_02=>'Confirmar'
,p_attribute_06=>'Si'
,p_attribute_07=>'No'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17797238370839888)
,p_event_id=>wwv_flow_imp.id(17796281346839888)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin',
'  delete from dcot_impuestos',
'    where dcot_id = :P70_DCOT',
'      and impuesto_id = :P70_DEL;',
'End;'))
,p_attribute_02=>'P70_DEL'
,p_attribute_03=>'P70_DCOT,P70_DEL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17797775445839889)
,p_event_id=>wwv_flow_imp.id(17796281346839888)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Listo!'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17798234689839889)
,p_event_id=>wwv_flow_imp.id(17796281346839888)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(34972162504971665)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17798601154839890)
,p_name=>'Cierralo'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(17791679402839874)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17799172780839890)
,p_event_id=>wwv_flow_imp.id(17798601154839890)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_attribute_01=>'P70_DCOT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17793498939839881)
,p_process_sequence=>5
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form GRABA IMP'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Registrado!'
,p_internal_uid=>17793498939839881
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17793077510839880)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'GRABACLOSE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(17791679402839874)
,p_process_success_message=>'Bien!'
,p_internal_uid=>17793077510839880
);
wwv_flow_imp.component_end;
end;
/
