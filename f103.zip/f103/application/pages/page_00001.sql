prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'RIPARA'
,p_autocomplete_on_off=>'OFF'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.intro',
'{',
'    background-color: orange;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20221011111050'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26141056649474321)
,p_plug_name=>'RIPARA'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_region_attributes=>'text-align: center'
,p_plug_template=>wwv_flow_imp.id(26035669003473833)
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<P style="font-family:Good times,verdana;">BIENVENIDO A RIPARA!',
unistr('UNA APLICACI\00D3N F\00C1CIL DE UTILIZAR Y CON UNA INTERFAZ NOVEDOSA Y AMIGABLE.</p>'),
'',
''))
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P0_CIA'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(163288491701305169)
,p_plug_name=>'BASE_LOGO'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26017058583473797)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<br><br>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(163288868373305173)
,p_plug_name=>'BASE_KOINOS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26017058583473797)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<br><br>'
,p_plug_footer=>'<div style="text-align: right;"><P style="font-family:verdana; color:#6699ff; vertical-align:bottom; size:4px;"> KOINOS, SRL (2022)</P></div><a href="http://koinos.com.do/"><img style="display: block; float: right; margin-right: 15px; width="80"; hei'
||'ght="30";" src="http://koinos.com.do/img/koinoslgo.png" alt="KOINOS, SRL"></a>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28200007934221867)
,p_name=>'P1_LOGO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(26141056649474321)
,p_source=>'#APP_IMAGES#logoht.jpg'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(163288786690305172)
,p_name=>'P1_FOTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(163288868373305173)
,p_item_default=>'#APP_IMAGES#htap1.png'
,p_post_element_text=>'<br><br>'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_attributes=>'style="display: block;  margin-left: auto;   margin-right: auto;  width: 20%;"'
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'URL'
,p_attribute_02=>'Equipo HT AutoPaint'
);
wwv_flow_imp.component_end;
end;
/
