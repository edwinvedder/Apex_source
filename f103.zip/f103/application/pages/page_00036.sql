prompt --application/pages/page_00036
begin
--   Manifest
--     PAGE: 00036
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>36
,p_name=>'ORDENES_ACTUALES'
,p_alias=>'ORDENES-ACTUALES'
,p_step_title=>'ORDENES_ACTUALES'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.tarjeta {',
'    background-color:#ffd9b3;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'KADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230925135726'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56489447783266971)
,p_plug_name=>'ORDENES PENDIENTES'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26045265164473840)
,p_plug_display_sequence=>20
,p_menu_id=>wwv_flow_imp.id(25990290661473704)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(26109219068473924)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(68487721206431137)
,p_plug_name=>'ORDENES_ACTUALES'
,p_region_template_options=>'t-CardsRegion--styleA'
,p_plug_template=>wwv_flow_imp.id(26020060573473803)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select o.id,p.descripcion||''-''||referencia reparar, o.fecha Entrada, c.nombre||'' ''||c.apellidos ecliente,',
' ''Entrega==>''||to_char(o.fecha_entrega,''dd/mm/yyyy'') Salida, ',
' (select descripcion from estado_orden where id= trae_estado_orden(o.id)) Estado',
' --decode(o.estado,''A'',''COTIZACION'',''B'',''EN PROCESO'',''C'',''ESPERA'') Estado',
' from ordenes_reparacion o',
'inner join productos p ',
'on p.id = o.producto_id',
'inner join clientes c',
'on c.id = o.cliente_id',
'and c.compania = o.compania',
'where o.compania = :P0_CIA ',
'  and o.estado in (select id from estado_orden where tipo in (trae_parametro(''MOVILIZAR'')))',
'order by salida'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(68488179236431149)
,p_region_id=>wwv_flow_imp.id(68487721206431137)
,p_layout_type=>'GRID'
,p_card_css_classes=>'tarjeta'
,p_title_adv_formatting=>false
,p_title_column_name=>'REPARAR'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'ECLIENTE'
,p_body_adv_formatting=>false
,p_body_column_name=>'SALIDA'
,p_second_body_adv_formatting=>false
,p_second_body_column_name=>'ESTADO'
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'ID'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56489549769266972)
,p_name=>'P36_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56489447783266971)
,p_pre_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_source=>'TO_CHAR(SYSDATE,''Dy DD Mon HH24:MI:SS'')'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'no-border;'
,p_tag_attributes=>'style=''color:red; position: center;'''
,p_field_template=>wwv_flow_imp.id(26106441111473911)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp.component_end;
end;
/
