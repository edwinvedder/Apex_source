prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page - Desktop'
,p_step_title=>'Global Page - Desktop'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20221008153828'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23389940471582668)
,p_plug_name=>'KOINOS-RIPARA'
,p_component_template_options=>'#DEFAULT#'
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_column=>1
,p_menu_id=>wwv_flow_imp.id(25990290661473704)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(26109219068473924)
,p_plug_header=>'<h2><p style="font-family:Arial; font-color:orange; size:70px;text-align: center;">HTAUTO PAINT</p></h2>'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23390035451582669)
,p_name=>'P0_CIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(23389940471582668)
,p_item_default=>'1'
,p_source=>'1'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28199667197221864)
,p_name=>'P0_RCOTIZA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(23389940471582668)
,p_item_default=>'13'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28200280902221870)
,p_name=>'P0_RFACTURA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(23389940471582668)
,p_item_default=>'13'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28200355990221871)
,p_name=>'P0_NCF'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(23389940471582668)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135992365533802470)
,p_name=>'P0_LOGUITO'
,p_item_sequence=>9
,p_item_plug_id=>wwv_flow_imp.id(23389940471582668)
,p_source=>'#APP_IMAGES#logopht.png'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_attributes=>'style="display: block;   margin-left: auto;   margin-right: auto;   width: 15%;"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'URL'
,p_attribute_02=>'LogoHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150896521912127099)
,p_name=>'P0_REFRESH'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(23389940471582668)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NVL(PARA_VALOR,120) REFRESCA FROM PARAMETROS',
'WHERE PARA_NOMBRE=''REFRESCAR_FORMA'''))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
