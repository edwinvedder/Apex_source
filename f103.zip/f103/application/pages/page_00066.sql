prompt --application/pages/page_00066
begin
--   Manifest
--     PAGE: 00066
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>66
,p_name=>'ESTADOS ORDEN'
,p_alias=>'ESTADOS-ORDEN'
,p_page_mode=>'MODAL'
,p_step_title=>'ESTADOS ORDEN'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.eactuales {',
'    color:blue;',
'    font-size:11px;',
'}'))
,p_step_template=>wwv_flow_imp.id(25994163552473748)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'KADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230925134815'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8494292403202214)
,p_plug_name=>'ESTACIONES/SERVICIOS'
,p_region_template_options=>'#DEFAULT#:t-Region--accent3:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(26045265164473840)
,p_plug_display_sequence=>20
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT B.EORID ',
' FROM ESTADOS_ORDEN_REPA B ',
'   WHERE  B.EORID > 0 AND ORDEN_ID=:P66_ORDENR'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10173200930960113)
,p_plug_name=>'ORDEN SERVICIO'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(26045265164473840)
,p_plug_display_sequence=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10173397622960114)
,p_plug_name=>'ESTACIONES ASIGNADAS'
,p_parent_plug_id=>wwv_flow_imp.id(10173200930960113)
,p_region_template_options=>'#DEFAULT#:t-Region--accent2:t-Region--stacked:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(26045265164473840)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>8
,p_plug_grid_column_css_classes=>'eactuales '
,p_plug_display_column=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT A.DESCRIPCION,B.EORID ',
' FROM ESTADO_ORDEN A, ESTADOS_ORDEN_REPA B ',
'   WHERE B.EORDEN_ID=A.ID AND B.EORID > 0 AND B.ORDEN_ID=:P66_ORDENR AND A.ESTADO=''A''',
'   ORDER BY B.SECUENCIA'))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P66_ORDENR'
,p_plug_query_num_rows=>5
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT B.EORID ',
' FROM ESTADOS_ORDEN_REPA B ',
'   WHERE  B.EORID > 0 AND ORDEN_ID=:P66_ORDENR'))
,p_attribute_02=>'DESCRIPCION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10172000987960101)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(8494292403202214)
,p_button_name=>'Grabar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(26107898604473922)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Grabar'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT B.EORID ',
' FROM ESTADOS_ORDEN_REPA B ',
'   WHERE  B.EORID > 0 AND ORDEN_ID=:P66_ORDENR'))
,p_button_condition_type=>'NOT_EXISTS'
,p_icon_css_classes=>'fa-save-as'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8497728685202249)
,p_name=>'P66_ORDENR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10173200930960113)
,p_prompt=>unistr('Orden Reparaci\00F3n')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT O.ID||''/''||P.DESCRIPCION||''-''||C.NOMBRE||'' ''||APELLIDOS ORDEN, O.ID OID FROM PRODUCTOS P, CLIENTES C, ORDENES_REPARACION O',
'WHERE P.ID = O.PRODUCTO_ID',
'  AND C.ID = O.CLIENTE_ID',
'  AND O.COMPANIA = :P0_CIA',
'  AND O.ID > 0'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P66_ORDENESTADO'
,p_ajax_items_to_submit=>'P66_ORDENESTADO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_tag_attributes=>'style="font-family: sans-serif;background-color:#ffe6e6;"'
,p_read_only_when=>'P66_ORDENR'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8497846720202250)
,p_name=>'P66_ORDENESTADO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(8494292403202214)
,p_prompt=>'Estaciones Disponibles'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion, id from estado_orden',
'where tipo in (select para_valor from parametros where para_nombre in (''MOVILIZAR''))',
'order by posicion_visual'))
,p_cHeight=>5
,p_colspan=>8
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'ALL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10173036946960111)
,p_name=>'LIMPIAR'
,p_event_sequence=>10
,p_bind_type=>'live'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10173114449960112)
,p_event_id=>wwv_flow_imp.id(10173036946960111)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Limpialo'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8494292403202214)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10172127782960102)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GUARDA_ESTADOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'CURSOR C_VALUES IS SELECT T.COLUMN_VALUE AS ESTACION FROM ',
'  TABLE (APEX_STRING.SPLIT(:P66_ORDENESTADO, '':'')) T',
'  WHERE T.COLUMN_VALUE IS NOT NULL;',
'',
'  CURSOR CHECK_FIRST IS SELECT ''x'' FROM ESTADOS_ORDEN_REPA WHERE EORID > 0 AND ORDEN_ID=:P66_ORDENR;',
'  X VARCHAR2(1);',
'  PROXIMO NUMBER(9);',
'  SEQ NUMBER(5):=0;',
'  BEGIN',
'    OPEN CHECK_FIRST;',
'    FETCH CHECK_FIRST INTO X;',
'    IF CHECK_FIRST%NOTFOUND THEN',
'      PROXIMO:= SEQ_GRAL.NEXTVAL;',
'      INSERT INTO ESTADOS_ORDEN_REPA (EORID,ORDEN_ID,EORDEN_ID,SECUENCIA,INICIADA,ESTADO)',
'        VALUES(PROXIMO,:P66_ORDENR,''0'',0,TO_DATE(TO_CHAR(SYSDATE,''DD/MM/YYYY HH24:MI''),''DD/MM/YYYY HH24:MI''),''P''); ',
'      FOR C IN C_VALUES ',
'      LOOP',
'        PROXIMO:= SEQ_GRAL.NEXTVAL;',
'        SEQ:=SEQ+1;',
'        INSERT INTO ESTADOS_ORDEN_REPA (EORID,ORDEN_ID,EORDEN_ID,SECUENCIA,ESTADO)',
'          VALUES(PROXIMO,:P66_ORDENR,C.ESTACION,SEQ,''P'');',
'      END LOOP;',
'     END IF;',
'    CLOSE CHECK_FIRST;',
'  END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>10172127782960102
);
wwv_flow_imp.component_end;
end;
/
