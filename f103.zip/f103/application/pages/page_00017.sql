prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>17
,p_name=>'EMPLEADOS'
,p_alias=>'EMPLEADOS'
,p_step_title=>'EMPLEADOS'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20220921121813'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30987893885361747)
,p_plug_name=>'EMPLEADOS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26020060573473803)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE||'' ''||APELLIDOS NOMBRES, ''CED.:''||ID_CEDULA||'' DIRECCION:''||DIRECCION ID_CEDULA,',
' DECODE(ESTADO,''A'',''ACTIVO'',''I'',''INACTIVO'',''N/A'') ESTADO',
'FROM PERSONAL',
'WHERE COMPANIA=:P0_CIA'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_plug_header=>'<H2><p style="font-family:verdana; color:red; size:70px">EMPLEADOS<p></H2>'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(30988369706361756)
,p_region_id=>wwv_flow_imp.id(30987893885361747)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'NOMBRES'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'ID_CEDULA'
,p_second_body_adv_formatting=>false
,p_second_body_column_name=>'ESTADO'
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'NOMBRES'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
);
wwv_flow_imp.component_end;
end;
/
