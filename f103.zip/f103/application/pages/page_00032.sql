prompt --application/pages/page_00032
begin
--   Manifest
--     PAGE: 00032
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>32
,p_name=>'LISTADO DE LABORES'
,p_alias=>'LISTADO-DE-LABORES'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'LISTADO DE LABORES'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'10'
,p_last_updated_by=>'KADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230831163029'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(55246836896628403)
,p_plug_name=>'LABORES'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(26016857078473795)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Declare',
' ',
'Begin',
'htp.p(''<style> ',
'table { ',
'    font-family: arial, sans-serif;',
'    border: 0px;',
'    border-collapse: collapse;',
'    width: 80%;',
'}',
'.tdetail {',
'  ',
'  border: 1px solid black;',
'  border-collapse: collapse;',
'  width: 80%;',
'}',
'}',
'td {',
'    border: 0px solid #000001;',
'    text-align: left;',
'    padding: 2px;',
'}',
'th {',
'    font-weight: bold;',
'    border: 0px solid #000001;',
'    text-align: left;',
'    padding: 4px;',
'}',
'tr: {',
'   background-color: #dddddd; ',
'}',
'.tab {',
'  padding-left: 8px;',
'}',
'</style>'');',
'',
'',
'',
'htp.p(''<table style="font-family: arial, sans-serif; font-size: 14;"><tr><th><font size="6" face="Courier New" >LABORES</font></th></tr><tr><td>&nbsp;</td></tr>',
'<tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr></table>'');',
'-- <table style="width: 100%;"><tr><th style="background-color:red";>&nbsp;<th></tr></table>'');',
'--INFO COMPANIA',
' for c in (select nombre, direccion,to_char(sysdate,''DD/MM/YYYY'') fechah, ''(''||substr(telefono_id,1,3)||'')''||''-''||substr(telefono_id,4,3)||''-''||substr(telefono_id,7,4) telefonof,rnc,emailp from compania',
'            where id=:P0_CIA)',
' loop',
'            htp.p(''<table style="width: 80%"><tr>',
'                     <td>''||htf.escape_sc(c.nombre)||''</td></tr>',
'                     <tr><td>''||htf.escape_sc(c.direccion)||''</td>',
'                     <td style="font-weight: bold;"> COTIZACION NO.</td></tr>',
'                     <tr><td>''||htf.escape_sc(c.telefonof)||''</td>',
'                     <td style="font-weight: bold; font-size: 120%;"> HT''||lpad(to_char(htf.escape_sc(:P0_RCOTIZA)),6,''0000'')||''</td></tr>',
'                     <tr><td>RNC ''||htf.escape_sc(c.rnc)||''</td>',
'                     <td style="font-weight: bold;">''||htf.escape_sc(c.fechah)||''</td></tr>',
'                     <tr><td>''||htf.escape_sc(c.emailp)||''</td></tr>',
'                     <tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr></table>'');',
'',
' end loop;',
' --INFO CLIENTE Y ORDEN',
' for o in (select id,producto_id,cliente_id from ordenes_reparacion',
'              where compania=:P0_CIA and id=:P0_RCOTIZA)',
' loop',
'   for c in (select nombre||'' ''||apellidos nombref,rnc_cedula rnc, direccion, ''(''||substr(telefonos,1,3)||'')''||''-''||substr(telefonos,4,3)||''-''||substr(telefonos,7,4) telefonof,nvl(email,''email'') email from clientes',
'              where compania=:P0_CIA and id=htf.escape_sc(o.cliente_id))',
'    loop',
'      for v in (select m.marca, mo.descripcion modelo, c.descripcion color, to_char(p.anofab_prod,''9999'') anofab, p.referencia chasis ',
'             from productos p, marca_modelo m, modelos mo, colores c',
'               where c.id = p.color',
'                 and m.id = p.marcamod_id',
'                 and mo.marcaid=m.id',
'                 and mo.id = marcamod_id',
'                 and p.compania=:P0_CIA ',
'                 and p.id=htf.escape_sc(o.producto_id))',
'        loop',
'            htp.p(''<table><tr><th>COTIZAR A:</th><th>VEHICULO:</th>',
'                     <tr><td>''||htf.escape_sc(c.nombref)||''</td>',
'                     <td>''||htf.escape_sc(v.marca)||''</td></tr>',
'                     <tr><td>''||htf.escape_sc(c.rnc)||''</td>',
'                     <td>''||htf.escape_sc(v.modelo)||''</td></tr>',
'                     <tr><td>''||htf.escape_sc(c.direccion)||''</td>',
'                     <td>''||htf.escape_sc(v.color)||''</td></tr>',
'                     <tr><td>''||htf.escape_sc(c.telefonof)||''</td>',
'                     <td>''||htf.escape_sc(v.anofab)||''</td><tr>',
'                     <tr><td>''||htf.escape_sc(c.email)||''</td>',
'                     </tr><tr><td>&nbsp;</td></tr></table>'');',
'        end loop;',
'    end loop;',
' end loop;',
'',
'htp.p(''<table class="tdetail"><tr class="tdetail"><th style="background-color:#FFFFF0">DESCRIPCION</th>',
'<th style="text-align:center; background-color:#FFFFF0">CANTIDAD</th>'');',
'',
' for x in (select de.id doid, p.descripcion producto, decode(p.tipo,1,''MATERIALES'',''LABOR'') tipo, de.cantidad cantidad',
'            from sintomas s, diagnosticos d, ordenes_detalle de, productos p',
'              where s.orden_id=:P0_RCOTIZA',
'                and s.codigo > 0',
'                and d.sintomas_id = s.codigo',
'                and d.codigo > 0                ',
'                and de.diag_id = d.codigo',
'                and de.id > 0 ',
'                and p.id = de.producto_id',
'                )',
' loop',
' ',
'htp.p(''<tr class="tdetail">',
'        <td>''||htf.escape_sc(x.producto)||''-''||htf.escape_sc(x.doid)||''(''||htf.escape_sc(x.tipo)||'')</td>',
'        <td style="text-align:center">''||htf.escape_sc(x.cantidad)||''</td>',
'         </tr>'');',
'for z in (select od.codigo, to_char(od.horas,''999.90'') horas, e.nombre||'' ''||apellidos responsablen, o.nombre oficio',
'            from dorden_responsable od, personal e, oficios o',
'              where o.id = od.tarea_oficio',
'                and e.id = od.personal_id',
'                and od.dorden_id = htf.escape_sc(x.doid))',
'    loop',
'         htp.p(''<tr><td><a style="font-family: arial, sans-serif; font-size: 70%;"><span class="tab">''||htf.escape_sc(z.responsablen)||''(**''||htf.escape_sc(z.oficio)||''**)</a></td>',
'         <td><a style="font-family: arial, sans-serif; font-size: 70%;">''||htf.escape_sc(z.horas)||''&bull;</a></td></tr>'');',
'    end loop;',
'end loop;',
'htp.p(''</table><table style="width: 80%"><tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr></table>'');',
'htp.p(''<table style="width: 80%;  font-size: 1;"><tr><td></td>Labores a realizar. HT AUTO PAINT 131927815 Santo Domingo Este, RD.</tr></table>'');',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp.component_end;
end;
/
