prompt --application/pages/page_00059
begin
--   Manifest
--     PAGE: 00059
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_page.create_page(
 p_id=>59
,p_name=>'GESTION_OBSERVACION'
,p_alias=>'GESTION-OBSERVACION'
,p_page_mode=>'MODAL'
,p_step_title=>'GESTION - OBSERVACION'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(167187290096964800)
,p_page_component_map=>'17'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20221221101805'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(254392605093326104)
,p_plug_name=>'GESTION-OBSERVACION'
,p_region_template_options=>'#DEFAULT#:t-Region--accent1:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(26045265164473840)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'OBSERVACIONES'
,p_query_where=>'ID_ORDEN=:P59_OID'
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'ID, FECHA_HORA'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>15
,p_plug_query_no_data_found=>unistr('Ninguna observaci\00F3n para mostrar')
,p_attribute_02=>'NOTA'
,p_attribute_06=>'USUARIO'
,p_attribute_08=>'FECHA_HORA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(236131822876143794)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(254392605093326104)
,p_button_name=>'Nueva'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(26107898604473922)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Nueva'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:60:&SESSION.::&DEBUG.::P60_ID_ORDEN:&P59_OID.'
,p_icon_css_classes=>'fa-newspaper-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236131657310143793)
,p_name=>'P59_OID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(254392605093326104)
,p_prompt=>'ORDEN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ORDENES_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT O.ID OID, O.ID||''/''||P.DESCRIPCION||''-''||C.NOMBRE||'' ''||APELLIDOS ORDEN FROM PRODUCTOS P, CLIENTES C, ORDENES_REPARACION O',
'WHERE P.ID = O.PRODUCTO_ID',
'  AND C.ID = O.CLIENTE_ID',
'  AND O.COMPANIA = :P0_CIA',
'  AND O.ID > 0'))
,p_cHeight=>1
,p_cattributes_element=>'style="font-weight:bold;color:blue"'
,p_tag_attributes=>'style="color:blue;"'
,p_read_only_when=>'P59_OID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(26106656428473915)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(236131901130143795)
,p_name=>'P59_MID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(254392605093326104)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
