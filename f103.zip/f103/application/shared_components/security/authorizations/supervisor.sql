prompt --application/shared_components/security/authorizations/supervisor
begin
--   Manifest
--     SECURITY SCHEME: Supervisor
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(167187290096964800)
,p_name=>'Supervisor'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'Supervisor'
,p_attribute_02=>'A'
,p_error_message=>unistr('Usted no esta autorizado para visualizar esta opci\00F3n, verifique los permisos y si su cuenta no ha sido bloqueada. Por favor contacte al administrador.')
,p_reference_id=>0
,p_caching=>'NOCACHE'
);
wwv_flow_imp.component_end;
end;
/
