prompt --application/shared_components/user_interface/lovs/tipos_productos_lov
begin
--   Manifest
--     TIPOS_PRODUCTOS_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(20009223861160431)
,p_lov_name=>'TIPOS_PRODUCTOS_LOV'
,p_lov_query=>'.'||wwv_flow_imp.id(20009223861160431)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(20009465561160437)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'ALMACENABLE'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(20009935218160442)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'CONSUMIBLES'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(20010312453160442)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'SERVICIOS'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(20010680557160443)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'REPARABLES'
,p_lov_return_value=>'4'
);
wwv_flow_imp.component_end;
end;
/
