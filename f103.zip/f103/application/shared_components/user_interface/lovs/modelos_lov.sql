prompt --application/shared_components/user_interface/lovs/modelos_lov
begin
--   Manifest
--     MODELOS_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(81487091029436929)
,p_lov_name=>'MODELOS_LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT O.ID CODIGO, M.MARCA||''/''||O.DESCRIPCION  NOMBRE FROM MARCA_MODELO M, MODELOS O',
'  WHERE M.ID=O.MARCAID',
'   AND M.ESTADO = ''A''',
'   AND O.ID > 0',
'   AND O.ESTADO=''A''',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'MODELOS'
,p_return_column_name=>'CODIGO'
,p_display_column_name=>'NOMBRE'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
