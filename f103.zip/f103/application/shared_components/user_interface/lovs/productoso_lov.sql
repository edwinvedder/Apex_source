prompt --application/shared_components/user_interface/lovs/productoso_lov
begin
--   Manifest
--     PRODUCTOSO_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>103
,p_default_id_offset=>8786944004961454
,p_default_owner=>'REPARA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(29398642472801495)
,p_lov_name=>'PRODUCTOSO_LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID, DESCRIPCION||''/''||REFERENCIA PRODN FROM PRODUCTOS',
'WHERE COMPANIA=:P0_CIA AND TIPO=4 AND ESTADO =''A'' '))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'PRODN'
,p_default_sort_column_name=>'PRODN'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
