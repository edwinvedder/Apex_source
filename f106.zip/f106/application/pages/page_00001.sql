prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'SOPORTE'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230612095248'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15415310850168994)
,p_plug_name=>'ORDENES SOPORTE TECNICO'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15284322995168657)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>'<footer>Desarrollado por KOINOS, SRL</footer>'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(19981998582117447)
,p_name=>'Actividades Pendientes'
,p_template=>wwv_flow_imp.id(15253424549168634)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'hidden-xs-down'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'REGION_POSITION_05'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT O.ID ORDENID, TO_CHAR(O.FECHA,''DD/MM/YYYY'') OFECHA, S.CODIGO SINTOMAS, D.CODIGO DIAGNOS, OD.ID DORDENID, OD.PRODUCTO_ID LABOR, DR.PERSONAL_ID, DR.CODIGO TAREA, ',
'DR.TAREA_OFICIO OFICIO, DR.ESTADO',
'  FROM ORDENES_SOPORTE O, SINTOMAS S, DIAGNOSTICOS D, ORDENES_DETALLE OD, DORDEN_RESPONSABLE DR',
'  WHERE O.COMPANIA = :P0_CIA',
'    AND O.ID > 0',
'    AND O.ESTADO_TECNICO IN (''A'',''R'')',
'    AND S.ORDEN_ID = O.ID',
'    AND D.SINTOMAS_ID = S.CODIGO',
'    AND OD.DIAG_ID = D.CODIGO',
'    AND DR.DORDEN_ID = OD.ID',
'    AND DR.PERSONAL_ID IN (SELECT ID FROM PERSONAL WHERE USUARIO IN (SELECT COALESCE(v(''APP_USER''), USER)FROM DUAL))',
'    AND DR.ESTADO IN (1,2,3)'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P0_CIA'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(15344021115168715)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19982132460117448)
,p_query_column_id=>1
,p_column_alias=>'ORDENID'
,p_column_display_sequence=>10
,p_column_heading=>'Orden Soporte'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(16643685659340106)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19983921025117466)
,p_query_column_id=>2
,p_column_alias=>'OFECHA'
,p_column_display_sequence=>55
,p_column_heading=>'Registrada'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19982215526117449)
,p_query_column_id=>3
,p_column_alias=>'SINTOMAS'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19982355379117450)
,p_query_column_id=>4
,p_column_alias=>'DIAGNOS'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19982367887117451)
,p_query_column_id=>5
,p_column_alias=>'DORDENID'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19982470086117452)
,p_query_column_id=>6
,p_column_alias=>'LABOR'
,p_column_display_sequence=>50
,p_column_heading=>'Labores Pendientes'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(15690460025797495)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19982634125117453)
,p_query_column_id=>7
,p_column_alias=>'PERSONAL_ID'
,p_column_display_sequence=>60
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19982742748117454)
,p_query_column_id=>8
,p_column_alias=>'TAREA'
,p_column_display_sequence=>70
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19982843959117455)
,p_query_column_id=>9
,p_column_alias=>'OFICIO'
,p_column_display_sequence=>80
,p_column_heading=>'Actividad'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(15703645674805093)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19982929492117456)
,p_query_column_id=>10
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>90
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(19342421983317820)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19983795643117465)
,p_plug_name=>'Mensajes'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(15246847611168622)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>3
,p_plug_display_column=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20280507444819754)
,p_plug_name=>'ELOGO'
,p_region_template_options=>'#DEFAULT#:margin-top-lg'
,p_plug_template=>wwv_flow_imp.id(15253424549168634)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>6
,p_plug_display_column=>6
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19983330203117460)
,p_name=>'P1_AP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(19983795643117465)
,p_prompt=>'Actividades Pendientes'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="background-color:#ffe6e6;text-align:center;color:red;"'
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_icon_css_classes=>'fa-lightbulb-o'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'HTML_UNSAFE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(19984027516117467)
,p_name=>'P1_OP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(19983795643117465)
,p_prompt=>'Nuevas Observaciones'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'style="background-color:#fff2b3;text-align:center;color:red;"'
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_icon_css_classes=>'fa-lightbulb-o'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20280577352819755)
,p_name=>'P1_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(20280507444819754)
,p_item_default=>'#APP_FILES#logofb.jpg'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_attributes=>'style="border:0;height:80px;width:225px;"'
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19983615678117463)
,p_name=>'CPendientes'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19983680333117464)
,p_event_id=>wwv_flow_imp.id(19983615678117463)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'OBSER_DATE VARCHAR2(20);',
'BEGIN',
'SELECT COUNT(*) CUANTOS INTO :P1_AP',
'  FROM ORDENES_SOPORTE O, SINTOMAS S, DIAGNOSTICOS D, ORDENES_DETALLE OD, DORDEN_RESPONSABLE DR',
'  WHERE O.COMPANIA = :P0_CIA',
'    AND O.ID > 0',
'    AND O.ESTADO_TECNICO IN (''A'',''R'')',
'    AND S.ORDEN_ID = O.ID',
'    AND D.SINTOMAS_ID = S.CODIGO',
'    AND OD.DIAG_ID = D.CODIGO',
'    AND DR.DORDEN_ID = OD.ID',
'    AND DR.PERSONAL_ID IN (SELECT ID FROM PERSONAL WHERE USUARIO IN (SELECT COALESCE(v(''APP_USER''), USER)FROM DUAL))',
'    AND DR.ESTADO IN (1,2,3);',
'',
'  SELECT  max(viewdate) vd INTO OBSER_DATE',
'    FROM   (SELECT DISTINCT apex_user username, to_char(view_date,''dd/mm/yyyy hh24:mi'') viewdate',
'            FROM   apex_workspace_activity_log',
'            WHERE  Trunc (view_date) = Trunc (sysdate))',
'    WHERE username in (SELECT COALESCE(v(''APP_USER''), USER)FROM DUAL)',
'    ORDER  BY 1; ',
'  SELECT COUNT(*) INTO :P1_OP',
'    FROM OBSERVACIONES WHERE TRUNC(FECHA_HORA) > TRUNC(TO_DATE(OBSER_DATE,''DD/MM/YYYY HH24:MI''));',
'END;'))
,p_attribute_02=>'P0_CIA'
,p_attribute_03=>'P1_AP,P1_OP'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(19983038412117457)
,p_name=>'APendientes'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_AP'
,p_condition_element=>'P1_AP'
,p_triggering_condition_type=>'GREATER_THAN'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19983126532117458)
,p_event_id=>wwv_flow_imp.id(19983038412117457)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19981998582117447)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(19983186266117459)
,p_event_id=>wwv_flow_imp.id(19983038412117457)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19981998582117447)
);
wwv_flow_imp.component_end;
end;
/
