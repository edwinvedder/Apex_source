prompt --application/pages/page_00040
begin
--   Manifest
--     PAGE: 00040
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_page.create_page(
 p_id=>40
,p_name=>'DOCUMENTOS DE LA ORDEN'
,p_alias=>'DOCUMENTOS-DE-LA-ORDEN'
,p_page_mode=>'MODAL'
,p_step_title=>'DOCUMENTOS DE LA ORDEN'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230331112437'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197442224494490074)
,p_plug_name=>'DOCUMENTOS DE LA TRANSACCION'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15252029077168633)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'DOCUMENTOS_ORDENES'
,p_include_rowid_column=>true
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197447322251490133)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15254853845168635)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18250264538186183)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(197447322251490133)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(15378986689168770)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18250702844186183)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(197447322251490133)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(15378986689168770)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P40_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18251101568186183)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(197447322251490133)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(15378986689168770)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P40_ROWID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18251512556186184)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(197447322251490133)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(15378986689168770)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P40_ROWID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18010723959808284)
,p_name=>'P40_ORDEN_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>33
,p_item_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_item_source_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_prompt=>'Orden Id'
,p_source=>'ORDEN_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ORDENES_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT O.ID OID, O.ID||''/''||P.DESCRIPCION||''-''||C.NOMBRE||'' ''||APELLIDOS ORDEN FROM PRODUCTOS P, CLIENTES C, ORDENES_SOPORTE O',
'WHERE P.ID = O.PRODUCTO_ID',
'  AND C.ID = O.CLIENTE_ID',
'  AND O.COMPANIA = :P0_CIA',
'  AND O.ID > 0'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18242404097186164)
,p_name=>'P40_ROWID'
,p_source_data_type=>'ROWID'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_item_source_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_source=>'ROWID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18242844091186164)
,p_name=>'P40_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_item_source_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_item_default=>'SEQ_DOCS1.NEXTVAL'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18243606593186165)
,p_name=>'P40_TIPO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_item_source_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_prompt=>'Tipo de Documento'
,p_source=>'TIPO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TIPOS_DOCUMENTOS_LOV'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(15377835423168766)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18244010663186166)
,p_name=>'P40_DESCRIPCION'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_item_source_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_prompt=>'DESCRIPCION'
,p_source=>'DESCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>200
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(15377835423168766)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18244374052186167)
,p_name=>'P40_BROWSEF'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_prompt=>'DOCUMENTO'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18244786887186167)
,p_name=>'P40_DOCORIGEN'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>65
,p_item_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_item_source_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_item_default=>'E'
,p_prompt=>'Docorigen'
,p_source=>'DOCORIGEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:INTERNO;I,EXTERNO;E'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18245248582186168)
,p_name=>'P40_PATH'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_item_source_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_source=>'PATH'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18245574232186168)
,p_name=>'P40_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_item_source_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_item_default=>'A'
,p_prompt=>'ESTADO'
,p_source=>'ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:ACTIVO;A,INACTIVO;I'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(15377835423168766)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18246389266186170)
,p_name=>'P40_PARAMPATH'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(197442224494490074)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PARA_VALOR FROM PARAMETROS',
'WHERE ID > 0 AND PARA_CIA=1 AND PARA_NOMBRE = ''PATH_DOCS'''))
,p_item_default_type=>'SQL_QUERY'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT PARA_VALOR FROM PARAMETROS',
'WHERE ID > 0 AND PARA_CIA=1 AND PARA_NOMBRE = ''PATH_DOCS'''))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(18252359094186185)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(18250264538186183)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18252794354186185)
,p_event_id=>wwv_flow_imp.id(18252359094186185)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(18253182544186186)
,p_name=>'Browsefile'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P40_BROWSEF'
,p_condition_element=>'P40_BROWSEF'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18253723875186186)
,p_event_id=>wwv_flow_imp.id(18253182544186186)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var fp = $("#P40_BROWSEF");',
'var lg = fp[0].files.length; // get length',
'var items = fp[0].files;',
'if (lg > 0) {',
'        for (var i = 0; i < lg; i++) {',
'            var fileName = items[i].name; // get file name',
'            //var valores = apex.item("P40_PARAMPATH").getValue() + fileName;',
'            var valores = fileName;',
'            ',
'         //   var fileSize = items[i].size; // get file size ',
'          //  var fileType = items[i].type; // get file type',
'            apex.item( "P40_PATH" ).setValue( valores, null, true );',
'        //    apex.item( "P6_FILE_SIZE" ).setValue( fileSize, null, true );',
'        //    apex.item( "P6_FILE_TYPE" ).setValue( fileType, null, true );',
' }',
'',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18249594635186182)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(197442224494490074)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form DOCUMENTOS DE LA TRANSACCION'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>18249594635186182
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18251905031186184)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>18251905031186184
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(18249237040186176)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(197442224494490074)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form DOCUMENTOS DE LA TRANSACCION'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>18249237040186176
);
wwv_flow_imp.component_end;
end;
/
