prompt --application/pages/page_00053
begin
--   Manifest
--     PAGE: 00053
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_page.create_page(
 p_id=>53
,p_name=>'Genera Fact_PDF'
,p_alias=>'GENERA-FACT-PDF'
,p_page_mode=>'MODAL'
,p_step_title=>'Genera  PDF'
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(15227034801168599)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230513101029'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21565506117552439)
,p_plug_name=>'FACTURA --> PDF'
,p_region_template_options=>'#DEFAULT#:t-Region--accent10:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15306456740168682)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'Genera Factura en formato PDF'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21566337620552447)
,p_plug_name=>'Botones'
,p_parent_plug_id=>wwv_flow_imp.id(21565506117552439)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noBorder'
,p_plug_template=>wwv_flow_imp.id(15254853845168635)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21565767603552442)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(21566337620552447)
,p_button_name=>'PDFBTN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(15379158749168770)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'PDF'
,p_icon_css_classes=>'fa-file-pdf-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(21566028698552444)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(21566337620552447)
,p_button_name=>'CerrarBTN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(15379158749168770)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cerrar'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-window-close'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(21565619987552440)
,p_name=>'P53_FACID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(21565506117552439)
,p_prompt=>'Factura seleccionada'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'FACTURAS_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT C.NOMBRE||'' ''||C.APELLIDOS||''(Fact#''||F.ID||''-$''||TRAE_TOTALFACT(F.ID)||''--$''||TRAE_DEUDATOTALFACT(F.ID)||'')'' CLIENTE, F.ID MIID ',
'FROM CLIENTES C, FACTURAS F',
'WHERE C.ID =F.CLIENTE_ID',
'  AND F.ESTADO IN (''A'',''B'',''X'')'))
,p_cHeight=>1
,p_tag_attributes=>'style="background-color:#ffe6e6;"'
,p_colspan=>10
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(21566139595552445)
,p_name=>'Cierralo'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(21566028698552444)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(21566225022552446)
,p_event_id=>wwv_flow_imp.id(21566139595552445)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(21565748436552441)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'FAC_PDF'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'  l_additional_parameters varchar2(32767);',
'  ',
'BEGIN',
'  if (nvl(:P53_FACID,0) > 0) then',
'    xlib_jasperreports.set_report_url(''http://localhost:8888/jri/report'');',
'',
'    l_additional_parameters := ''FACTID='' || apex_util.url_encode(:P53_FACID);',
'    xlib_jasperreports.show_report(p_rep_name => ''fact'',',
'                                    p_rep_format => ''pdf'',',
'                                    p_data_source => ''default'',',
'                                    p_rep_locale => ''en-US'',',
'                                    p_out_filename => ''factura00''||:P53_FACID||''.pdf'',',
'                                    p_additional_params => l_additional_parameters);',
'    apex_application.g_unrecoverable_error := true;',
'  else',
'    raise_application_error(''-20002'',''Hey! debes elegir una factura primero!'');',
'  end if;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'No pude generar el archivo PDF',
''))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(21565767603552442)
,p_process_success_message=>'Generada Factura PDF!'
,p_internal_uid=>21565748436552441
);
wwv_flow_imp.component_end;
end;
/
