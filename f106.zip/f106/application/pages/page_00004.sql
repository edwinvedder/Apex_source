prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'CLIENTES'
,p_alias=>'CLIENTES'
,p_step_title=>'CLIENTES'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.button1 {',
'     background-color black;',
'     color: black;',
'     border: 2px solid #008CBA;',
'}',
'',
'.button1:hover {',
'     background-color: #008CBA;',
'     color: white;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(16644183188340131)
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'SOPORTE'
,p_last_upd_yyyymmddhh24miss=>'20230417130540'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(34328536547836043)
,p_plug_name=>'CLIENTES'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--accent5:t-Region--scrollBody:margin-top-sm'
,p_plug_template=>wwv_flow_imp.id(15306456740168682)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select COMPANIA,',
'       ID,',
'       substr(RNC_CEDULA,1,3)||''-''||substr(RNC_CEDULA,4,8)||''-''||substr(RNC_CEDULA,9,1) RNCCEDULA,',
'       NOMBRE,',
'       APELLIDOS,',
'       DIRECCION,',
'       substr(TELEFONOS,1,3)||''-''||substr(TELEFONOS,4,3)||''-''||substr(TELEFONOS,7,4) TELEFONOS,',
'       EMAIL,',
'       PAGWEB,',
'       ESTADO,',
'       CLASIFICACION,',
'       SCORE,',
'       CREDITO',
'  from CLIENTES'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'CLIENTES'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_header=>'<h3><p style="font-family:verdana; text-align:center; color:blue; size:70px">REGISTRO DE CLIENTES<p></h3>'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(34328990589836044)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No se encontraron datos.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_download_filename=>'Soporte-clientes'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP,:P5_ID,P5_COMPANIA:\#ID#\,\#COMPANIA#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ADMIN'
,p_internal_uid=>21438029219521108
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15516871422378510)
,p_db_column_name=>'COMPANIA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Compania'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15517344903378515)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18010474229808282)
,p_db_column_name=>'RNCCEDULA'
,p_display_order=>3
,p_column_identifier=>'N'
,p_column_label=>unistr('RNC-C\00C9DULA')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15518091509378516)
,p_db_column_name=>'NOMBRE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'NOMBRES'
,p_column_html_expression=>'<a class="u-bold u-italics">#NOMBRE# &nbsp #APELLIDOS#</a>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15518516111378517)
,p_db_column_name=>'APELLIDOS'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'APELLIDOS'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15518913040378519)
,p_db_column_name=>'DIRECCION'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>unistr('DIRECCI\00D3N ')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15519318262378519)
,p_db_column_name=>'TELEFONOS'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'TEL(S)'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15519675851378520)
,p_db_column_name=>'EMAIL'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'EMAIL'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15520104985378520)
,p_db_column_name=>'PAGWEB'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'PAG. WEB'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15520541701378521)
,p_db_column_name=>'ESTADO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'ESTADO'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(15522790387378567)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18010253940808279)
,p_db_column_name=>'CLASIFICACION'
,p_display_order=>20
,p_column_identifier=>'K'
,p_column_label=>'Clasificacion'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18010282174808280)
,p_db_column_name=>'SCORE'
,p_display_order=>30
,p_column_identifier=>'L'
,p_column_label=>'Score'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18010406949808281)
,p_db_column_name=>'CREDITO'
,p_display_order=>40
,p_column_identifier=>'M'
,p_column_label=>'Credito'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(34518890879939360)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'190026'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'RNCCEDULA:NOMBRE:DIRECCION:TELEFONOS:ESTADO:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17512672984918477)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(34328536547836043)
,p_button_name=>'Relacionados_btn'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(15379158749168770)
,p_button_image_alt=>'Relacionados'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.::P36_CLIENTE:&P4_ID.#ID.\'
,p_button_css_classes=>'button1'
,p_icon_css_classes=>'fa-users-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17512831207918478)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(34328536547836043)
,p_button_name=>'Coments_btn'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(15379158749168770)
,p_button_image_alt=>'Comentarios'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.::P35_CID:\&ID.\'
,p_button_css_classes=>'button1'
,p_icon_css_classes=>'fa-eye'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15521078251378533)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(34328536547836043)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_imp.id(15379158749168770)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Nuevo'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:3::'
,p_icon_css_classes=>'fa-file-new'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15521473151378535)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(34328536547836043)
,p_button_name=>'ORDEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_imp.id(15379158749168770)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Orden'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-clipboard-wrench'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17513082274918481)
,p_name=>'P4_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(34328536547836043)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15521933728378556)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(34328536547836043)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15522397112378560)
,p_event_id=>wwv_flow_imp.id(15521933728378556)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(34328536547836043)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17512895770918479)
,p_name=>'Selected'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(34328536547836043)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17513019345918480)
,p_event_id=>wwv_flow_imp.id(17512895770918479)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var miid',
'model=this.data.model;',
'if(this.data != null){',
'    if(this.data.selectedRecords[0]!=null){',
'        miid =  model.getValue(this.data.selectedRecords[0], "ID");',
'    }',
'}',
'apex.item( "P4_ID" ).setValue(miid);'))
);
wwv_flow_imp.component_end;
end;
/
