prompt --application/pages/page_00026
begin
--   Manifest
--     PAGE: 00026
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_page.create_page(
 p_id=>26
,p_name=>'CALENDARIO TRABAJOS'
,p_alias=>'CALENDARIO-TRABAJOS'
,p_step_title=>'CALENDARIO TRABAJOS'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'08'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230727173335'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17190346458677531)
,p_plug_name=>'CALENDARIO TRABAJOS'
,p_region_template_options=>'#DEFAULT#:t-Region--accent3:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(15306456740168682)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select O.COMPANIA,',
'       O.ID,',
'       FECHA,',
'       PRODUCTO_ID,',
'       CANTIDAD_PRODUCTO,',
'       CLIENTE_ID,C.NOMBRE||'' ''||C.APELLIDOS||''(''||P.DESCRIPCION||'')'' NOMBRE,',
'       TIPO_FACTURACION,',
'       FECHA_VGARANTIA,',
'       O.ESTADO,',
'       NOTAS,',
'       REFERENCIA1,',
'       REFERENCIA2,',
'       VDESDE,',
'       VHASTA,',
'       FECHA_ENTREGA,',
'       CASE ',
'  WHEN O.ESTADO IN (''A'',''B'',''S'')  THEN ''apex-cal-green''',
'  WHEN O.ESTADO NOT IN (''A'',''B'',''S'') THEN ''apex-cal-blue''',
'  WHEN O.ESTADO IN (''A'',''B'',''S'') AND (FECHA_ENTREGA > SYSDATE) THEN ''apex-cal-red''',
'  ELSE ''apex-cal-red''',
'END AS css_class',
'  from ORDENES_SOPORTE O',
'  inner join PRODUCTOS P on O.PRODUCTO_ID = p.id',
'  inner join CLIENTES C on O.CLIENTE_ID = C.id',
' where O.COMPANIA=:P0_CIA AND O.ESTADO_TECNICO in (''A'',''E'',''R'')'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_attribute_01=>'FECHA'
,p_attribute_02=>'FECHA_ENTREGA'
,p_attribute_03=>'NOMBRE'
,p_attribute_04=>'ID'
,p_attribute_05=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_attribute_06=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_attribute_07=>'Y'
,p_attribute_08=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  UPDATE ORDENES_SOPORTE',
'    SET FECHA = TO_DATE(:APEX$NEW_START_DATE,''YYYYMMDDHH24MISS''),',
'        FECHA_ENTREGA = TO_DATE(:APEX$NEW_END_DATE,''YYYYMMDDHH24MISS'')',
'    WHERE ID = :APEX$PK_VALUE;',
'END;'))
,p_attribute_09=>'list:navigation'
,p_attribute_13=>'N'
,p_attribute_14=>'CSS_CLASS'
,p_attribute_17=>'Y'
,p_attribute_19=>'Y'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
);
wwv_flow_imp.component_end;
end;
/
