prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_page.create_page(
 p_id=>21
,p_name=>'GESTION_OBSERVACION'
,p_alias=>'GESTION-OBSERVACION'
,p_page_mode=>'MODAL'
,p_step_title=>'GESTION_OBSERVACION'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(16644183188340131)
,p_page_component_map=>'17'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230314113423'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(262247569494704688)
,p_plug_name=>'GESTION-OBSERVACION'
,p_region_template_options=>'#DEFAULT#:t-Region--accent1:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(15306456740168682)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'OBSERVACIONES'
,p_query_where=>'ID_ORDEN=:P21_OID'
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'ID, FECHA_HORA'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>15
,p_plug_query_no_data_found=>unistr('Ninguna observaci\00F3n para mostrar')
,p_attribute_02=>'NOTA'
,p_attribute_06=>'USUARIO'
,p_attribute_08=>'FECHA_HORA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16642559547340068)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(262247569494704688)
,p_button_name=>'Nueva'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(15379158749168770)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Nueva'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::P22_ID_ORDEN:&P21_OID.'
,p_icon_css_classes=>'fa-newspaper-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16642918416340071)
,p_name=>'P21_OID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(262247569494704688)
,p_prompt=>'ORDEN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ORDENES_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT O.ID OID, O.ID||''/''||P.DESCRIPCION||''-''||C.NOMBRE||'' ''||APELLIDOS ORDEN FROM PRODUCTOS P, CLIENTES C, ORDENES_SOPORTE O',
'WHERE P.ID = O.PRODUCTO_ID',
'  AND C.ID = O.CLIENTE_ID',
'  AND O.COMPANIA = :P0_CIA',
'  AND O.ID > 0'))
,p_cHeight=>1
,p_tag_attributes=>'style="color:blue;"'
,p_read_only_when=>'P21_OID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16643275042340075)
,p_name=>'P21_MID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(262247569494704688)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
