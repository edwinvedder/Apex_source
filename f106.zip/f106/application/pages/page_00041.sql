prompt --application/pages/page_00041
begin
--   Manifest
--     PAGE: 00041
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_page.create_page(
 p_id=>41
,p_name=>'REQUISITOS ORDEN'
,p_alias=>'REQUISITOS-ORDEN'
,p_page_mode=>'MODAL'
,p_step_title=>'REQUISITOS PROCESO'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(15227034801168599)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'600'
,p_dialog_width=>'600'
,p_dialog_max_width=>'800'
,p_page_component_map=>'03'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230331151624'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(173678803799571802)
,p_name=>'REQUISITOS DEL PROCESO'
,p_template=>wwv_flow_imp.id(15306456740168682)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--accent5:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       ID_ESTORDEN,',
'       ( select l.DESCRIPCION from ESTADO_ORDEN l where l.ID = m.ID_ESTORDEN) ID_ESTORDEN_L$1,',
'       ID_ESTORDENP,',
'       ( select l.DESCRIPCION from ESTADO_ORDEN l where l.ID = m.ID_ESTORDENP) ID_ESTORDENP_L$2,',
'       DECODE(OBLIGADO,''S'',''Si'',''N'',''No'') OBLIGADO,',
'       ESTADO',
'from ESTADO_ORD_PREREQ m',
'where ID_ESTORDEN = :P41_ORDEN'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(15344021115168715)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18279155445760640)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18279536353760643)
,p_query_column_id=>2
,p_column_alias=>'ID_ESTORDEN'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18279887528760644)
,p_query_column_id=>3
,p_column_alias=>'ID_ESTORDEN_L$1'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18280278502760644)
,p_query_column_id=>4
,p_column_alias=>'ID_ESTORDENP'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18280700862760645)
,p_query_column_id=>5
,p_column_alias=>'ID_ESTORDENP_L$2'
,p_column_display_sequence=>50
,p_column_heading=>'PROCESO REQUERIDO'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18281086996760645)
,p_query_column_id=>6
,p_column_alias=>'OBLIGADO'
,p_column_display_sequence=>60
,p_column_heading=>'ES NECESARIO?'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'Si'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18281474766760646)
,p_query_column_id=>7
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>70
,p_column_heading=>'ESTATUS'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(15522790387378567)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18281953893760654)
,p_name=>'P41_ORDEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(173678803799571802)
,p_prompt=>'Proceso'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ESTADOS_ORD_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID CODIGO, DESCRIPCION NOMBRE FROM ESTADO_ORDEN',
'WHERE ESTADO =''A'''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
