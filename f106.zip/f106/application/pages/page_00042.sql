prompt --application/pages/page_00042
begin
--   Manifest
--     PAGE: 00042
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_page.create_page(
 p_id=>42
,p_name=>'Facturas Realizadas'
,p_alias=>'FACTURAS-REALIZADAS'
,p_step_title=>'Facturas Realizadas'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230620095633'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18266918921505847)
,p_plug_name=>'FACTURAS DEL PERIODO'
,p_region_template_options=>'#DEFAULT#:t-Region--accent5:js-headingLevel-2:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15306456740168682)
,p_plug_display_sequence=>12
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>4
,p_plug_display_column=>5
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<H3>PERIODO A CONSULTAR<H3>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(19058169152719148)
,p_name=>'FACTURAS REALIZADAS'
,p_template=>wwv_flow_imp.id(15306456740168682)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--accent4:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--horizontalBorders'
,p_grid_column_span=>6
,p_display_column=>4
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT F.ID FACID,TO_CHAR(F.FECHA,''DD/MM/YYYY'') FFECHA, F.NCF, C.RNC_CEDULA RNC,C.NOMBRE||'' ''||C.APELLIDOS CNOMBRE,',
'  SUM((D.CANTIDAD * D.PRECIO)-D.DESCUENTO) MONTO_NETO, SUM(D.IMPUESTO) ITBIS, SUM((D.CANTIDAD * D.PRECIO)-D.DESCUENTO) + SUM(D.IMPUESTO) TOTAL',
'  FROM FACTURAS F, CLIENTES C, FACTURAS_DET D',
'  WHERE F.COMPANIA=:P0_CIA',
'    AND F.ID > 0',
'    AND F.FECHA BETWEEN TO_DATE(:P42_DFECHA,''DD/MM/YYYY'') AND TO_DATE(:P42_HFECHA,''DD/MM/YYYY'')',
'    AND F.ESTADO IN (''P'',''A'',''B'')',
'    AND C.COMPANIA = F.COMPANIA',
'    AND C.ID = F.CLIENTE_ID    ',
'    AND D.ID > 0',
'    AND D.FAC_ID = F.ID',
'    GROUP BY F.ID,TO_CHAR(F.FECHA,''DD/MM/YYYY''),F.NCF, C.RNC_CEDULA,C.NOMBRE||'' ''||C.APELLIDOS',
'    ORDER BY F.ID,FFECHA'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P42_REPORT_NAME,P42_DFECHA,P42_HFECHA'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(15344021115168715)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No hay datos.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Descargar'
,p_prn_output=>'Y'
,p_prn_format=>'PDF'
,p_prn_output_link_text=>'Imprimir'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width_units=>'PERCENTAGE'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'FACTURAS REALIZADAS'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_sort_null=>'L'
,p_plug_query_exp_filename=>'&P42_REPORT_NAME.'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19058634112719159)
,p_query_column_id=>1
,p_column_alias=>'FACID'
,p_column_display_sequence=>10
,p_column_heading=>'Num.'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19059058903719164)
,p_query_column_id=>2
,p_column_alias=>'FFECHA'
,p_column_display_sequence=>20
,p_column_heading=>'Fecha'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON-YYYY'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19059437350719165)
,p_query_column_id=>3
,p_column_alias=>'NCF'
,p_column_display_sequence=>11
,p_column_heading=>'NCF'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19059797095719165)
,p_query_column_id=>4
,p_column_alias=>'RNC'
,p_column_display_sequence=>14
,p_column_heading=>'RNC'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19060583975719166)
,p_query_column_id=>5
,p_column_alias=>'CNOMBRE'
,p_column_display_sequence=>12
,p_column_heading=>'Cliente'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19060987366719167)
,p_query_column_id=>6
,p_column_alias=>'MONTO_NETO'
,p_column_display_sequence=>22
,p_column_heading=>'Monto Neto'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(19061428403719167)
,p_query_column_id=>7
,p_column_alias=>'ITBIS'
,p_column_display_sequence=>24
,p_column_heading=>'Itbis'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18267242470505850)
,p_query_column_id=>8
,p_column_alias=>'TOTAL'
,p_column_display_sequence=>40
,p_column_heading=>'Total'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18267015409505848)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(18266918921505847)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(15379158749168770)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_icon_css_classes=>'fa-search'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18266751585505845)
,p_name=>'P42_DFECHA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(18266918921505847)
,p_prompt=>'Desde'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18266823602505846)
,p_name=>'P42_HFECHA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(18266918921505847)
,p_prompt=>'Hasta'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18267368348505852)
,p_name=>'P42_REPORT_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(18266918921505847)
,p_item_default=>'SELECT ''Fact_Realizadas''||TO_CHAR(SYSDATE,''YYYYMMDD_HH24MI'')||''.csv'' RNAME FROM DUAL'
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
