prompt --application/pages/page_00054
begin
--   Manifest
--     PAGE: 00054
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_page.create_page(
 p_id=>54
,p_name=>'Genera Cot_PDF'
,p_alias=>'GENERA-COT-PDF'
,p_page_mode=>'MODAL'
,p_step_title=>'Genera Cot_PDF'
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(15227034801168599)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'KADMIN'
,p_last_upd_yyyymmddhh24miss=>'20231115132011'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30962084378142258)
,p_plug_name=>'COTIZACION --> PDF'
,p_region_template_options=>'#DEFAULT#:t-Region--accent10:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(15306456740168682)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>unistr('Genera Cotizaci\00F3n en formato PDF')
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30962915881142266)
,p_plug_name=>'Botones'
,p_parent_plug_id=>wwv_flow_imp.id(30962084378142258)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noBorder'
,p_plug_template=>wwv_flow_imp.id(15254853845168635)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22288727164904795)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(30962915881142266)
,p_button_name=>'PDFBTN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(15379158749168770)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'PDF'
,p_icon_css_classes=>'fa-file-pdf-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22289120260904796)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(30962915881142266)
,p_button_name=>'CerrarBTN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(15379158749168770)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cerrar'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-window-close'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22288007545904788)
,p_name=>'P54_COTID'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(30962084378142258)
,p_prompt=>'Cotizacion seleccionada'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'COTIZACIONES_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT O.ID CODIGO,  C.NOMBRE||'' ''||C.APELLIDOS || ''(#'' || TO_CHAR(O.ID) ||''-''|| TO_CHAR(O.FECHA,''DD/MON/YYYY'')||'')'' MICOT FROM COTIZACION O, CLIENTES C',
'WHERE O.COMPANIA=:P0_CIA AND O.ESTADO IN (''A'',''B'')',
'  AND C.ID=O.CLIENTE_ID'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_tag_attributes=>'style="background-color:#ffe6e6;"'
,p_colspan=>10
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22289922695904839)
,p_name=>'Cierralo'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(22289120260904796)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22290379754904845)
,p_event_id=>wwv_flow_imp.id(22289922695904839)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22289511248904834)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'COT_PDF'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'  l_additional_parameters varchar2(32767);',
'  ',
'BEGIN',
'  if (nvl(:P54_COTID,0) > 0) then',
'    xlib_jasperreports.set_report_url(''http://10.0.0.246:8888/jri/report'');',
'',
'    l_additional_parameters := ''COTID='' || apex_util.url_encode(:P54_COTID);',
'    xlib_jasperreports.show_report(p_rep_name => ''cotiz'',',
'                                    p_rep_format => ''pdf'',',
'                                    p_data_source => ''default'',',
'                                    p_rep_locale => ''en-US'',',
'                                    p_out_filename => ''cotiza00''||:P54_COTID||''.pdf'',',
'                                    p_additional_params => l_additional_parameters);',
'    apex_application.g_unrecoverable_error := true;',
'  else',
unistr('    raise_application_error(''-20002'',''Hey! debes elegir una cotizaci\00F3n primero!'');'),
'  end if;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No pude generar el archivo PDF'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(22288727164904795)
,p_process_success_message=>unistr('Cotizaci\00F3n PDF Generada!')
,p_internal_uid=>22289511248904834
);
wwv_flow_imp.component_end;
end;
/
