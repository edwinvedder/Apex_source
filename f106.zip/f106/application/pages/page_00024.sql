prompt --application/pages/page_00024
begin
--   Manifest
--     PAGE: 00024
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_page.create_page(
 p_id=>24
,p_name=>'IMPRIMIR ORDENES'
,p_alias=>'IMPRIMIR-ORDENES'
,p_step_title=>'IMPRIMIR ORDENES'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.button1 {',
'    background-color: #4CAF50;',
'    border-radius: 12px;',
'    ',
'}',
'',
'.button1:hover {',
'  background-color: #6acebd; /* Green */',
'  color: white;',
'  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);',
'}',
'//#bfff00'))
,p_step_template=>wwv_flow_imp.id(15228535652168603)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'10'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230404144821'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16979779672451837)
,p_plug_name=>'ORDENES'
,p_region_name=>'misordenes'
,p_region_template_options=>'#DEFAULT#:t-Region--accent4:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(15306456740168682)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'CURSOR ORD1 IS select ''<tr ><td class=" u-tL" headers="C22511980156668032">''|| TO_CHAR(M.FECHA,''DD-MON-YYYY'')||''</td>',
'<td class=" u-tL" headers="C22512758761668033">'' ||( select l.DESCRIPCION from PRODUCTOS l where l.ID = M.PRODUCTO_ID)||''</td>',
'<td class=" u-tR" headers="C22513174125668034">''||M.CANTIDAD_PRODUCTO||''</td>',
'<td class=" u-tL" headers="C22513562956668034">''||( select l.NOMBRE||'' ''||l.APELLIDOS from CLIENTES l where l.ID = M.CLIENTE_ID)||''</td>',
'<td class=" u-tL" headers="C22515116904668036"><a title="''|| D.TITULO || ''" href="'' || apex_util.prepare_url(''f?p=&APP_ID.: ''||D.UPAGINA|| '':'' || :app_session || ''::::P''||D.UPAGINA||''_ID:'' || to_number(M.ID)) || ''" >''||trae_estado(M.ESTADO)||''</a></t'
||'d></tr>'' MDETALLE,',
'       M.COMPANIA,',
'       M.ID,',
'       case',
unistr('         when rownum > 1 then rownum ||'' \00D3rdenes'''),
'         else rownum||'' Orden''',
'       end CUANTOSO',
'from ORDENES_SOPORTE M, ESTADO_ORDEN E, DOCUMENTOS D',
'where M.ID > 0 ',
'  and M.FECHA BETWEEN NVL(TO_DATE(:P24_F1,''DD/MM/YYYY''),(SYSDATE - 1)) AND NVL(TO_DATE(:P24_F2,''DD/MM/YYYY''), (SYSDATE + 30))',
'  and M.ESTADO IN (NVL(:P24_ESTADOS,M.ESTADO))',
'  and E.ID = M.ESTADO',
'  and E.ESTADO = ''A''',
'  and D.ID = E.DOCUMENTO',
'  and D.ESTADO =''A''',
'order by M.FECHA ASC;',
'CUANTOS varchar2(25);',
'BEGIN',
'  --CUANTOS:=0;',
'  sys.htp.print(''<div id="R22510723500667992_chart" class="a-IRR-chartView"></div><div id="R22510723500667992_group_by" class="a-IRR-groupByView">',
'</div> <div id="R22510723500667992_pivot" class="a-IRR-pivotView"></div>',
'<div id="R22510723500667992_data_panel" class="a-IRR-reportView">',
'  <div class="a-IRR-tableContainer">'');',
'  sys.htp.print(''<table aria-label="Region = Ordenes, Report = Primary Default, View = Report, Displayed Rows Start = 1, Displayed Rows End = 1" class="a-IRR-table" id="22510860600667992">',
'<tr><th class="a-IRR-header u-tL" id="C22511980156668032"><a class="a-IRR-headerLink" data-column="22511980156668032" >FECHA</a></th><th class="a-IRR-header" id="C22512758761668033">',
'<a class="a-IRR-headerLink" data-column="22512758761668033" >SERVICIO</a></th>',
'<th class="a-IRR-header u-tR" id="C22513174125668034"><a class="a-IRR-headerLink" data-column="22513174125668034" >CANTIDAD</a></th>',
'<th class="a-IRR-header" id="C22513562956668034"><a class="a-IRR-headerLink" data-column="22513562956668034" >CLIENTE</a></th>',
'<th class="a-IRR-header u-tL" id="C22515116904668036"><a class="a-IRR-headerLink" data-column="22515116904668036" >ESTADO</a></th></tr>'');',
'  FOR I IN ORD1 ',
'  LOOP',
'    sys.htp.print(I.MDETALLE);',
'    CUANTOS:=I.CUANTOSO;    ',
'  END LOOP; ',
'   sys.htp.print(''</table></div>'');',
'  sys.htp.print(''<div class="a-IRR-paginationWrap a-IRR-paginationWrap--bottom"><ul class="a-IRR-pagination"><li aria-hidden="true" class="a-IRR-pagination-item is-disabled"></li>',
'<li class="a-IRR-pagination-item"><span class="a-IRR-pagination-label">Mostrando ''||CUANTOS||'' </span></li><li aria-hidden="true" class="a-IRR-pagination-item is-disabled"></li></ul></div></div></div></div></div>',
'<div class="a-IRR-sortWidget" id="R22510723500667992_sort_widget" style="display:none;">',
'<ul class="a-IRR-sortWidget-actions" id="R22510723500667992_sort_widget_actions">',
'<li class="a-IRR-sortWidget-actions-item" id="R22510723500667992_sort_widget_action_up">',
'<button class="a-Button a-IRR-button a-IRR-sortWidget-button" type="button" title="Sort Ascending" data-option="up">',
'<span class="a-Icon icon-irr-sort-asc"></span></button></li>'');',
'',
'  sys.htp.print(''<li class="a-IRR-sortWidget-actions-item" id="R22510723500667992_sort_widget_action_down">',
'<button class="a-Button a-IRR-button a-IRR-sortWidget-button" type="button" title="Sort Descending" data-option="down">',
'<span class="a-Icon icon-irr-sort-desc"></span></button></li><li class="a-IRR-sortWidget-actions-item" id="R22510723500667992_sort_widget_action_hide">',
'<button class="a-Button a-IRR-button a-IRR-sortWidget-button" type="button" title="Hide Column" data-option="hide"><span class="a-Icon icon-irr-remove-col"></span></button></li>',
'<li class="a-IRR-sortWidget-actions-item" id="R22510723500667992_sort_widget_action_break"><button class="a-Button a-IRR-button a-IRR-sortWidget-button" type="button" title="Control Break" data-option="break">',
'<span class="a-Icon icon-irr-control-break"></span></button></li>',
'<li class="a-IRR-sortWidget-actions-item" id="R22510723500667992_sort_widget_action_help">',
'<button class="a-Button a-IRR-button a-IRR-sortWidget-button" type="button" title="Column Information" data-option="help">',
'<span class="a-Icon icon-irr-help"></span></button></li>',
'<li class="a-IRR-sortWidget-actions-item" id="R22510723500667992_sort_widget_action_computation">',
'<button class="a-Button a-IRR-button a-IRR-sortWidget-button" type="button" title="Compute" data-option="computation">',
'<span class="a-Icon icon-irr-calculator"></span></button></li></ul><div class="a-IRR-sortWidget-help" id="R22510723500667992_sort_widget_help"></div>',
'<div class="a-IRR-sortWidget-search" id="R22510723500667992_sort_widget_search">',
'<label for="R22510723500667992_sort_widget_search_field" class="a-IRR-sortWidget-searchLabel">',
'<span class="u-VisuallyHidden">Search</span></label><input id="R22510723500667992_sort_widget_search_field" class="a-IRR-sortWidget-searchField" type="text" placeholder="Filter..." />',
'<div class="a-IRR-sortWidget-rows" id="R22510723500667992_sort_widget_rows"></div></div></div></div>',
'<p style="font-family:verdana; color:red; size:8px">  *Click en el estado para Imprimir el documento correspondiente <p>'');',
'END;',
''))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17510634820918456)
,p_plug_name=>'MOSTRAR'
,p_region_template_options=>'#DEFAULT#:t-Region--accent3:t-Region--scrollBody:t-Form--slimPadding'
,p_plug_template=>wwv_flow_imp.id(15306456740168682)
,p_plug_display_sequence=>15
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>6
,p_plug_display_column=>4
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17511028144918460)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(17510634820918456)
,p_button_name=>'Filtrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(15379158749168770)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'button1'
,p_icon_css_classes=>'fa-search'
,p_grid_new_row=>'Y'
,p_grid_column=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17510737786918457)
,p_name=>'P24_F1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(17510634820918456)
,p_item_default=>'trunc(SYSDATE,''MM'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Desde:'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'STATIC'
,p_attribute_04=>'01/01/2022'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17510839787918458)
,p_name=>'P24_F2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(17510634820918456)
,p_item_default=>'TRUNC((add_months(SYSDATE,1)),''MM'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Hasta:'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'P24_F1'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17510887127918459)
,p_name=>'P24_ESTADOS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(17510634820918456)
,p_prompt=>'Estados'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ESTADOS_ORD_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID CODIGO, DESCRIPCION NOMBRE FROM ESTADO_ORDEN',
'WHERE ESTADO =''A'''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todas'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17511132713918461)
,p_name=>'Filtralo'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(17511028144918460)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17511261055918462)
,p_event_id=>wwv_flow_imp.id(17511132713918461)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp.component_end;
end;
/
