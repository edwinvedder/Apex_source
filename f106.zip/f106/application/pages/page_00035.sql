prompt --application/pages/page_00035
begin
--   Manifest
--     PAGE: 00035
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_page.create_page(
 p_id=>35
,p_name=>'COMENTARIOS A CLIENTES'
,p_alias=>'COMENTARIOS-A-CLIENTES'
,p_page_mode=>'MODAL'
,p_step_title=>'COMENTARIOS A CLIENTES'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230329111631'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(259385747548935497)
,p_plug_name=>'COMENTARIOS'
,p_region_template_options=>'#DEFAULT#:t-Region--accent5:t-Region--stacked:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(15306456740168682)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'COMENTARIOS_CLIENTES'
,p_query_where=>'CLIEID = :P35_CID AND ESTADO = ''A'''
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'FECHA_HORA DESC'
,p_include_rowid_column=>true
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>15
,p_plug_column_width=>'style="font-family:verdana;font-size:10px;"'
,p_plug_query_no_data_found=>'No hay comentarios'
,p_attribute_02=>'COMENTARIO'
,p_attribute_06=>'USUARIO'
,p_attribute_08=>'FECHA_HORA'
,p_attribute_16=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:RP,:P37_ROWID:\&ROWID.\'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17971953508385382)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(259385747548935497)
,p_button_name=>'Cierra'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(15378986689168770)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cerrar'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17972287062385387)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(259385747548935497)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(15378986689168770)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:42::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17972664103385394)
,p_name=>'P35_CID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(259385747548935497)
,p_prompt=>'Elija Cliente:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'CLIENTES_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID, NOMBRE||'' ''||APELLIDOS NAMAP FROM CLIENTES',
'WHERE COMPANIA=:P0_CIA'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17973160137385425)
,p_name=>'Cierrala'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(17971953508385382)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17973658956385430)
,p_event_id=>wwv_flow_imp.id(17973160137385425)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp.component_end;
end;
/
