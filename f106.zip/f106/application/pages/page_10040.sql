prompt --application/pages/page_10040
begin
--   Manifest
--     PAGE: 10040
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_page.create_page(
 p_id=>10040
,p_name=>'About'
,p_alias=>'HELP'
,p_step_title=>'About'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(15408825391168929)
,p_required_patch=>wwv_flow_imp.id(15405910946168899)
,p_protection_level=>'C'
,p_help_text=>'All application help text can be accessed from this page. The links in the "Documentation" region give a much more in-depth explanation of the application''s features and functionality.'
,p_page_component_map=>'17'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230420130253'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15462370720169270)
,p_plug_name=>'Acerca de KSoporte'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h1:t-ContentBlock--lightBG'
,p_plug_template=>wwv_flow_imp.id(15280137168168654)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>10
,p_plug_display_column=>2
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Aplicaci&oacute;n para la administraci&oacute;n y control de las solicitudes u &oacute;rdenes de soporte que realizan los clientes a la empresa.</p> ',
'  El flujo de actividades inicia con el registro de la solicitud y permite gestionar todo el proceso de diagn&oacute;stico del problema indicado, hasta proporcionar la soluci&oacute;n, cierre y respectiva facturaci&oacute;n de los gastos incurridos.'))
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20280747051819756)
,p_name=>'P10040_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(15462370720169270)
,p_item_default=>'#APP_FILES#flujosoporte.jpg'
,p_prompt=>'1'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_attributes=>'style="border:0;height4:80px;width:825px;"'
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20280835914819757)
,p_name=>'P10040_F2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(15462370720169270)
,p_item_default=>'#APP_FILES#flujo_soporte2.jpg'
,p_prompt=>'2'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_attributes=>'style="border:0;height:480px;width:825px;"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(15376474378168765)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_imp.component_end;
end;
/
