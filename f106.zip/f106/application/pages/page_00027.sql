prompt --application/pages/page_00027
begin
--   Manifest
--     PAGE: 00027
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_page.create_page(
 p_id=>27
,p_name=>'ADD_IMPUESTOS'
,p_alias=>'ADD-IMPUESTOS'
,p_page_mode=>'MODAL'
,p_step_title=>'IMPUESTOS'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'500'
,p_dialog_width=>'700'
,p_dialog_attributes=>'close: function(event, ui) {apex.navigation.dialog.close(true,{dialogPageId:27});}'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230322092226'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17181503765131840)
,p_plug_name=>'DISPONIBLES'
,p_region_name=>'mylistview'
,p_region_template_options=>'#DEFAULT#:t-Region--accent4:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(15306456740168682)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>4
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID MID,',
'       DESCRIPCION,',
'       SIGLAS,',
'       PORCIENTO,',
'       VALOR,',
'       ESTADO',
'  from IMPUESTOS',
' where COMPANIA=:P0_CIA',
' order by ID'))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P27_DCOT,P27_ADD'
,p_plug_query_num_rows=>15
,p_plug_footer=>'Click para agregar impuesto.'
,p_attribute_01=>'ADVANCED_FORMATTING:INSET'
,p_attribute_03=>'span class="select-room"'
,p_attribute_04=>'data-id="&MID." '
,p_attribute_05=>'&SIGLAS.'
,p_attribute_16=>'javascript:$s(''P27_ADD'',''&MID.'')'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17181585576131841)
,p_plug_name=>'APLICAR'
,p_region_name=>'MILISTA2'
,p_region_template_options=>'#DEFAULT#:t-Region--accent7:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(15306456740168682)
,p_plug_display_sequence=>45
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>6
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D.DCOT_ID,',
'       D.ID NID,',
'       D.IMPUESTO_ID IID,',
'       I.SIGLAS DESCRIPCION',
'  from IMPUESTOS I',
'    inner join SOPORTE.DCOT_IMPUESTOS D',
'    on I.ID = D.IMPUESTO_ID and D.DCOT_ID=:P27_DCOT',
'',
'  '))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'P27_DCOT'
,p_plug_query_num_rows=>15
,p_attribute_01=>'ADVANCED_FORMATTING:INSET'
,p_attribute_03=>'span class="select-imp"'
,p_attribute_04=>'data-id="&IID." '
,p_attribute_05=>'&DESCRIPCION.'
,p_attribute_16=>'javascript:$s(''P27_DEL'',''&IID.'')'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17184555733131870)
,p_button_sequence=>75
,p_button_name=>'Close'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(15378986689168770)
,p_button_image_alt=>'Close'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17181695462131842)
,p_name=>'P27_DCOT'
,p_item_sequence=>55
,p_item_default=>'37'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17181791776131843)
,p_name=>'P27_ADD'
,p_item_sequence=>65
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17509596776918446)
,p_name=>'P27_DEL'
,p_item_sequence=>85
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17182293082131848)
,p_name=>'CLICK_SELECTOR'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.select-room'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17183270272131858)
,p_event_id=>wwv_flow_imp.id(17182293082131848)
,p_event_result=>'TRUE'
,p_action_sequence=>5
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Desea incluir este impuesto?'
,p_attribute_02=>'Confirmar'
,p_attribute_06=>'Si'
,p_attribute_07=>'No'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17182404058131849)
,p_event_id=>wwv_flow_imp.id(17182293082131848)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin',
'  insert into dcot_impuestos',
'    values(:P27_DCOT,SEQ_UBICACION.NEXTVAL,:P27_ADD);',
'End;'))
,p_attribute_02=>'P27_ADD'
,p_attribute_03=>'P27_DCOT,P27_ADD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17183426040131859)
,p_event_id=>wwv_flow_imp.id(17182293082131848)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Listo!'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17185070022131876)
,p_event_id=>wwv_flow_imp.id(17182293082131848)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(17181585576131841)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17509099774918441)
,p_name=>'CLICK_SELECTOR_A'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.select-imp'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17509194643918442)
,p_event_id=>wwv_flow_imp.id(17509099774918441)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Desea eliminar este impuesto?'
,p_attribute_02=>'Confirmar'
,p_attribute_06=>'Si'
,p_attribute_07=>'No'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17509343680918443)
,p_event_id=>wwv_flow_imp.id(17509099774918441)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Begin',
'  delete from dcot_impuestos',
'    where dcot_id = :P27_DCOT',
'      and impuesto_id = :P27_DEL;',
'End;'))
,p_attribute_02=>'P27_DEL'
,p_attribute_03=>'P27_DCOT,P27_DEL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17509378386918444)
,p_event_id=>wwv_flow_imp.id(17509099774918441)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Listo!'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17509523918918445)
,p_event_id=>wwv_flow_imp.id(17509099774918441)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(17181585576131841)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17184642186131871)
,p_name=>'Cierralo'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(17184555733131870)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17184710390131872)
,p_event_id=>wwv_flow_imp.id(17184642186131871)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_attribute_01=>'P27_DCOT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17507900762769717)
,p_process_sequence=>5
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form GRABA IMP'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Registrado!'
,p_internal_uid=>17507900762769717
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17186083778131886)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'GRABACLOSE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(17184555733131870)
,p_process_success_message=>'Bien!'
,p_internal_uid=>17186083778131886
);
wwv_flow_imp.component_end;
end;
/
