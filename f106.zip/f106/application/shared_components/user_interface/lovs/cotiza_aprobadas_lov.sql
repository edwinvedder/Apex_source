prompt --application/shared_components/user_interface/lovs/cotiza_aprobadas_lov
begin
--   Manifest
--     COTIZA_APROBADAS_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(16709281172655302)
,p_lov_name=>'COTIZA_APROBADAS_LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID CODIGO, ''COT.#''||TO_CHAR(ID)||'' del: ''||TO_CHAR(FECHA,''DD/MON/YYYY'') MICOT FROM COTIZACION',
'WHERE COMPANIA=:P0_CIA AND ESTADO =''B'''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'CODIGO'
,p_display_column_name=>'MICOT'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'MICOT'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
