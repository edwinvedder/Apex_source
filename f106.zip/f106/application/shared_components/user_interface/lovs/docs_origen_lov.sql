prompt --application/shared_components/user_interface/lovs/docs_origen_lov
begin
--   Manifest
--     DOCS_ORIGEN_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(18237612278181422)
,p_lov_name=>'DOCS_ORIGEN_LOV'
,p_lov_query=>'.'||wwv_flow_imp.id(18237612278181422)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(18238039480181422)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'EXTERNO'
,p_lov_return_value=>'E'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(18238402688181424)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'INTERNO'
,p_lov_return_value=>'I'
);
wwv_flow_imp.component_end;
end;
/
