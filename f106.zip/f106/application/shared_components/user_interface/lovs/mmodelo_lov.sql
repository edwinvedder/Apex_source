prompt --application/shared_components/user_interface/lovs/mmodelo_lov
begin
--   Manifest
--     MMODELO_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(18733197177125311)
,p_lov_name=>'MMODELO_LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT B.ID, A.SIGLAS||''-''||B.DESCRIPCION MODELO FROM MARCAS_MODELOS A, MODELOS B',
'WHERE A.ID > 0',
'  AND A.ESTADO = ''A''',
'  AND B.ID > 0',
'  AND B.MARCAID = A.ID',
'  AND B.ESTADO = ''A'''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'MODELO'
,p_default_sort_column_name=>'MODELO'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
