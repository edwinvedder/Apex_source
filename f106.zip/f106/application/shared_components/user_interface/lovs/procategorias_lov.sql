prompt --application/shared_components/user_interface/lovs/procategorias_lov
begin
--   Manifest
--     PROCATEGORIAS_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(19647501855701278)
,p_lov_name=>'PROCATEGORIAS_LOV'
,p_lov_query=>'.'||wwv_flow_imp.id(19647501855701278)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(19647794563701279)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'SE COMPRA'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(19648197566701279)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'SE VENDE'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(19648591336701280)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'COMPRA Y VENDE'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(19649058312701280)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'NO APLICA'
,p_lov_return_value=>'4'
);
wwv_flow_imp.component_end;
end;
/
