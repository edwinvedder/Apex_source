prompt --application/shared_components/user_interface/lovs/supervisores_lov
begin
--   Manifest
--     SUPERVISORES_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(15685618247797471)
,p_lov_name=>'SUPERVISORES_LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT P.ID CODIGO, P.NOMBRE||'' ''||P.APELLIDOS NOMBRE FROM PERSONAL P, OFICIOS_PERSONAL OP',
'WHERE P.ID = OP.PERSONAL_ID',
'  AND OP.ID > 0',
'  AND OP.OFICIO_ID IN(select para_valor from parametros where para_nombre=''OFICIOS_SUPERVISORES'')'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'CODIGO'
,p_display_column_name=>'NOMBRE'
,p_default_sort_column_name=>'NOMBRE'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
