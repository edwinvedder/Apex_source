prompt --application/shared_components/user_interface/lovs/marcas_modelos_lov
begin
--   Manifest
--     MARCAS_MODELOS_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(19650449742723163)
,p_lov_name=>'MARCAS_MODELOS_LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT B.ID ID,A.SIGLAS||''/''||B.DESCRIPCION MARCAM FROM MARCAS_MODELOS A, MODELOS B',
'WHERE A.COMPANIA=:P0_CIA',
'AND B.MARCAID = A.ID',
'AND B.ESTADO = ''A''',
'AND B.ID > 0'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'MARCAM'
,p_default_sort_column_name=>'MARCAM'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
