prompt --application/shared_components/reports/report_layouts/rl_empleados_prueba
begin
--   Manifest
--     REPORT LAYOUT: rl_empleados_prueba
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
    wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
    wwv_flow_imp.g_varchar2_table(1) := '<?xml version="1.0" encoding="UTF-8"?>'||wwv_flow.LF||
'<DOCUMENT>'||wwv_flow.LF||
'<ROWSET>'||wwv_flow.LF||
'   <ROW>'||wwv_flow.LF||
'      <COMPANIA>1</COMPANIA>'||wwv_flow.LF||
'   ';
    wwv_flow_imp.g_varchar2_table(2) := '   <ID>9</ID>'||wwv_flow.LF||
'      <CARNET>0054</CARNET>'||wwv_flow.LF||
'      <ID_CEDULA>00101489652</ID_CEDULA>'||wwv_flow.LF||
'      <NOMBRE>EDW';
    wwv_flow_imp.g_varchar2_table(3) := 'IN</NOMBRE>'||wwv_flow.LF||
'      <APELLIDOS>ANTIGUA</APELLIDOS>'||wwv_flow.LF||
'      <DIRECCION>CESAR CANO #259</DIRECCION>'||wwv_flow.LF||
'      ';
    wwv_flow_imp.g_varchar2_table(4) := '<TELEFONO>8092994814</TELEFONO>'||wwv_flow.LF||
'      <ESTADO>A</ESTADO>'||wwv_flow.LF||
'      <HORARIO_ID>1</HORARIO_ID>'||wwv_flow.LF||
'      <FOT';
    wwv_flow_imp.g_varchar2_table(5) := 'O>[unsupported data type]</FOTO>'||wwv_flow.LF||
'      <USUARIO>SOPORTE</USUARIO>'||wwv_flow.LF||
'      <EMAIL>eantigua@hotmail.com<';
    wwv_flow_imp.g_varchar2_table(6) := '/EMAIL>'||wwv_flow.LF||
'   </ROW>'||wwv_flow.LF||
'   <ROW>'||wwv_flow.LF||
'      <COMPANIA>1</COMPANIA>'||wwv_flow.LF||
'      <ID>10</ID>'||wwv_flow.LF||
'      <CARNET>0059</CARNET';
    wwv_flow_imp.g_varchar2_table(7) := '>'||wwv_flow.LF||
'      <ID_CEDULA>00102541225</ID_CEDULA>'||wwv_flow.LF||
'      <NOMBRE>RAFAEL</NOMBRE>'||wwv_flow.LF||
'      <APELLIDOS>MENDEZ</AP';
    wwv_flow_imp.g_varchar2_table(8) := 'ELLIDOS>'||wwv_flow.LF||
'      <DIRECCION>C/ BARAHONA #44</DIRECCION>'||wwv_flow.LF||
'      <TELEFONO>8095442244</TELEFONO>'||wwv_flow.LF||
'      <E';
    wwv_flow_imp.g_varchar2_table(9) := 'STADO>A</ESTADO>'||wwv_flow.LF||
'      <HORARIO_ID>1</HORARIO_ID>'||wwv_flow.LF||
'      <FOTO></FOTO>'||wwv_flow.LF||
'      <USUARIO>SOPORTE1</USUAR';
    wwv_flow_imp.g_varchar2_table(10) := 'IO>'||wwv_flow.LF||
'      <EMAIL>rmendez@koinos.com.do</EMAIL>'||wwv_flow.LF||
'   </ROW>'||wwv_flow.LF||
'   <ROW>'||wwv_flow.LF||
'      <COMPANIA>1</COMPANIA>'||wwv_flow.LF||
'     ';
    wwv_flow_imp.g_varchar2_table(11) := ' <ID>11</ID>'||wwv_flow.LF||
'      <CARNET>0028</CARNET>'||wwv_flow.LF||
'      <ID_CEDULA>00102115410</ID_CEDULA>'||wwv_flow.LF||
'      <NOMBRE>ROBE';
    wwv_flow_imp.g_varchar2_table(12) := 'RTO</NOMBRE>'||wwv_flow.LF||
'      <APELLIDOS>JAQUEZ</APELLIDOS>'||wwv_flow.LF||
'      <DIRECCION>CALLE 2DA. #55, CIUDAD JUAN BOSCH<';
    wwv_flow_imp.g_varchar2_table(13) := '/DIRECCION>'||wwv_flow.LF||
'      <TELEFONO>8094675613</TELEFONO>'||wwv_flow.LF||
'      <ESTADO>A</ESTADO>'||wwv_flow.LF||
'      <HORARIO_ID>2</HORA';
    wwv_flow_imp.g_varchar2_table(14) := 'RIO_ID>'||wwv_flow.LF||
'      <FOTO></FOTO>'||wwv_flow.LF||
'      <USUARIO>RJAQUEZ</USUARIO>'||wwv_flow.LF||
'      <EMAIL>roberto.jaquez@gmail.com</';
    wwv_flow_imp.g_varchar2_table(15) := 'EMAIL>'||wwv_flow.LF||
'   </ROW>'||wwv_flow.LF||
'</ROWSET>'||wwv_flow.LF||
'</DOCUMENT>'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_report_layout(
 p_id=>wwv_flow_imp.id(21156734701945793)
,p_report_layout_name=>'rl_empleados_prueba'
,p_report_layout_type=>'XSL_FILE'
,p_varchar2_table=>wwv_flow_imp.g_varchar2_table
);
wwv_flow_imp.component_end;
end;
/
