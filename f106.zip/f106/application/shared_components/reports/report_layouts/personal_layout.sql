prompt --application/shared_components/reports/report_layouts/personal_layout
begin
--   Manifest
--     REPORT LAYOUT: personal_layout
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
    wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
    wwv_flow_imp.g_varchar2_table(1) := '<?xml version = ''1.0'' encoding = ''utf-8''?>'||wwv_flow.LF||
'<xsl:stylesheet version="2.0" xmlns:xsl="http://www.w3.or';
    wwv_flow_imp.g_varchar2_table(2) := 'g/1999/XSL/Transform" xmlns:fo="http://www.w3.org/1999/XSL/Format" xmlns:xlink="http://www.w3.org/19';
    wwv_flow_imp.g_varchar2_table(3) := '99/xlink">'||wwv_flow.LF||
'   <xsl:variable name="CARNET" select="''''"/>'||wwv_flow.LF||
'   <xsl:variable name="NOMBRE" select="''''"/"';
    wwv_flow_imp.g_varchar2_table(4) := '/>'||wwv_flow.LF||
'   <xsl:variable name="APELLIDOS" select="''''"/"/>'||wwv_flow.LF||
'   <xsl:variable name="EMAIL" select="''''"/"/>'||wwv_flow.LF||
' ';
    wwv_flow_imp.g_varchar2_table(5) := '  <xsl:attribute-set name="padding">'||wwv_flow.LF||
'      <xsl:attribute name="padding-bottom">0.25pt</xsl:attribut';
    wwv_flow_imp.g_varchar2_table(6) := 'e>'||wwv_flow.LF||
'      <xsl:attribute name="padding-top">0.25pt</xsl:attribute>'||wwv_flow.LF||
'   </xsl:attribute-set>'||wwv_flow.LF||
'   <xsl:at';
    wwv_flow_imp.g_varchar2_table(7) := 'tribute-set name="text">'||wwv_flow.LF||
'      <xsl:attribute name="text-align">start</xsl:attribute>'||wwv_flow.LF||
'      <xsl:att';
    wwv_flow_imp.g_varchar2_table(8) := 'ribute name="orphans">2</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="start-indent">0.0pt</xsl:attribut';
    wwv_flow_imp.g_varchar2_table(9) := 'e>'||wwv_flow.LF||
'      <xsl:attribute name="linefeed-treatment">preserve</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name';
    wwv_flow_imp.g_varchar2_table(10) := '="padding-top">0.0pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="end-indent">0.0pt</xsl:attribute>'||wwv_flow.LF||
'  ';
    wwv_flow_imp.g_varchar2_table(11) := '    <xsl:attribute name="padding-bottom">0.0pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="height">0.';
    wwv_flow_imp.g_varchar2_table(12) := '0pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="widows">2</xsl:attribute>'||wwv_flow.LF||
'   </xsl:attribute-set>'||wwv_flow.LF||
'   ';
    wwv_flow_imp.g_varchar2_table(13) := '<xsl:attribute-set name="align-left">'||wwv_flow.LF||
'      <xsl:attribute name="text-align">left</xsl:attribute>'||wwv_flow.LF||
'  ';
    wwv_flow_imp.g_varchar2_table(14) := ' </xsl:attribute-set>'||wwv_flow.LF||
'   <xsl:attribute-set name="align-center">'||wwv_flow.LF||
'      <xsl:attribute name="text-ali';
    wwv_flow_imp.g_varchar2_table(15) := 'gn">center</xsl:attribute>'||wwv_flow.LF||
'   </xsl:attribute-set>'||wwv_flow.LF||
'   <xsl:attribute-set name="align-right">'||wwv_flow.LF||
'      <';
    wwv_flow_imp.g_varchar2_table(16) := 'xsl:attribute name="text-align">right</xsl:attribute>'||wwv_flow.LF||
'   </xsl:attribute-set>'||wwv_flow.LF||
'   <xsl:attribute-set ';
    wwv_flow_imp.g_varchar2_table(17) := 'name="footer">'||wwv_flow.LF||
'      <xsl:attribute name="text-align">right</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute nam';
    wwv_flow_imp.g_varchar2_table(18) := 'e="start-indent">5.4pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="end-indent">5.4pt</xsl:attribute>'||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(19) := '   </xsl:attribute-set>'||wwv_flow.LF||
'   <xsl:attribute-set name="text_2">'||wwv_flow.LF||
'      <xsl:attribute name="start-indent';
    wwv_flow_imp.g_varchar2_table(20) := '">5.4pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="end-indent">23.4pt</xsl:attribute>'||wwv_flow.LF||
'   </xsl:attri';
    wwv_flow_imp.g_varchar2_table(21) := 'bute-set>'||wwv_flow.LF||
'   <xsl:attribute-set name="text_20">'||wwv_flow.LF||
'      <xsl:attribute name="height">13.872pt</xsl:att';
    wwv_flow_imp.g_varchar2_table(22) := 'ribute>'||wwv_flow.LF||
'      <xsl:attribute name="end-indent">5.4pt</xsl:attribute>'||wwv_flow.LF||
'   </xsl:attribute-set>'||wwv_flow.LF||
'   <xsl';
    wwv_flow_imp.g_varchar2_table(23) := ':attribute-set name="text_0">'||wwv_flow.LF||
'      <xsl:attribute name="end-indent">5.4pt</xsl:attribute>'||wwv_flow.LF||
'   </xsl:';
    wwv_flow_imp.g_varchar2_table(24) := 'attribute-set>'||wwv_flow.LF||
'   <xsl:attribute-set name="page-header">'||wwv_flow.LF||
'      <xsl:attribute name="color">#PAGE_HEA';
    wwv_flow_imp.g_varchar2_table(25) := 'DER_FONT_COLOR#</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="font-family">#PAGE_HEADER_FONT_FAMILY#</x';
    wwv_flow_imp.g_varchar2_table(26) := 'sl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="white-space-collapse">false</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attr';
    wwv_flow_imp.g_varchar2_table(27) := 'ibute name="font-size">#PAGE_HEADER_FONT_SIZE#pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="font-wei';
    wwv_flow_imp.g_varchar2_table(28) := 'ght">#PAGE_HEADER_FONT_WEIGHT#</xsl:attribute>'||wwv_flow.LF||
'   </xsl:attribute-set>'||wwv_flow.LF||
'   <xsl:attribute-set name="p';
    wwv_flow_imp.g_varchar2_table(29) := 'age-footer">'||wwv_flow.LF||
'      <xsl:attribute name="color">#PAGE_FOOTER_FONT_COLOR#</xsl:attribute>'||wwv_flow.LF||
'      <xsl:a';
    wwv_flow_imp.g_varchar2_table(30) := 'ttribute name="font-family">#PAGE_FOOTER_FONT_FAMILY#</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="whi';
    wwv_flow_imp.g_varchar2_table(31) := 'te-space-collapse">false</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="font-size">#PAGE_FOOTER_FONT_SIZ';
    wwv_flow_imp.g_varchar2_table(32) := 'E#pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="font-weight">#PAGE_FOOTER_FONT_WEIGHT#</xsl:attribut';
    wwv_flow_imp.g_varchar2_table(33) := 'e>'||wwv_flow.LF||
'   </xsl:attribute-set>'||wwv_flow.LF||
'   <xsl:attribute-set name="body-font">'||wwv_flow.LF||
'      <xsl:attribute name="height';
    wwv_flow_imp.g_varchar2_table(34) := '">12.0pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="font-family">#BODY_FONT_FAMILY#</xsl:attribute>'||wwv_flow.LF||
'';
    wwv_flow_imp.g_varchar2_table(35) := '      <xsl:attribute name="white-space-collapse">false</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="fo';
    wwv_flow_imp.g_varchar2_table(36) := 'nt-size">#BODY_FONT_SIZE#pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="font-weight">#BODY_FONT_WEIGH';
    wwv_flow_imp.g_varchar2_table(37) := 'T#</xsl:attribute>'||wwv_flow.LF||
'   </xsl:attribute-set>'||wwv_flow.LF||
'   <xsl:attribute-set name="page-number">'||wwv_flow.LF||
'      <xsl:attr';
    wwv_flow_imp.g_varchar2_table(38) := 'ibute name="height">13.872pt</xsl:attribute>'||wwv_flow.LF||
'   </xsl:attribute-set>'||wwv_flow.LF||
'   <xsl:attribute-set name="hea';
    wwv_flow_imp.g_varchar2_table(39) := 'der-font">'||wwv_flow.LF||
'      <xsl:attribute name="height">#HEADER_FONT_SIZE#pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attrib';
    wwv_flow_imp.g_varchar2_table(40) := 'ute name="font-family">#HEADER_FONT_FAMILY#</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="white-space-c';
    wwv_flow_imp.g_varchar2_table(41) := 'ollapse">false</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="font-size">#HEADER_FONT_SIZE#pt</xsl:attri';
    wwv_flow_imp.g_varchar2_table(42) := 'bute>'||wwv_flow.LF||
'      <xsl:attribute name="font-weight">#HEADER_FONT_WEIGHT#</xsl:attribute>'||wwv_flow.LF||
'   </xsl:attribut';
    wwv_flow_imp.g_varchar2_table(43) := 'e-set>'||wwv_flow.LF||
'   <xsl:attribute-set name="border">'||wwv_flow.LF||
'      <xsl:attribute name="border-top">#BORDER_WIDTH#pt ';
    wwv_flow_imp.g_varchar2_table(44) := 'solid #BORDER_COLOR#</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="border-bottom">#BORDER_WIDTH#pt soli';
    wwv_flow_imp.g_varchar2_table(45) := 'd #BORDER_COLOR#</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="border-start-width">#BORDER_WIDTH#pt</xs';
    wwv_flow_imp.g_varchar2_table(46) := 'l:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="border-start-color">#BORDER_COLOR#</xsl:attribute>'||wwv_flow.LF||
'      <xs';
    wwv_flow_imp.g_varchar2_table(47) := 'l:attribute name="border-start-style">solid</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="border-end-wi';
    wwv_flow_imp.g_varchar2_table(48) := 'dth">#BORDER_WIDTH#pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="border-end-color">#BORDER_COLOR#</x';
    wwv_flow_imp.g_varchar2_table(49) := 'sl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="border-end-style">solid</xsl:attribute>'||wwv_flow.LF||
'   </xsl:attribute-';
    wwv_flow_imp.g_varchar2_table(50) := 'set>'||wwv_flow.LF||
'   <xsl:attribute-set name="cell">'||wwv_flow.LF||
'      <xsl:attribute name="background-color">#BODY_BG_COLOR#';
    wwv_flow_imp.g_varchar2_table(51) := '</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="color">#BODY_FONT_COLOR#</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attr';
    wwv_flow_imp.g_varchar2_table(52) := 'ibute name="padding-start">5.15pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="vertical-align">top</xs';
    wwv_flow_imp.g_varchar2_table(53) := 'l:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="padding-top">0.0pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name';
    wwv_flow_imp.g_varchar2_table(54) := '="padding-end">5.15pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="number-columns-spanned">1</xsl:attr';
    wwv_flow_imp.g_varchar2_table(55) := 'ibute>'||wwv_flow.LF||
'      <xsl:attribute name="height">0.0pt</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name="padding-b';
    wwv_flow_imp.g_varchar2_table(56) := 'ottom">0.0pt</xsl:attribute>'||wwv_flow.LF||
'   </xsl:attribute-set>'||wwv_flow.LF||
'   <xsl:attribute-set name="header-color">'||wwv_flow.LF||
'    ';
    wwv_flow_imp.g_varchar2_table(57) := '  <xsl:attribute name="background-color">#HEADER_BG_COLOR#</xsl:attribute>'||wwv_flow.LF||
'      <xsl:attribute name';
    wwv_flow_imp.g_varchar2_table(58) := '="color">#HEADER_FONT_COLOR#</xsl:attribute>'||wwv_flow.LF||
'   </xsl:attribute-set>'||wwv_flow.LF||
'   <xsl:template match="/">'||wwv_flow.LF||
'   ';
    wwv_flow_imp.g_varchar2_table(59) := '   <fo:root>'||wwv_flow.LF||
'         <fo:layout-master-set>'||wwv_flow.LF||
'            <fo:simple-page-master master-name="master0';
    wwv_flow_imp.g_varchar2_table(60) := '" margin-left="66.6pt" margin-right="66.6pt" page-height="#PAGE_HEIGHT#pt" page-width="#PAGE_WIDTH#p';
    wwv_flow_imp.g_varchar2_table(61) := 't" margin-top="36.0pt" margin-bottom="36.0pt">'||wwv_flow.LF||
'               <fo:region-body region-name="region-bo';
    wwv_flow_imp.g_varchar2_table(62) := 'dy" margin-top="54.0pt" margin-bottom="54.0pt"/>'||wwv_flow.LF||
'               <fo:region-before region-name="regio';
    wwv_flow_imp.g_varchar2_table(63) := 'n-header" extent="54.0pt"/>'||wwv_flow.LF||
'               <fo:region-after region-name="region-footer" extent="54.0';
    wwv_flow_imp.g_varchar2_table(64) := 'pt" display-align="after"/>'||wwv_flow.LF||
'            </fo:simple-page-master>'||wwv_flow.LF||
'         </fo:layout-master-set>'||wwv_flow.LF||
'  ';
    wwv_flow_imp.g_varchar2_table(65) := '       <fo:page-sequence master-reference="master0">'||wwv_flow.LF||
'            <xsl:variable name="_PW" select="nu';
    wwv_flow_imp.g_varchar2_table(66) := 'mber(#PAGE_HEIGHT#)"/>'||wwv_flow.LF||
'            <xsl:variable name="_PH" select="number(#PAGE_WIDTH#)"/>'||wwv_flow.LF||
'        ';
    wwv_flow_imp.g_varchar2_table(67) := '    <xsl:variable name="_ML" select="number(72.0)"/>'||wwv_flow.LF||
'            <xsl:variable name="_MR" select="nu';
    wwv_flow_imp.g_varchar2_table(68) := 'mber(72.0)"/>'||wwv_flow.LF||
'            <xsl:variable name="_MT" select="number(90.0)"/>'||wwv_flow.LF||
'            <xsl:variable';
    wwv_flow_imp.g_varchar2_table(69) := ' name="_MB" select="number(90.0)"/>'||wwv_flow.LF||
'            <xsl:variable name="_HY" select="number(36.0)"/>'||wwv_flow.LF||
'   ';
    wwv_flow_imp.g_varchar2_table(70) := '         <xsl:variable name="_FY" select="number(36.0)"/>'||wwv_flow.LF||
'            <xsl:variable name="_SECTION_N';
    wwv_flow_imp.g_varchar2_table(71) := 'AME" select="string(''master0'')"/>'||wwv_flow.LF||
'            <fo:static-content flow-name="region-header">'||wwv_flow.LF||
'        ';
    wwv_flow_imp.g_varchar2_table(72) := '       <fo:block xsl:use-attribute-sets="text text_2 text_0 #PAGE_HEADER_ALIGNMENT#">'||wwv_flow.LF||
'              ';
    wwv_flow_imp.g_varchar2_table(73) := '    <fo:inline xsl:use-attribute-sets="page-header">#PAGE_HEADER#</fo:inline>'||wwv_flow.LF||
'               </fo:bl';
    wwv_flow_imp.g_varchar2_table(74) := 'ock>'||wwv_flow.LF||
'            </fo:static-content>'||wwv_flow.LF||
'            <fo:static-content flow-name="region-footer">'||wwv_flow.LF||
'    ';
    wwv_flow_imp.g_varchar2_table(75) := '           <fo:block xsl:use-attribute-sets="text footer">'||wwv_flow.LF||
'                  <fo:inline xsl:use-attr';
    wwv_flow_imp.g_varchar2_table(76) := 'ibute-sets="body-font page-number">'||wwv_flow.LF||
'                     <fo:page-number/>'||wwv_flow.LF||
'                  </fo:in';
    wwv_flow_imp.g_varchar2_table(77) := 'line>'||wwv_flow.LF||
'               </fo:block>'||wwv_flow.LF||
'               <fo:block xsl:use-attribute-sets="text text_2 #PAGE_';
    wwv_flow_imp.g_varchar2_table(78) := 'FOOTER_ALIGNMENT#">'||wwv_flow.LF||
'                  <fo:inline xsl:use-attribute-sets="page-footer">#PAGE_FOOTER#<';
    wwv_flow_imp.g_varchar2_table(79) := '/fo:inline>'||wwv_flow.LF||
'               </fo:block>'||wwv_flow.LF||
'            </fo:static-content>'||wwv_flow.LF||
'         </fo:page-sequence>';
    wwv_flow_imp.g_varchar2_table(80) := ''||wwv_flow.LF||
'      </fo:root>'||wwv_flow.LF||
'   </xsl:template>'||wwv_flow.LF||
'</xsl:stylesheet>'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_report_layout(
 p_id=>wwv_flow_imp.id(21146142770362436)
,p_report_layout_name=>'personal_layout'
,p_report_layout_type=>'XSL_GENERIC'
,p_varchar2_table=>wwv_flow_imp.g_varchar2_table
,p_xslfo_column_heading=>wwv_flow_string.join(wwv_flow_t_varchar2(
'                           <fo:table-cell xsl:use-attribute-sets="cell header-color border">',
'                               <fo:block xsl:use-attribute-sets="text #TEXT_ALIGN#">',
'                                   <fo:inline xsl:use-attribute-sets="header-font">#COLUMN_HEADING#</fo:inline>',
'                               </fo:block>',
'                           </fo:table-cell>',
''))
,p_xslfo_column_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'                              <fo:table-cell xsl:use-attribute-sets="cell border">',
'                                  <fo:block xsl:use-attribute-sets="text #TEXT_ALIGN#">',
'                                      <fo:inline xsl:use-attribute-sets="body-font">',
'                                          <xsl:value-of select=".//#COLUMN_HEADER_NAME#"/>',
'                                      </fo:inline>',
'                                  </fo:block>',
'                              </fo:table-cell>',
''))
,p_xslfo_column_template_width=>wwv_flow_string.join(wwv_flow_t_varchar2(
'                     <fo:table-column column-width="#COLUMN_WIDTH#pt"/>',
''))
);
wwv_flow_imp.component_end;
end;
/
