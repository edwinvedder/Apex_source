prompt --application/shared_components/reports/report_queries/probando_query
begin
--   Manifest
--     WEB SERVICE: probando_query
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_shared.create_shared_query(
 p_id=>wwv_flow_imp.id(21144942100301907)
,p_name=>'probando_query'
,p_query_text=>'select * from personal'
,p_report_layout_id=>wwv_flow_imp.id(21149408778910106)
,p_format=>'PDF'
,p_output_file_name=>'probando_query'
,p_content_disposition=>'INLINE'
);
wwv_flow_imp_shared.create_shared_query_stmnt(
 p_id=>wwv_flow_imp.id(21157530390950686)
,p_shared_query_id=>wwv_flow_imp.id(21144942100301907)
,p_sql_statement=>'select * from personal'
);
wwv_flow_imp.component_end;
end;
/
