prompt --application/shared_components/web_sources/https_restcountries_com_v3_1_all
begin
--   Manifest
--     WEB SOURCE: https://restcountries.com/v3.1/all
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(21705513347463981)
,p_name=>'https://restcountries.com/v3.1/all'
,p_static_id=>'https___restcountries_com_v3_1_all'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(21615325117463902)
,p_remote_server_id=>wwv_flow_imp.id(21615099635463896)
,p_url_path_prefix=>'/v3.1/all'
,p_sync_table_owner=>'SOPORTE'
,p_sync_table_name=>'COUNTRY_INFO'
,p_sync_type=>'APPEND'
,p_sync_max_http_requests=>1000
,p_pass_ecid=>true
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(21705704979464002)
,p_web_src_module_id=>wwv_flow_imp.id(21705513347463981)
,p_name=>'restcountries'
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
