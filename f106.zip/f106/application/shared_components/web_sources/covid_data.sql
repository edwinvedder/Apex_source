prompt --application/shared_components/web_sources/covid_data
begin
--   Manifest
--     WEB SOURCE: COVID_DATA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(20322157341196963)
,p_name=>'COVID_DATA'
,p_static_id=>'COVID_DATA'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(20318575655196953)
,p_remote_server_id=>wwv_flow_imp.id(20309567730242882)
,p_url_path_prefix=>'/summary'
,p_sync_is_active=>true
,p_sync_table_owner=>'SOPORTE'
,p_sync_table_name=>'COVID_RESULTADOS'
,p_sync_type=>'APPEND'
,p_sync_interval=>'FREQ=WEEKLY;INTERVAL=1;BYDAY=FRI;BYHOUR=10;BYMINUTE=11;BYSECOND=0'
,p_sync_max_http_requests=>1000
,p_pass_ecid=>true
,p_attribute_05=>'1'
,p_attribute_08=>'OFFSET'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(20322353689196965)
,p_web_src_module_id=>wwv_flow_imp.id(20322157341196963)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
