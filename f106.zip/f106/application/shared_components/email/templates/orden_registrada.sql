prompt --application/shared_components/email/templates/orden_registrada
begin
--   Manifest
--     REPORT LAYOUT: Orden Registrada
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(20082860089648749)
,p_name=>'Orden Registrada'
,p_static_id=>'ORDEN_REGISTRADA'
,p_version_number=>2
,p_subject=>'KOINOS, Orden Registrada(#MID#)'
,p_html_body=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Saludos #CUSTOMER_NAME#</strong>,<br>',
'<br>',
'Informamos que tenemos registrada la orden num.#MID#, a su solicitud.<br>  Desde el #ORDER_DATE#, nos encontramos atendiendo su requerimiento.',
'    Abajo un detalle actualizado de la misma.<br>',
'<br>',
'<strong>Detalle Orden Registrada</strong><br>',
'<br>',
'<table width="100%">',
'  <tr>',
'    <th align="left">De Fecha</th>',
'    <td>#ORDER_DATE#</td>',
'  </tr>',
'  <tr>',
'    <th align="left">Orden Num.</th>',
'    <td>#ORDER_NUMBER#</td>',
'  </tr>',
'    <tr>',
'    <th align="left">Servicio</th>',
'    <td>#GESTION#</td>',
'  </tr>',
'    <tr>',
'    <th align="left">Estado Actual</th>',
'    <td><b>#ESTADO#</b></td>',
'  </tr>',
'  <tr>',
'    <th align="left">SUPERVISOR ASIGNADO</th>',
'    <td>#RESPONSABLE#</td>',
'  </tr>',
' ',
'</table>',
'<br>',
'<br>',
'Conocer detalles o Informar inconvenientes <a href="#ORDER_URL#"></a> '))
,p_html_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<b style="font-size: 24px;">Orden Registrada</b>',
'   ',
' ',
'    '))
,p_html_footer=>'<a href="#MY_APPLICATION_LINK#"></a>.'
,p_html_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!DOCTYPE HTML>',
'<html>',
'<head>',
'  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">',
'  <meta name="viewport" content="width=device-width">',
'  <style>',
'    body { background-color: #fdfdfd; color: #3e3e3e; margin: 0; padding: 0; min-width: 100%; -webkit-text-size-adjust: none; -ms-text-size-adjust: none; text-size-adjust: none; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica N'
||'eue", Roboto, Helvetica, Arial, sans-serif; line-height: 1.5; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }',
'    table { border: 0; border-spacing: 0; border-collapse: collapse; mso-table-lspace: 0pt; mso-table-rspace: 0pt; }',
'    table td { padding: 0; vertical-align: top; border-collapse: collapse; }',
'    table, th, td { line-height: inherit; }',
'    img { vertical-align: middle; text-decoration: none; outline: none; border: 0; -ms-interpolation-mode: bicubic; }',
'    table.container { margin-right: auto; margin-left: auto; width: 600px; }',
'    p { margin: 0 0 20px 0; }',
'    a, .main a { color: #056abf; }',
'    @media only screen and (max-width: 612px) {',
'      .mobile-hide { display: none !important; }',
'      .stack { display: block !important; width: auto !important; }',
'      table.container { width: 100% !important; }',
'      table td { text-align: left !important; }',
'    }',
'  </style>',
'</head>',
'<body yahoo="fix" style="background-color: #efefef; line-height: 1.5;">',
'<table class="body" border="0" width="100%">',
'  <tr>',
'    <td align="center" valign="top" style="background-color: #efefef;">',
'      <center>',
'        <table class="container" width="600">',
'          <tr>',
'            <td style="padding: 12px 6px;">',
'',
'              <!-- Header -->',
'              <table width="100%" style="background-color: #f8f8f8; border-radius: 4px 4px 0 0">',
'                <tr>',
'                  <td style="text-align: left; padding: 20px 12px; border-bottom: 1px solid #eaeaea;">',
'                    #HEADER#',
'                  </td>',
'                </tr>',
'              </table>',
'              <!-- // Header -->',
'',
'              <!-- Main Body -->',
'              <table width="100%" style="background-color: #ffffff; border-radius: 0 0 4px 4px;">',
'                <tr>',
'                  <td class="main" style="text-align: left; padding: 12px; font-size: 14px;">',
'                  #BODY#',
'                  </td>',
'                </tr>',
'              </table>',
'              <!-- // Main Body -->',
'',
'              <!-- Footer -->',
'              <table width="100%">',
'                <tr>',
'                  <td style="font-size: 11px; padding: 12px;">',
'                    #FOOTER#',
'                  </td>',
'                </tr>',
'              </table>',
'              <!-- // Footer -->',
'',
'            </td>',
'          </tr>',
'        </table>',
'      </center>',
'    </td>',
'  </tr>',
'</table>',
'</body>',
'</html>'))
,p_text_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Hello #CUSTOMER_NAME#,',
'',
'Thank you for placing your order!',
'',
'Order Details',
'--------------------------------------------------------------------------------',
'  Order Date:       #ORDER_DATE#',
'  Order Number:     #ORDER_NUMBER#',
'  Ship To:          #SHIP_TO#',
'  Shipping Address: #SHIPPING_ADDRESS_LINE_1#',
'                    #SHIPPING_ADDRESS_LINE_2#',
'  Items Ordered:    #ITEMS_ORDERED#',
'  Order Total:      #ORDER_TOTAL#',
'--------------------------------------------------------------------------------',
'',
'Need to make a change to your order? Manage your order #ORDER_NUMBER# here: #ORDER_URL#'))
);
wwv_flow_imp.component_end;
end;
/
