prompt --application/shared_components/email/templates/factura_email
begin
--   Manifest
--     REPORT LAYOUT: FACTURA EMAIL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(20834503461708122)
,p_name=>'FACTURA EMAIL'
,p_static_id=>'FACTURA_EMAIL'
,p_version_number=>1
,p_subject=>'KOINOS FACTURA  (#FACT_NUMBER#)'
,p_html_body=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Saludos #CUSTOMER_NAME#</strong>,<br>',
'',
'<br>',
'Adjunto factura N&uacute;m.<B>#FACT_NUMBER#</B> de fecha #FECHA_FACTURA#, correspondiente al servicio #EL_SERVICIO# por un monto #MONTO_BRUTO#.<br>',
'<br><strong>Detalle</strong><br>',
'<table width="100%">',
'  <tr>',
'    <th align="left">Fecha</th>',
'    <td>#FECHA_FACTURA#</td>',
'  </tr>',
'  <tr>',
'    <th align="left">Factura No.</th>',
'    <td>#FACT_NUMBER#</td>',
'  </tr>',
'  <tr>',
'    <th align="left">Condici&oacute;n de Pago:</th>',
'    <td>#CONDICION#</td>',
'  </tr> ',
'  <tr>',
'    <th align="left">Total Factura</th>',
'    <td>#MONTO_BRUTO#</td>',
'  </tr>',
'  <tr>',
'    <th align="left">Total Pendiente</th>',
'    <td>#MONTO_DEUDA#</td>',
'  </tr>',
'  <tr>',
'      <td colspan = 2 >',
'        Gracias por confiar en KOINOS, SRL.<br>',
'     </td>',
'  </tr>',
'</table>',
'<br>',
'<br>',
'Comentario o duda? <a href="www.koinos.com.do/#contact">Indicar n&uacute;mero factura: #FACT_NUMBER#.</a>'))
,p_html_header=>'<b style="font-size: 24px;">FACTURA</b>'
,p_html_footer=>'<a href="www.koinos.com.do">KOINOS, SRL</a>.'
,p_text_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Hello #CUSTOMER_NAME#,',
'',
'Thank you for placing your order!',
'',
'Order Details',
'--------------------------------------------------------------------------------',
'  Order Date:       #ORDER_DATE#',
'  Order Number:     #ORDER_NUMBER#',
'  Ship To:          #SHIP_TO#',
'  Shipping Address: #SHIPPING_ADDRESS_LINE_1#',
'                    #SHIPPING_ADDRESS_LINE_2#',
'  Items Ordered:    #ITEMS_ORDERED#',
'  Order Total:      #ORDER_TOTAL#',
'--------------------------------------------------------------------------------',
'',
'Need to make a change to your order? Manage your order #ORDER_NUMBER# here: #ORDER_URL#'))
);
wwv_flow_imp.component_end;
end;
/
