prompt --workspace/remote_servers/restcountries_com
begin
--   Manifest
--     REMOTE SERVER: restcountries-com
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.5'
,p_default_workspace_id=>7164858141668868
,p_default_application_id=>106
,p_default_id_offset=>12890961370314936
,p_default_owner=>'SOPORTE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(21615099635463896)
,p_name=>'restcountries-com'
,p_static_id=>'restcountries_com'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('restcountries_com'),'https://restcountries.com')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('restcountries_com'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('restcountries_com'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('restcountries_com'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('restcountries_com'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
